policy_partition <- function(con, here, shard, n_shards, note = message) {
  query <- function(s) DBI::dbGetQuery(con, s)
  execute <- function(s) invisible(DBI::dbExecute(con, s))
  run_file <- function(name, after = NULL) {
    x <- readLines(file.path(here, name), warn = FALSE, encoding = "UTF-8")
    x <- x[!grepl("^\\s*--", x, perl = TRUE) & nzchar(trimws(x))]
    ends <- which(grepl(";\\s*(--.*)?$", x, perl = TRUE))
    stopifnot(length(ends) > 0L, tail(ends, 1L) == length(x))
    starts <- c(1L, head(ends, -1L) + 1L)
    for (i in seq_along(ends)) {
      statement <- paste(x[starts[i]:ends[i]], collapse = "\n")
      tryCatch(execute(statement), error = function(e) {
        object <- strsplit(statement, "\n", fixed=TRUE)[[1]][1L]
        stop(paste("Partition",shard+1L,"file",name,"at",substr(object,1L,100L),conditionMessage(e)),call.=FALSE)
      })
      if (!is.null(after)) after(statement)
    }
  }
  eras <- c("early", "late", "boundary_or_unknown","all")
  policies <- c("all_pending","gram","dynamic","gram_plus_dynamic",
                "nonblood_plus_gram_blood","nonblood_gram_blood_plus_dynamic")
  note(paste("Partition",shard+1L,"of",n_shards,"- specimen labels and final reports"))
  run_file("label_keys.sql")
  run_file("culture.sql", function(statement) {
    if (startsWith(statement, "CREATE TEMP TABLE culture_culture_rows AS")) run_file("performance.sql")
  })
  note(paste("Partition",shard+1L,"of",n_shards,"- transfer medications and susceptibility"))
  for (f in c("medications.sql","windows.sql","result_drugs.sql","live_trigger.sql",
              "meds.sql","spectrum.sql","paired_targets.sql","metrics.sql")) run_file(f)
  events <- query("SELECT * FROM reflex_events")
  stopifnot(!anyDuplicated(events[c("pid","hid","specimen")]), !anyNA(events))
  denominators <- query("SELECT CASE WHEN era_upper<=2019 THEN 'early' WHEN era_lower>=2020 THEN 'late'
     ELSE 'boundary_or_unknown' END AS era,count(*) AS patients,count(DISTINCT pid) AS unique_patients
     FROM cohort GROUP BY era")
  stopifnot(all(denominators$patients==denominators$unique_patients))
  n_person <- function(df, flag) length(unique(df$pid[flag]))
  policy_counts <- function(df, policy) {
    timed <- df$dynamic & policy %in% c("dynamic","gram_plus_dynamic","nonblood_gram_blood_plus_dynamic")
    static <- switch(policy, all_pending=df$pending, gram=df$gram, gram_plus_dynamic=df$gram,
      nonblood_plus_gram_blood=df$nonblood_plus_gram_blood,
      nonblood_gram_blood_plus_dynamic=df$nonblood_plus_gram_blood,
      dynamic=rep(FALSE,nrow(df)))
    mm <- (df$mismatch & static) | (timed & df$dynamic_mismatch)
    pp <- (df$positive & static) | (timed & df$dynamic_positive)
    data.frame(reviews=sum(static | timed),review_occasions=sum(static)+sum(timed),
        dynamic_after_first_ward=sum(timed & df$after_first_ward),
        positive_specimens=sum(df$positive),positive_captured=sum(pp),mismatch_specimens=sum(df$mismatch),
        mismatch_captured=sum(mm),mismatch_patients=n_person(df,df$mismatch),mismatch_patients_captured=n_person(df,mm))
  }
  era_rows <- list()
  policy_rows <- list()
  for (era in eras) {
    events_in_era <- if (era=="all") events else events[events$era==era,,drop=FALSE]
    denominator <- if (era=="all") sum(denominators$patients) else sum(denominators$patients[denominators$era==era])
    for (scope in c("frozen","plus_exact_reflex")) {
      df <- if (scope=="frozen") events_in_era[!events_in_era$added,,drop=FALSE] else events_in_era
      era_rows[[length(era_rows)+1L]] <- data.frame(era=era,scope=scope,transfers=denominator,
        pending_specimens=sum(df$pending),pending_patients=n_person(df,df$pending),
        positive_48h_specimens=sum(df$positive),positive_48h_patients=n_person(df,df$positive),
        mismatch_specimens=sum(df$mismatch),mismatch_patients=n_person(df,df$mismatch))
      for (strategy in policies) {
        policy_rows[[length(policy_rows)+1L]] <- cbind(data.frame(era=era,scope=scope,strategy=strategy,
            transfers=denominator),policy_counts(df,strategy))
      }
    }
  }
  target <- events[events$mismatch,,drop=FALSE]
  patient_capture <- data.frame(pid=numeric(), dynamic=logical(), with_gram=logical())
  if (nrow(target)) {
    target$with_gram <- target$dynamic_mismatch | target$gram
    patient_capture <- stats::aggregate(target[c("dynamic_mismatch","with_gram")], list(pid=target$pid), any)
    names(patient_capture)[2] <- "dynamic"
  }
  restricted <- events[!events$added & events$pending, c("pid","era","positive","mismatch")]
  list(paired=patient_capture, restricted=restricted, shard=as.integer(shard), n_shards=as.integer(n_shards), cohort_n=sum(denominators$patients),
       era=do.call(rbind,era_rows), policy=do.call(rbind,policy_rows))
}
