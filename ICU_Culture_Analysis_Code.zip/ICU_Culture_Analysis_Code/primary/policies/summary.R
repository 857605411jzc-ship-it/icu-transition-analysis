summarize_policies <- function(parts, out) {
  bind <- function(key) do.call(rbind, lapply(parts, "[[", key))
  pool <- function(field, keys) {
    x <- bind(field)
    stats::aggregate(x[setdiff(names(x),keys)], x[keys], sum)
  }
  write_counts <- function(x, count_names, file) {
    x[count_names] <- lapply(x[count_names], report_count)
    utils::write.csv(x, file.path(out,file), row.names=FALSE, na="")
  }
  era <- pool("era", c("era","scope"))
  write_counts(era, setdiff(names(era), c("era","scope")), "cohort_by_era.csv")
  p <- pool("policy", c("era","scope","strategy"))
  counts <- setdiff(names(p), c("era","scope","strategy"))
  ratio <- function(n,N,scale=100) ifelse(n>=11 & N>=11, scale*n/N, NA_real_)
  ci <- function(n,N) {
    x <- proportion_table(n,N)
    x[n<11 | N<11, c("percent","lower95","upper95")] <- NA_real_
    x
  }
  person <- ci(p$mismatch_patients_captured,p$mismatch_patients)
  specimen <- ci(p$positive_captured,p$positive_specimens)
  p$distinct_reviews_per_100 <- ratio(p$reviews,p$transfers)
  p$review_occasions_per_100 <- ratio(p$review_occasions,p$transfers)
  p$reviews_per_patient_captured <- ratio(p$review_occasions,p$mismatch_patients_captured,1)
  p$patient_capture_percent <- person$percent
  p$patient_capture_lower95 <- person$lower95
  p$patient_capture_upper95 <- person$upper95
  p$positive_capture_percent <- specimen$percent
  p$positive_capture_lower95 <- specimen$lower95
  p$positive_capture_upper95 <- specimen$upper95
  write_counts(p, counts, "review_policies.csv")
  full <- subset(p, era=="all" & scope=="plus_exact_reflex")
  all_pending <- subset(full,strategy=="all_pending")
  dynamic <- subset(full,strategy=="dynamic")
  combined <- subset(full,strategy %in% c("gram_plus_dynamic","nonblood_gram_blood_plus_dynamic"))
  added <- combined$review_occasions-dynamic$review_occasions
  captures <- combined$mismatch_patients_captured-dynamic$mismatch_patients_captured
  marginal <- data.frame(strategy=combined$strategy,additional_reviews=added,additional_patients=captures,
                         reviews_per_additional_patient=ratio(added,captures,1))
  write_counts(marginal,c("additional_reviews","additional_patients"),"marginal_review_cost.csv")
  pair <- bind("paired")
  stopifnot(!anyDuplicated(pair$pid), sum(pair$dynamic)==dynamic$mismatch_patients_captured,
            sum(pair$with_gram)==combined$mismatch_patients_captured[combined$strategy=="gram_plus_dynamic"])
  lost <- sum(pair$dynamic & !pair$with_gram)
  gained <- sum(!pair$dynamic & pair$with_gram)
  discordant <- lost+gained
  probability <- if (!discordant) 1 else stats::binom.test(gained, discordant, 0.5)$p.value
  # A constituent policy is nested in its union; a loss is impossible by design.
  paired <- data.frame(both=report_count(sum(pair$dynamic & pair$with_gram)),
                       neither=report_count(sum(!pair$dynamic & !pair$with_gram)),
                       lost=if (!lost) "0" else report_count(lost), gained=report_count(gained),
                       exact_two_sided_p=if (discordant>=11) probability else NA_real_)
  utils::write.csv(paired,file.path(out,"paired_capture.csv"),row.names=FALSE,na="")
  N <- all_pending$reviews
  reviews <- dynamic$review_occasions
  targets <- c(dynamic$positive_specimens, dynamic$mismatch_specimens)
  hits <- c(dynamic$positive_captured, dynamic$mismatch_captured)
  random <- data.frame(endpoint=c("positive","discordance"),pending=N,review_budget=reviews,
    target_specimens=targets,expected_hits=ifelse(reviews>=11 & targets>=11, reviews*targets/N, NA_real_),
    random_capture_percent=ratio(reviews,N),observed_hits=hits,observed_capture_percent=ratio(hits,targets))
  write_counts(random,c("pending","review_budget","target_specimens","observed_hits"),"equal_budget_random.csv")
  restricted <- bind("restricted")
  q <- subset(p, scope=="frozen" & strategy=="gram")
  random <- list()
  for (i in seq_len(nrow(q))) {
    group <- q$era[i]
    x <- if (group=="all") restricted else restricted[restricted$era==group,,drop=FALSE]
    k <- q$reviews[i]
    n <- nrow(x)
    for (endpoint in c("mismatch","positive")) {
      m <- as.numeric(table(x$pid[x[[endpoint]]]))
      probability <- if(n && length(m)) 1-stats::dhyper(0,m,n-m,k) else numeric()
      random[[length(random)+1L]] <- data.frame(era=group,endpoint,quota=k,pending=n,
        target_specimens=sum(m),target_patients=length(m),
        expected_specimens=if(k>=11 && sum(m)>=11) k*sum(m)/n else NA_real_,
        expected_patients=if(k>=11 && length(m)>=11) sum(probability) else NA_real_)
    }
  }
  write_counts(do.call(rbind,random),c("quota","pending","target_specimens","target_patients"),
               "restricted_equal_quota_review.csv")
}
