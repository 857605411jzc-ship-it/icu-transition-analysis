summarize_prescribing <- function(parts,out) {
  data <- do.call(rbind,parts)
  stopifnot(!anyDuplicated(data[c("scope","analysis","pid","location")]))
  rates <- contrasts <- list()
  designs <- c("main","report_active_only","both_times","explicit_negative_only","no_other_recent_positive")
  data$value <- as.integer(data$reduced)
  fields <- c("metric","adjustment","eligible","ward_n","estimate","lower","upper","unit","status")
  for(scope in c("frozen","plus_exact_reflex")) {
    for(analysis in designs) {
      x <- data[data$scope==scope & data$analysis==analysis,,drop=FALSE]
      for(location in c("ICU","ward")) {
        z <- treatment_summary(x[x$location==location,,drop=FALSE],"stop_or_reduce_48h")
        rates[[length(rates)+1L]] <- cbind(scope,analysis,location,z)
      }
      for(adj in c("crude","adjusted")) {
        z <- location_contrast(x,"stop_or_reduce_48h",adj)
        contrasts[[length(contrasts)+1L]] <- cbind(scope,analysis,z[fields])
      }
    }
  }
  rates <- do.call(rbind,rates)
  contrasts <- do.call(rbind,contrasts)
  f <- c("prescribing_rates.csv","prescribing_contrasts.csv")
  utils::write.csv(rates,file.path(out,f[1]),row.names=FALSE,na="")
  utils::write.csv(contrasts,file.path(out,f[2]),row.names=FALSE,na="")
  f
}
