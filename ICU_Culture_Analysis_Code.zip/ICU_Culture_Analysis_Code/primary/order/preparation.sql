CREATE TEMP TABLE clinical_dot_positive_reports AS
SELECT s.*,s.final_time AS report_time,
 CASE WHEN s.final_time>s.tm THEN 'ward' ELSE 'ICU' END AS phase
FROM culture_spec s WHERE s.outcome_class='positive' AND s.final_time IS NOT NULL AND s.final_time<s.hospital_end
 AND ((s.pending AND s.final_time>s.tm AND s.final_time<=s.tm+INTERVAL '72 hours')
      OR s.pre_handoff_48);

CREATE TEMP TABLE clinical_dot_tested AS
SELECT r.pid,r.hid,r.specimen,a.isolate_key,d.agent,
 CASE WHEN count(DISTINCT upper(a.interpretation))=1 THEN min(upper(a.interpretation)) ELSE 'conflict' END AS sir
FROM clinical_dot_positive_reports r JOIN culture_ast a USING(pid,hid,specimen) JOIN susceptibility_transition_drugs d ON d.name=culture_name(a.antibiotic)
WHERE a.ast_time<=r.report_time AND d.agent IS NOT NULL AND upper(a.interpretation) IN ('S','I','R')
GROUP BY r.pid,r.hid,r.specimen,a.isolate_key,d.agent;

CREATE TEMP TABLE clinical_dot_iso_profile AS
WITH isolates AS (
 SELECT i.*,r.report_time,r.sterile,r.era_lower,r.tm,r.hospital_end,r.ward_end,r.phase,
    r.has_unknown_label
 FROM clinical_dot_positive_reports r JOIN culture_iso i USING(pid,hid,specimen)
 WHERE r.outcome_class='positive' AND i.first_org_time<=r.report_time
), phenotype AS (
 SELECT i.pid,i.hid,i.specimen,i.isolate_key,
   bool_or(t.sir='S' AND t.agent IN ('cefoxitin','oxacillin')) AS meth_s,
   bool_or(t.sir IN ('I','R','conflict') AND t.agent IN ('cefoxitin','oxacillin')) AS meth_ns,
   bool_or(t.sir='S' AND t.agent='ampicillin') AS amp_s,
   bool_or(t.sir='S' AND t.agent='ceftriaxone') AS cro_s,
   count(DISTINCT t.agent) FILTER(WHERE t.sir IN ('R','I','conflict') AND t.agent IN ('ertapenem','meropenem','imipenem','cefepime')) AS beta_warning,
   count(DISTINCT t.agent) FILTER(WHERE t.sir IN ('R','I','conflict') AND t.agent IN ('meropenem','imipenem','cefepime','ceftazidime','piperacillin_tazobactam','aztreonam')) AS pa_warning,
   count(DISTINCT t.agent) FILTER(WHERE t.sir IN ('R','I','conflict') AND t.agent IN ('micafungin','caspofungin','anidulafungin')) AS echino_warning
 FROM isolates i LEFT JOIN clinical_dot_tested t USING(pid,hid,specimen,isolate_key)
 GROUP BY i.pid,i.hid,i.specimen,i.isolate_key
)
SELECT i.*,p.* EXCLUDE(pid,hid,specimen,isolate_key),
 i.organism_category='staph_aureus' AND NOT i.is_mrsa AND coalesce(p.meth_s,false) AND NOT coalesce(p.meth_ns,false) AS mssa,
 (i.organism_category='yeast_fungus') AS fungal,
 regexp_matches(i.organism,'^(ESCHERICHIA COLI|KLEBSIELLA PNEUMONIAE|KLEBSIELLA OXYTOCA|PROTEUS MIRABILIS)($|[^A-Z])') AS common_enteric,
 regexp_matches(i.organism,'^(ENTEROBACTER CLOACAE|KLEBSIELLA AEROGENES|ENTEROBACTER AEROGENES|CITROBACTER FREUNDII|HAFNIA ALVEI)($|[^A-Z])') AS ampc_risk,
 regexp_matches(i.organism,'^PSEUDOMONAS AERUGINOSA($|[^A-Z])') AS pa,
 regexp_matches(i.organism,'^ENTEROCOCCUS FAECALIS($|[^A-Z])') AS efaecalis,
 regexp_matches(i.organism,'^(STREPTOCOCCUS PYOGENES|GROUP A STREPTOCOCCUS)($|[^A-Z])') AS gas,
 CASE WHEN i.clinical_class IN ('possible_contamination','nonsterile_candida_only') THEN 'low'
      WHEN i.clinical_class NOT IN ('reported_isolate','repeat_commensal') OR i.label_conflict
           OR (i.organism_category='yeast_fungus' AND NOT i.sterile) THEN 'unknown'
      ELSE 'eligible' END AS target_type
FROM isolates i JOIN phenotype p USING(pid,hid,specimen,isolate_key);

CREATE TEMP TABLE clinical_dot_activity AS
WITH candidates AS (
 SELECT DISTINCT agent,family FROM culture_drug_patterns WHERE family<>'local'
), matrix AS (
 SELECT i.*,d.agent,d.family,t.sir,
   CASE
    WHEN i.ampc_risk AND i.site_group<>'urine' AND d.agent IN ('ceftriaxone','ceftazidime','cefotaxime') THEN 'ampc_invasive_site'
    WHEN d.agent IN ('nitrofurantoin','fosfomycin') THEN 'lower_urinary_indication_unverified'
    WHEN d.agent='daptomycin' AND i.site_group='respiratory' THEN 'respiratory_daptomycin'
    WHEN d.agent IN ('rifampin','rifabutin') THEN 'adjunct_only'
    WHEN i.organism_category='enterococcus' AND d.agent IN ('gentamicin','streptomycin','amikacin','tobramycin') THEN 'adjunct_only'
    WHEN i.site_group='csf' AND d.agent NOT IN ('meropenem','cefepime','ceftazidime','ceftriaxone','cefotaxime','vancomycin','oxacillin','nafcillin','ampicillin','penicillin_g','trimethoprim_sulfamethoxazole','linezolid') THEN 'cns_exposure_unverified'
    WHEN i.fungal AND i.site_group='csf' THEN 'cns_fungal_evaluation'
    WHEN i.site_group='blood' AND i.organism_category='staph_aureus' AND d.agent IN ('linezolid','clindamycin','doxycycline','gentamicin','erythromycin','azithromycin','ciprofloxacin','levofloxacin') THEN 'bloodstream_indication_unverified'
    ELSE NULL END AS site_guard,
   CASE
    WHEN i.is_mrsa AND d.agent IN ('oxacillin','nafcillin','dicloxacillin','cefazolin','ceftriaxone','cefepime','cefotaxime','meropenem','imipenem','ertapenem','piperacillin_tazobactam','ampicillin_sulbactam','amoxicillin_clavulanate','cephalexin','cefuroxime','cefoxitin') THEN 'MRSA_standard_beta_lactam'
    WHEN i.organism_category='enterococcus' AND d.agent IN ('cefazolin','ceftriaxone','cefepime','ceftazidime','cefotaxime','cefuroxime','cefoxitin','cephalexin','cefpodoxime','cefdinir','ertapenem') THEN 'enterococcus_no_standalone_activity'
    WHEN i.pa AND d.agent IN ('ceftriaxone','ertapenem','cefazolin','cefotaxime','ampicillin','amoxicillin','amoxicillin_clavulanate','ampicillin_sulbactam','cefuroxime','cephalexin') THEN 'pseudomonas_off_spectrum'
    WHEN i.organism_category IN ('enterobacterales','pseudomonas','acinetobacter') AND d.agent IN ('vancomycin','linezolid','daptomycin','nafcillin','oxacillin','clindamycin','metronidazole') THEN 'aerobic_GNR_off_spectrum'
    WHEN i.organism_category IN ('staph_aureus','enterococcus','streptococcus') AND d.agent IN ('aztreonam','metronidazole') THEN 'aerobic_GPC_off_spectrum'
    ELSE NULL END AS inactive_rule,
   CASE
    WHEN i.mssa AND d.agent IN ('nafcillin','oxacillin','cefazolin','ceftriaxone','cefepime','cefotaxime','cefuroxime','piperacillin_tazobactam','ampicillin_sulbactam','amoxicillin_clavulanate','meropenem','imipenem','ertapenem') THEN 'MSSA_methicillin_surrogate'
    WHEN i.efaecalis AND i.amp_s AND d.agent IN ('amoxicillin','ampicillin_sulbactam','amoxicillin_clavulanate','piperacillin_tazobactam') THEN 'E_faecalis_ampicillin_surrogate'
    ELSE NULL END AS surrogate_rule,
   CASE
    WHEN i.common_enteric AND i.cro_s AND i.beta_warning <= CASE WHEN t.sir IN ('I','R','conflict') AND d.agent IN ('ertapenem','meropenem','imipenem','cefepime') THEN 1 ELSE 0 END AND d.agent IN ('meropenem','imipenem','ertapenem','cefepime','cefotaxime') THEN 'common_enteric_CRO_S_broader_beta_lactam'
    WHEN i.organism_category='staph_aureus' AND d.agent='vancomycin' THEN 'S_aureus_vancomycin'
    WHEN i.organism_category='staph_aureus' AND d.agent='linezolid' AND i.site_group='respiratory' THEN 'S_aureus_respiratory_linezolid'
    WHEN i.organism_category='staph_aureus' AND d.agent='daptomycin' AND i.site_group='blood' THEN 'S_aureus_blood_daptomycin'
    WHEN i.pa AND i.pa_warning <= CASE WHEN t.sir IN ('I','R','conflict') AND d.agent IN ('meropenem','imipenem','cefepime','ceftazidime','piperacillin_tazobactam','aztreonam') THEN 1 ELSE 0 END AND d.agent IN ('ceftazidime','cefepime','meropenem','imipenem','piperacillin_tazobactam') THEN 'P_aeruginosa_empiric_antipseudomonal'
    WHEN i.gas AND d.agent IN ('penicillin_g','ampicillin','amoxicillin') THEN 'GAS_penicillin_class'
    WHEN regexp_matches(i.organism,'^CANDIDA (ALBICANS|TROPICALIS)($|[^A-Z])') AND i.sterile AND i.site_group<>'csf'
     AND i.echino_warning <= CASE WHEN t.sir IN ('I','R','conflict') AND d.agent IN ('micafungin','caspofungin','anidulafungin') THEN 1 ELSE 0 END AND d.agent IN ('anidulafungin','caspofungin','micafungin') THEN 'sterile_Candida_expected_echinocandin'
    ELSE NULL END AS expected_rule
 FROM clinical_dot_iso_profile i CROSS JOIN candidates d LEFT JOIN clinical_dot_tested t
 ON t.pid=i.pid AND t.hid=i.hid AND t.specimen=i.specimen AND t.isolate_key=i.isolate_key AND t.agent=d.agent
), ruled AS (
 SELECT *,CASE
  WHEN target_type<>'eligible' AND NOT (fungal AND clinical_class='reported_isolate' AND NOT label_conflict) THEN 'uncertain_identity_or_indication'
  WHEN sir='conflict' THEN 'uncertain_conflicting_AST'
  WHEN sir='R' THEN 'inactive_direct_R' WHEN sir='I' THEN 'inactive_direct_I'
  WHEN (fungal AND family<>'antifungal') OR (NOT fungal AND family='antifungal') THEN 'inactive_wrong_class'
  WHEN sir='S' AND inactive_rule IS NOT NULL THEN 'uncertain_discordant_phenotype'
  WHEN site_guard IS NOT NULL THEN 'uncertain_site_or_role'
  WHEN sir='S' THEN 'active_direct'
  WHEN inactive_rule IS NOT NULL THEN 'inactive_intrinsic'
  WHEN surrogate_rule IS NOT NULL THEN 'active_surrogate'
  WHEN expected_rule IS NOT NULL THEN 'active_expected'
  ELSE 'uncertain_untested' END AS activity
 FROM matrix
)
SELECT pid,hid,specimen,isolate_key,agent,family,sir,activity,inactive_rule,surrogate_rule,expected_rule,site_guard,
 activity IN ('active_direct','active_surrogate','active_expected') AS is_active,
 activity IN ('active_direct','active_surrogate') AS strict_active,
 starts_with(activity,'inactive_') AS is_inactive,
 (activity IN ('active_direct','active_surrogate') AND site_group<>'csf' AND
  ((mssa AND agent IN ('cefazolin','nafcillin','oxacillin')) OR
   (organism_category='enterococcus' AND amp_s AND agent='ampicillin') OR
   (common_enteric AND cro_s AND agent='ceftriaxone'))) AS narrow_option
FROM ruled;

-- A restricted regimen is represented by the ingredient count and three spectrum dimensions.
-- The dictionary is fixed before comparing report locations; one combination ingredient counts once.
CREATE TEMP TABLE review_dot_agents AS
SELECT agent, CASE WHEN category='mrsa' THEN 1 ELSE 0 END AS mrsa,
 CASE WHEN category IN ('ap','ap_carb') THEN 1 ELSE 0 END AS ap,
 CASE WHEN category IN ('carb','ap_carb') THEN 1 ELSE 0 END AS carb
FROM (VALUES
 ('vancomycin','mrsa'),('linezolid','mrsa'),('daptomycin','mrsa'),('tedizolid','mrsa'),
 ('ceftaroline','mrsa'),('telavancin','mrsa'),
 ('piperacillin_tazobactam','ap'),('cefepime','ap'),('ceftazidime','ap'),('aztreonam','ap'),
 ('ceftazidime_avibactam','ap'),('ceftolozane_tazobactam','ap'),('cefiderocol','ap'),
 ('ciprofloxacin','ap'),('levofloxacin','ap'),('gentamicin','ap'),('amikacin','ap'),
 ('tobramycin','ap'),('colistin','ap'),('polymyxin_b','ap'),('ertapenem','carb'),
 ('meropenem','ap_carb'),('imipenem','ap_carb'),('doripenem','ap_carb'),
 ('meropenem_vaborbactam','ap_carb'),('imipenem_relebactam','ap_carb')
) a(agent,category);

CREATE TEMP TABLE review_dot_normal AS
SELECT pid,hid,specimen
FROM culture_work_rows
GROUP BY pid,hid,specimen
HAVING bool_and(row_class IN ('flora','no_growth','null_no_growth'))
 AND count(*) FILTER (WHERE row_class='flora')>0
 AND bool_and(row_class<>'flora' OR
  (regexp_matches(coalesce(organism,'')||' '||coalesce(annotation,''),
   '(^|[^A-Z])(NORMAL|USUAL) ((RESPIRATORY|UROGENITAL|ORAL|SKIN|ENTERIC|BACTERIAL|VAGINAL|UPPER RESPIRATORY) )*FLORA([^A-Z]|$)')
   AND NOT regexp_matches(coalesce(organism,'')||' '||coalesce(annotation,''),
   '(NO|ABSENCE OF) (NORMAL|USUAL)|MIXED|PREDOMINANT|PATHOGEN')));

CREATE TEMP TABLE review_dot_narrow AS
WITH target AS (
 SELECT pid,hid,specimen,isolate_key,
   bool_or(narrow_option AND activity='active_direct' AND sir='S') AS tested
 FROM clinical_dot_activity GROUP BY pid,hid,specimen,isolate_key
)
SELECT i.pid,i.hid,i.specimen FROM culture_iso i
LEFT JOIN target t USING(pid,hid,specimen,isolate_key)
WHERE i.clinical_class NOT IN ('possible_contamination','nonsterile_candida_only')
GROUP BY i.pid,i.hid,i.specimen
HAVING bool_and(coalesce(t.tested,false) AND i.clinical_class IN ('reported_isolate','repeat_commensal'));

CREATE TEMP VIEW clinical_dot_spec_by_scope AS
SELECT s.*,q.scope FROM culture_spec s CROSS JOIN (VALUES ('frozen'),('plus_exact_reflex')) q(scope)
WHERE q.scope='plus_exact_reflex' OR NOT EXISTS (
 SELECT 1 FROM reflex_keys k WHERE k.pid=s.pid AND k.hid=s.hid AND k.specimen=s.specimen);
CREATE TEMP TABLE review_dot_reports AS
WITH r AS (
 SELECT s.scope,s.pid,s.hid,s.specimen,s.tm,s.final_time AS t,s.hospital_end,s.site_group,s.collected,
   CASE WHEN s.outcome_class='no_growth' THEN 'no_growth'
     WHEN s.outcome_class='mixed_flora' AND f.specimen IS NOT NULL THEN 'normal_flora'
     WHEN s.outcome_class='positive' AND a.specimen IS NOT NULL AND NOT s.has_unknown_label
       AND NOT s.has_uncertain_isolate AND NOT s.has_uninterpretable THEN 'direct_narrow_S' END AS result
 FROM clinical_dot_spec_by_scope s LEFT JOIN review_dot_normal f USING(pid,hid,specimen)
 LEFT JOIN review_dot_narrow a USING(pid,hid,specimen)
 WHERE (s.pre_handoff_48 OR s.post_handoff_48) AND s.final_time<>s.tm AND s.final_time<s.hospital_end
), located AS (
 SELECT r.*,l.unit_category FROM r JOIN loc l ON l.pid=r.pid AND l.hid=r.hid
 AND l.began<=r.t AND (l.ended>r.t OR l.ended IS NULL) WHERE result IS NOT NULL
 QUALIFY count(*) OVER(PARTITION BY r.scope,r.pid,r.hid,r.specimen)=1 AND l.ended IS NOT NULL
)
SELECT r.*,CASE WHEN t<tm THEN 'ICU' ELSE 'ward' END AS location,
 EXISTS(SELECT 1 FROM clinical_dot_spec_by_scope s WHERE s.scope=r.scope AND s.pid=r.pid AND s.hid=r.hid AND s.specimen<>r.specimen
   AND s.final_time BETWEEN r.t-INTERVAL '48 hours' AND r.t AND s.outcome_class='positive'
   AND NOT EXISTS(SELECT 1 FROM review_dot_narrow a WHERE a.pid=s.pid AND a.hid=s.hid AND a.specimen=s.specimen))
   AS other_positive
FROM located r
WHERE (t<tm AND unit_category='ICU') OR (t>tm AND unit_category IN ('Medical','Surgical','Mixed or specialty'));

CREATE TEMP TABLE review_dot_hosp AS SELECT DISTINCT pid,hid FROM review_dot_reports;

CREATE TEMP TABLE review_dot_rx AS
WITH pharm AS (
 SELECT h.pid,h.hid,try_cast(p.pharmacy_id AS BIGINT) AS pharmacy_id,
  CASE WHEN count(DISTINCT try_cast(p.entertime AS TIMESTAMP))=1 THEN min(try_cast(p.entertime AS TIMESTAMP)) END AS entered,
  CASE WHEN count(DISTINCT nullif(culture_name(p.route),''))=1 THEN min(nullif(culture_name(p.route),'')) END AS route
 FROM src_pharmacy p JOIN review_dot_hosp h ON try_cast(p.subject_id AS BIGINT)=h.pid AND try_cast(p.hadm_id AS BIGINT)=h.hid
 WHERE try_cast(p.pharmacy_id AS BIGINT) IS NOT NULL GROUP BY h.pid,h.hid,try_cast(p.pharmacy_id AS BIGINT)
)
SELECT DISTINCT r.pid,r.hid,r.started,r.stopped,n.agent,p.entered,culture_route_kind(coalesce(nullif(r.route,''),p.route),n.agent,r.name) AS route
FROM culture_r0 r JOIN review_dot_hosp h USING(pid,hid) JOIN susceptibility_transition_drugs n USING(name)
JOIN review_dot_agents a USING(agent) LEFT JOIN pharm p USING(pid,hid,pharmacy_id)
WHERE r.started IS NOT NULL AND (r.stopped IS NULL OR r.stopped>=r.started)
 AND NOT regexp_matches(r.name,'TROUGH|PEAK|RANDOM LEVEL|PLACEHOLDER|DOSING BY PHARMACY|PHARMACY TO DOSE');

CREATE TEMP TABLE review_dot_clock AS
WITH clocks AS (SELECT pid,hid,t FROM review_dot_reports UNION SELECT pid,hid,tm FROM review_dot_reports)
SELECT *,row_number() OVER(ORDER BY pid,hid,t) AS clock_id FROM clocks;

CREATE TEMP TABLE review_dot_broad_at AS
SELECT DISTINCT c.clock_id,'order' AS channel,r.agent FROM review_dot_clock c JOIN review_dot_rx r
 ON r.pid=c.pid AND r.hid=c.hid AND r.started<=c.t AND r.stopped>c.t AND r.route='systemic'
 AND (r.entered IS NULL OR r.entered<=c.t);

CREATE TEMP TABLE review_dot_reg AS
SELECT b.clock_id,b.channel,count(*) AS n,max(a.mrsa) AS mrsa,max(a.ap) AS ap,max(a.carb) AS carb
FROM review_dot_broad_at b JOIN review_dot_agents a USING(agent) GROUP BY b.clock_id,b.channel;

CREATE TEMP TABLE review_dot_eligible AS
SELECT r.*,b.channel,b.n,b.mrsa,b.ap,b.carb,
 coalesce(z.n,0)>0 AS broad_at_transfer,c.clock_id AS report_id,k.clock_id AS transfer_id
FROM review_dot_reports r JOIN review_dot_clock c ON c.pid=r.pid AND c.hid=r.hid AND c.t=r.t
JOIN review_dot_clock k ON k.pid=r.pid AND k.hid=r.hid AND k.t=r.tm
JOIN review_dot_reg b ON b.clock_id=c.clock_id LEFT JOIN review_dot_reg z ON z.clock_id=k.clock_id AND z.channel=b.channel;
