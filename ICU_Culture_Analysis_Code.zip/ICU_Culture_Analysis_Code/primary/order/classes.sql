-- All three comparisons use the first qualifying report in the symmetric broad-order cohort.
-- Drug sets are disjoint, but patients on combination therapy may enter several denominators.
CREATE TEMP TABLE response_ingredient_class AS
SELECT agent,
 CASE WHEN mrsa=1 THEN 'anti_MRSA'
      WHEN carb=1 THEN 'carbapenem'
      WHEN agent IN ('piperacillin_tazobactam','cefepime','ceftazidime','aztreonam',
                     'ceftazidime_avibactam','ceftolozane_tazobactam','cefiderocol') THEN 'antipseudomonal_noncarbapenem_beta_lactam' END AS drug_group
FROM review_dot_agents;

CREATE TEMP TABLE response_targeted_orders AS
WITH start_counts AS (
 SELECT b.clock_id AS report_id,a.drug_group,count(DISTINCT b.agent) AS baseline_in_class
 FROM review_dot_broad_at b JOIN response_ingredient_class a USING(agent)
 WHERE b.channel='order' AND a.drug_group IS NOT NULL GROUP BY b.clock_id,a.drug_group
), follow_counts AS (
 SELECT c.report_id,a.drug_group,count(DISTINCT r.agent) AS remaining_in_class
 FROM review_dot_index_clock c JOIN review_dot_rx r ON r.pid=c.pid AND r.hid=c.hid
 AND r.started<=c.t+INTERVAL '48 hours' AND r.stopped>c.t+INTERVAL '48 hours'
 AND r.route='systemic' AND (r.entered IS NULL OR r.entered<=c.t+INTERVAL '48 hours')
 JOIN response_ingredient_class a USING(agent) WHERE a.drug_group IS NOT NULL
 GROUP BY c.report_id,a.drug_group
)
SELECT p.*,g.drug_group,g.baseline_in_class,coalesce(f.remaining_in_class,0) AS remaining_in_class,
 k.mrsa<=i.mrsa AND k.ap<=i.ap AND k.carb<=i.carb AS no_new_spectrum,
 p.reduced AND coalesce(f.remaining_in_class,0)<g.baseline_in_class AS class_deescalated,
 coalesce(f.remaining_in_class,0)=0 AS class_discontinued
FROM therapy_rx_person p
JOIN review_dot_index i USING(scope,analysis,pid,hid,channel,location,specimen,t)
JOIN review_dot_order_change k USING(report_id) JOIN start_counts g USING(report_id)
LEFT JOIN follow_counts f ON g.report_id=f.report_id AND g.drug_group=f.drug_group
WHERE p.stop_obs AND p.analysis='report_active_only';
