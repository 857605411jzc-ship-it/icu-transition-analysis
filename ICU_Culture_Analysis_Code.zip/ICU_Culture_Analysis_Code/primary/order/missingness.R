# Bound the ward-minus-ICU contrast among patients still in hospital 48 hours after reporting.
summarize_missing_doses <- function(parts, out) {
  d <- do.call(rbind, parts)
  d <- d[d$flow != "hospital_exit_by_48h", , drop=FALSE]
  counts <- function(location) {
    a <- d[d$location == location, , drop=FALSE]
    observed <- a$flow == "evaluable"
    c(total=nrow(a), reduced=sum(a$reduced[observed]), missing=sum(!observed))
  }
  ward <- counts("ward")
  icu <- counts("ICU")
  wn <- unname(c(ward["reduced"], ward["reduced"] + ward["missing"]))
  cn <- unname(c(icu["reduced"] + icu["missing"], icu["reduced"]))
  W <- unname(ward["total"])
  C <- unname(icu["total"])
  supported <- W >= 11 & C >= 11 & wn >= 11 & cn >= 11 & W-wn >= 11 & C-cn >= 11
  difference <- ifelse(supported, 100 * (wn/W - cn/C), NA_real_)
  tab <- data.frame(scenario=c("Ward none / ICU all missing reduced", "Ward all / ICU none missing reduced"),
                    ward_reduced=report_count(wn), ward_N=report_count(W),
                    ICU_reduced=report_count(cn), ICU_N=report_count(C),
                    ward_minus_ICU_percentage_points=difference)
  utils::write.csv(tab, file.path(out, "missing_administration_bounds.csv"), row.names=FALSE, na="")
}
