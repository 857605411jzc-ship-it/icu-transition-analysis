order_partition <- function(con,module) {
  for(file in c('selection.sql','followup.sql','classes.sql'))
    execute_sql(con,file.path(module,file))
  main <- DBI::dbGetQuery(con,"SELECT * FROM therapy_rx_person WHERE stop_obs")
  classes <- DBI::dbGetQuery(con,"SELECT * FROM response_targeted_orders")
  stopifnot(!anyDuplicated(main[c('analysis','pid','location')]),
            !anyDuplicated(classes[c('pid','location','drug_group')]),
            all(classes$baseline_in_class>0),all(!classes$class_deescalated | classes$reduced),
            all(main$scope=='plus_exact_reflex'),all(main$channel=='order'))
  list(main=main,classes=classes)
}

summarize_orders <- function(parts,out,transfer_count) {
  bind <- function(field) do.call(rbind,lapply(parts,'[[',field))
  d <- bind('main')
  classes <- bind('classes')
  stopifnot(!anyDuplicated(d[c("analysis","pid","location")]),
            !anyDuplicated(classes[c("pid","location","drug_group")]))
  ward_reports <- subset(d, analysis=="report_active_only" & location=="ward")
  stopifnot(!anyDuplicated(ward_reports$pid), transfer_count>=nrow(ward_reports))
  opportunities <- nrow(ward_reports)
  review <- data.frame(scope="plus_exact_reflex", ward_reports=report_count(opportunities),
    eligible_transfers=report_count(transfer_count),
    opportunities_per_100_transfers=if (opportunities>=11L) 100*opportunities/transfer_count else NA_real_)
  utils::write.csv(review,file.path(out,"ward_review_opportunities.csv"),row.names=FALSE,na="")
  rates <- effects <- list()
  save_summary <- function(z,group,endpoint,response) {
    if(anyNA(z[[response]]) || !all(z[[response]] %in% c(0,1))) stop('Missing or invalid observed order endpoint')
    z$value <- as.integer(z[[response]])
    for(loc in c('ICU','ward')) {
      row <- treatment_summary(z[z$location==loc,,drop=FALSE],'stop_or_reduce_48h')
      row$metric <- NULL
      rates[[length(rates)+1L]] <<- cbind(scope='plus_exact_reflex',group,endpoint,location=loc,row)
    }
    for(adj in c('crude','adjusted')) {
      fit <- location_contrast(z,'stop_or_reduce_48h',adj)
      effects[[length(effects)+1L]] <<- cbind(scope='plus_exact_reflex',group,endpoint,
        fit[c('adjustment','eligible','ward_n','estimate','lower','upper','unit','status')])
    }
  }
  for(a in c('report_active_only','negative_at_report','negative_through_endpoint'))
    save_summary(d[d$analysis==a,,drop=FALSE],a,'any_broad_deescalation','reduced')
  for(a in c('anti_MRSA','antipseudomonal_noncarbapenem_beta_lactam','carbapenem')) {
    g <- classes[classes$drug_group==a,,drop=FALSE]
    save_summary(g,a,'class_reduction_with_overall_deescalation','class_deescalated')
    save_summary(g,a,'all_orders_in_class_stopped','class_discontinued')
    save_summary(g,a,'any_broad_deescalation','reduced')
  }
  dest <- c('order_rates.csv','order_differences.csv')
  utils::write.csv(do.call(rbind,rates),file.path(out,dest[1]),row.names=FALSE,na='')
  utils::write.csv(do.call(rbind,effects),file.path(out,dest[2]),row.names=FALSE,na='')
  c(dest,"ward_review_opportunities.csv")
}
