CREATE TEMP TABLE review_dot_index_clock AS
SELECT DISTINCT i.report_id,i.pid,i.hid,i.t,i.hospital_end
FROM review_dot_index i;

CREATE TEMP TABLE review_dot_order_change AS
WITH frame AS (
 SELECT c.*,c.t+INTERVAL '48 hours' AS end48 FROM review_dot_index_clock c
), regimen AS (
 SELECT c.report_id,count(DISTINCT r.agent) AS n,coalesce(max(a.mrsa),0) AS mrsa,
   coalesce(max(a.ap),0) AS ap,coalesce(max(a.carb),0) AS carb
 FROM frame c LEFT JOIN review_dot_rx r ON r.pid=c.pid AND r.hid=c.hid AND r.started<=c.end48
   AND r.stopped>c.end48 AND r.route='systemic' AND (r.entered IS NULL OR r.entered<=c.end48)
 LEFT JOIN review_dot_agents a USING(agent) GROUP BY c.report_id
)
SELECT c.report_id,k.n,k.mrsa,k.ap,k.carb,
   EXISTS(SELECT 1 FROM review_dot_rx r WHERE r.pid=c.pid AND r.hid=c.hid AND r.started<=c.end48
       AND (r.entered IS NULL OR r.entered<=c.end48) AND (r.stopped IS NULL
           OR (r.route='uncertain' AND (r.stopped>c.t OR r.stopped IS NULL)))
       AND r.route IN ('systemic','uncertain')) AS uncertain_order,
   EXISTS(SELECT 1 FROM culture_r0 r WHERE r.pid=c.pid AND r.hid=c.hid AND r.started<=c.end48
     AND r.stopped>c.end48-INTERVAL '12 hours' AND r.stopped>r.started) AS order_observed
FROM frame c JOIN regimen k USING(report_id);
CREATE TEMP TABLE therapy_rx_person AS
SELECT i.scope,i.analysis,i.pid,i.hid,i.location,i.channel,i.t,i.specimen,i.result,i.site_group AS site,
 c.age_at_exit AS age,p.sex,
 CASE WHEN c.era_upper<=2019 THEN 'early' WHEN c.era_lower>=2020 THEN 'late' ELSE 'crossing' END AS era,
 greatest(0,epoch(i.t-c.icu_in)/86400.0) AS days_since_icu_entry,
 epoch(i.t-i.collected)/3600 AS specimen_age_hours,i.n AS baseline_agents,i.mrsa,i.ap,i.carb,i.other_positive,
 i.channel='order' AND c.hospital_end>i.t+INTERVAL '48 hours' AND k.order_observed AND NOT k.uncertain_order AS stop_obs,
 (k.mrsa<=i.mrsa AND k.ap<=i.ap AND k.carb<=i.carb AND
  (k.mrsa<i.mrsa OR k.ap<i.ap OR k.carb<i.carb OR k.n<i.n)) AS reduced,
 i.hospital_end>=(cast(i.t AS DATE)+8)::TIMESTAMP AS seven_complete_dates
FROM review_dot_index i JOIN cohort c USING(pid,hid) JOIN clinical_demographics p USING(pid)
JOIN review_dot_order_change k USING(report_id);
