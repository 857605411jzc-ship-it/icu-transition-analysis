-- report, and for ward reports also at ICU exit). Follow-up plays no role here.
CREATE TEMP TABLE response_dot_broad_given AS
SELECT c.clock_id,e.agent FROM review_dot_clock c
JOIN culture_em e ON e.pid=c.pid AND e.hid=c.hid AND e.at_time>=c.t-INTERVAL '24 hours'
 AND e.at_time<c.t AND e.recorded<=c.t AND e.route_kind='systemic'
JOIN review_dot_agents a USING(agent)
WHERE NOT regexp_matches(e.name,'TROUGH|PEAK|RANDOM LEVEL|PLACEHOLDER|DOSING BY PHARMACY|PHARMACY TO DOSE')
GROUP BY c.clock_id,e.agent;

CREATE TEMP TABLE response_dot_dose_reg AS
SELECT b.clock_id,count(*) AS baseline_agents,max(a.mrsa) AS mrsa,max(a.ap) AS ap,max(a.carb) AS carb
FROM response_dot_broad_given b JOIN review_dot_agents a USING(agent) GROUP BY b.clock_id;

CREATE TEMP TABLE response_dot_index AS
WITH enrolled AS (
 SELECT r.*,b.baseline_agents,b.mrsa,b.ap,b.carb,c.age_at_exit AS age,
 CASE WHEN c.era_upper<=2019 THEN 'early' WHEN c.era_lower>=2020 THEN 'late' ELSE 'crossing' END AS era,
 greatest(0,epoch(r.t-c.icu_in)/86400.0) AS days_since_icu_entry,
 epoch(r.t-r.collected)/3600 AS specimen_age_hours
 FROM review_dot_reports r JOIN cohort c USING(pid,hid)
 JOIN review_dot_clock report ON report.pid=r.pid AND report.hid=r.hid AND report.t=r.t
 JOIN review_dot_clock exit_clock ON exit_clock.pid=r.pid AND exit_clock.hid=r.hid AND exit_clock.t=r.tm
 JOIN response_dot_dose_reg b ON b.clock_id=report.clock_id
 LEFT JOIN response_dot_dose_reg at_exit ON at_exit.clock_id=exit_clock.clock_id
 WHERE r.location='ICU' OR at_exit.clock_id IS NOT NULL
 QUALIFY row_number() OVER(PARTITION BY r.scope,r.pid,r.hid,r.location
 ORDER BY r.t,CASE r.result WHEN 'direct_narrow_S' THEN 1 WHEN 'normal_flora' THEN 2 ELSE 3 END,r.specimen)=1
)
SELECT pid,hid,scope,'main' AS analysis,location,t,hospital_end,specimen,age,'unknown' AS sex,era,site_group AS site,
 result,days_since_icu_entry,specimen_age_hours,baseline_agents,mrsa,ap,carb,other_positive,
 hospital_end>=(cast(t AS DATE)+8)::TIMESTAMP AS seven_complete_dates
FROM enrolled;
