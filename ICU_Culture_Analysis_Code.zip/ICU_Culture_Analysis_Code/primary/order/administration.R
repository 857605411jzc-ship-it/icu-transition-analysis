dose_partition <- function(con,module) {
  execute_sql(con,file.path(module,'dose.sql'))
  d <- DBI::dbGetQuery(con,"SELECT * FROM therapy_dose_people")
  stopifnot(!anyDuplicated(d[c("pid","location")]),all(d$baseline_agents>=1L),
            all(!d$no_broad | d$reduced),all(d$location %in% c("ICU","ward")))
  d
}

summarize_doses <- function(parts,out) {
  d <- do.call(rbind,parts)
  stopifnot(!anyDuplicated(d[c("pid","location")]))
  scope <- "plus_exact_reflex"
  design <- "report_active_only_symmetric_24h"
  reasons <- c("hospital_exit_by_48h","incomplete_eMAR_documentation","ambiguous_agent_or_route","evaluable")
  stopifnot(all(d$flow %in% reasons))
  flow <- rates <- contrasts <- list()
  for(loc in c("ICU","ward")) {
    m <- d[d$location==loc,,drop=FALSE]
    flow[[loc]] <- data.frame(scope,design,location=loc,stage=c("indexed",reasons),
        n=report_count(c(nrow(m),vapply(reasons,function(stage) sum(m$flow==stage),integer(1)))))
    m <- m[m$flow=="evaluable",,drop=FALSE]
    counts <- list(reduced_dose_spectrum_final24h=m$reduced,no_broad_dose_final24h=m$no_broad,
                   any_broad_dose_final24h=!m$no_broad)
    for(metric in names(counts)) {
      m$value <- as.integer(counts[[metric]])
      rates[[length(rates)+1L]] <- cbind(scope,design,location=loc,treatment_summary(m,metric))
    }
  }
  m <- d[d$flow=="evaluable",,drop=FALSE]
  m$value <- as.integer(m$reduced)
  keep <- c("metric","adjustment","eligible","ward_n","estimate","lower","upper","unit","status")
  for(adj in c("crude","adjusted")) {
    z <- location_contrast(m,"reduced_dose_spectrum_final24h",adj)
    contrasts[[adj]] <- cbind(scope,design,z[keep])
  }
  tables <- list(administration_flow=flow,administration_rates=rates,administration_contrasts=contrasts)
  names_out <- paste0(names(tables),".csv")
  for(j in seq_along(tables)) utils::write.csv(do.call(rbind,tables[[j]]),file.path(out,names_out[j]),row.names=FALSE,na="")
  names_out
}
