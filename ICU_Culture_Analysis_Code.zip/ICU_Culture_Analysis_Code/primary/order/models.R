# Apply the project's reportable cell threshold at export, retaining exact local summaries.
proportion_table <- function(n, N) {
  if (length(n)!=length(N) && length(n)!=1L && length(N)!=1L) stop("Rate lengths differ.")
  len <- max(length(n), length(N))
  if (!length(n) || !length(N)) len <- 0L
  n <- rep_len(as.numeric(n),len); N <- rep_len(as.numeric(N),len)
  if (any(n<0 | N<0 | n>N | n!=floor(n) | N!=floor(N),na.rm=TRUE)) stop("Invalid risk numerator or denominator.")
  p <- lo <- hi <- rep(NA_real_,len)
  sel <- !is.na(n) & !is.na(N) & N>0
  p[sel] <- n[sel]/N[sel]
  z <- stats::qnorm(.975)
  den <- 1+z*z/N[sel]
  mid <- (p[sel]+z*z/(2*N[sel]))/den
  half <- z*sqrt(p[sel]*(1-p[sel])/N[sel]+z*z/(4*N[sel]^2))/den
  lo[sel] <- pmax(0,mid-half); hi[sel] <- pmin(1,mid+half)
  data.frame(n=n,N=N,percent=100*p,lower95=100*lo,upper95=100*hi)
}
# Broad-spectrum prescribing and administered days of therapy after final reporting.
report_count <- function(n) {
  ifelse(is.na(n),NA_character_,ifelse(n<11,"<11",format(n,trim=TRUE,scientific=FALSE)))
}

treatment_summary <- function(z,metric) {
  binary <- metric %in% c("stop_or_reduce_48h","all_stopped_48h","stop_or_reduce_48h_emar_checked","reduced_dose_spectrum_final24h","no_broad_dose_final24h","any_broad_dose_final24h")
  vals <- as.numeric(z$value)
  n <- length(vals)
  count <- if(binary) sum(vals) else NA_real_
  est <- lo <- hi <- NA_real_
  if(n>=11 && (!binary || count>=11) && (!startsWith(metric,"broad_dot") || sum(vals>0)>=11)) {
    if(binary) {
      interval <- proportion_table(count,n)
      est <- interval$percent; lo <- interval$lower95; hi <- interval$upper95
    } else {
      est <- mean(vals)
      half <- stats::qt(.975,n-1L)*stats::sd(vals)/sqrt(n)
      lo <- max(0,est-half); hi <- est+half
    }
  }
  data.frame(metric=metric,eligible=report_count(n),numerator=report_count(count),
             estimate=est,lower=lo,upper=hi,
             unit=if(binary) "percent" else if(metric=="inpatient_days_7d") "inpatient_days_per_patient" else "agent_days_per_patient")
}

# Linear mean and risk-difference contrasts on their original scales. Rows from the same
# person in both locations share a sandwich cluster. Group means in the output use all
# eligible observations; adjusted contrasts use common measured case-mix support.
location_contrast <- function(z,metric,adjustment) {
  binary <- startsWith(metric,"stop_") || metric=="reduced_dose_spectrum_final24h"
  unit <- if(binary) "percentage_points" else "agent_days_per_patient"
  empty <- function(status) data.frame(metric,adjustment,eligible=report_count(nrow(z)),ward_n=report_count(sum(z$location=="ward")),
     estimate=NA_real_,lower=NA_real_,upper=NA_real_,unit,status,ward_difference_total_DOT=NA_real_,
     ward_total_lower=NA_real_,ward_total_upper=NA_real_,stringsAsFactors=FALSE)
  if(!all(c("ICU","ward") %in% z$location)) return(empty("insufficient_support"))
  z$ward <- as.integer(z$location=="ward")
  z$source_site <- ifelse(z$site=="blood","blood",ifelse(z$site %in% c("csf","pleural","peritoneal","synovial","pericardial","deep_tissue_pus"),
         "other_sterile",ifelse(z$site %in% c("urine","respiratory"),z$site,"other")))
  z$report_type <- ifelse(z$result=="direct_narrow_S","positive","negative_or_normal")
  candidates <- character()
  if(adjustment=="adjusted") {
    # Remove categorical levels represented in only one setting, retaining explicitly reported common support.
    for(nm in c("source_site","report_type","era","sex")) {
      by_group <- split(as.character(z[[nm]]),z$location)
      shared <- intersect(unique(by_group$ICU),unique(by_group$ward))
      z <- z[z[[nm]] %in% shared,,drop=FALSE]
      if(!nrow(z)||length(unique(z$location))<2) return(empty("no_common_support"))
    }
    z$log_icu_days <- log1p(z$days_since_icu_entry)
    z$log_specimen_hours <- log1p(z$specimen_age_hours)
    choices <- c("age","sex","era","source_site","report_type","baseline_agents","mrsa","ap","carb",
                 "log_icu_days","log_specimen_hours","other_positive")
    candidates <- choices[vapply(choices,function(nm) length(unique(z[[nm]][!is.na(z[[nm]])]))>1L,logical(1))]
  }
  terms <- c("ward",candidates)
  z <- z[stats::complete.cases(z[,c(terms,"value","pid")]),,drop=FALSE]
  if(!all(c("ward","ICU") %in% z$location) || min(table(z$location))<11 || length(unique(z$pid))<22)
    return(empty("insufficient_support"))
  if(binary && any(vapply(split(z$value,z$location),function(x) min(sum(x),length(x)-sum(x)),numeric(1))<11))
    return(empty("sparse_events"))
  if(!binary && any(vapply(split(z$value,z$location),function(x) sum(x>0),numeric(1))<11))
    return(empty("sparse_administered_DOT"))
  X <- stats::model.matrix(stats::reformulate(terms),z)
  # Remove redundant nuisance columns while retaining intercept and location in their original order.
  decomp <- qr(X); keep <- sort(decomp$pivot[seq_len(decomp$rank)])
  if(!all(c("(Intercept)","ward")%in%colnames(X)[keep])) return(empty("non_estimable"))
  X <- X[,keep,drop=FALSE]
  n <- nrow(X); p <- ncol(X); g <- length(unique(z$pid))
  if(n<5*p || g<=p) return(empty("insufficient_model_support"))
  fit <- stats::lm.fit(X,z$value)
  inv <- tryCatch(chol2inv(chol(crossprod(X))),error=function(e) NULL)
  if(is.null(inv)) return(empty("non_estimable"))
  s <- rowsum(X*as.numeric(fit$residuals),group=z$pid,reorder=FALSE)
  v <- inv%*%crossprod(s)%*%inv * (g/(g-1))*((n-1)/(n-p))
  j <- match("ward",colnames(X)); scale <- if(binary) 100 else 1
  e <- scale*unname(fit$coefficients[j]); half <- scale*stats::qt(.975,g-1)*sqrt(max(0,v[j,j]))
  nw <- sum(z$ward==1L)
  data.frame(metric,adjustment,eligible=report_count(n),ward_n=report_count(nw),estimate=e,lower=e-half,upper=e+half,
             unit,status="estimable",ward_difference_total_DOT=if(binary) NA_real_ else e*nw,
             ward_total_lower=if(binary) NA_real_ else (e-half)*nw,
             ward_total_upper=if(binary) NA_real_ else (e+half)*nw,stringsAsFactors=FALSE)
}
