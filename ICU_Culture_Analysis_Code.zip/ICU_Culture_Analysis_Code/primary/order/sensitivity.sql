CREATE TEMP TABLE review_dot_index AS
WITH rules AS (SELECT * FROM (VALUES ('main'),('report_active_only'),('both_times'),('no_other_recent_positive'),
 ('explicit_negative_only')) x(analysis)), enroll AS (
 SELECT r.*,s.analysis FROM review_dot_eligible r CROSS JOIN rules s WHERE
  (s.analysis='report_active_only' OR r.broad_at_transfer OR (r.location='ICU' AND s.analysis<>'both_times'))
  AND (s.analysis<>'no_other_recent_positive' OR NOT r.other_positive)
  AND (s.analysis<>'explicit_negative_only' OR EXISTS(SELECT 1 FROM culture_spec sp
      WHERE sp.pid=r.pid AND sp.hid=r.hid AND sp.specimen=r.specimen AND sp.outcome_class='no_growth' AND sp.explicit_no_growth))
)
SELECT * FROM enroll QUALIFY row_number() OVER(PARTITION BY scope,pid,hid,channel,analysis,location
 ORDER BY t, CASE result WHEN 'direct_narrow_S' THEN 1 WHEN 'normal_flora' THEN 2 ELSE 3 END,specimen)=1;
