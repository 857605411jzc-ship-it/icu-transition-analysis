-- Select explicit negative reports and omit every other positive accession in the
-- expanded study-culture set, including positives susceptible to a narrow agent.
-- The separate retrospective sensitivity extends the competing-report window to +48 h.
CREATE TEMP TABLE response_negative_candidates AS
SELECT r.pid,r.hid,r.specimen,r.t,
 NOT EXISTS(SELECT 1 FROM culture_spec other
    WHERE other.pid=r.pid AND other.hid=r.hid AND other.specimen<>r.specimen
    AND other.outcome_class='positive' AND other.final_time BETWEEN r.t-INTERVAL '48 hours' AND r.t) AS negative_at_report,
 NOT EXISTS(SELECT 1 FROM culture_spec other
    WHERE other.pid=r.pid AND other.hid=r.hid AND other.specimen<>r.specimen
    AND other.outcome_class='positive' AND other.final_time BETWEEN r.t-INTERVAL '48 hours' AND r.t+INTERVAL '48 hours') AS negative_through_endpoint
FROM review_dot_eligible r JOIN culture_spec s USING(pid,hid,specimen)
WHERE r.scope='plus_exact_reflex' AND s.outcome_class='no_growth' AND s.explicit_no_growth;

CREATE TEMP TABLE review_dot_index AS
WITH designs AS (SELECT * FROM (VALUES ('report_active_only'),('negative_at_report'),('negative_through_endpoint')) d(analysis)),
 eligible AS (
 SELECT r.*,d.analysis FROM review_dot_eligible r CROSS JOIN designs d
 LEFT JOIN response_negative_candidates n USING(pid,hid,specimen,t)
 WHERE r.scope='plus_exact_reflex' AND
 (d.analysis='report_active_only' OR (d.analysis='negative_at_report' AND n.negative_at_report)
 OR (d.analysis='negative_through_endpoint' AND n.negative_through_endpoint))
 )
SELECT * FROM eligible
QUALIFY row_number() OVER(PARTITION BY scope,pid,hid,channel,analysis,location
ORDER BY t, CASE result WHEN 'direct_narrow_S' THEN 1 WHEN 'normal_flora' THEN 2 ELSE 3 END,specimen)=1;
