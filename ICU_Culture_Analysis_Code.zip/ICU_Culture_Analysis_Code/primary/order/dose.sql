CREATE TEMP TABLE therapy_dose_reports AS
WITH first_location AS (
 SELECT l.pid,l.hid,min(l.began) AS first_seen
 FROM loc l JOIN cohort c USING(pid,hid) WHERE l.ended>l.began GROUP BY l.pid,l.hid
)
SELECT r.*,c.icu_in,c.age_at_exit AS age,
 CASE WHEN c.era_upper<=2019 THEN 'early' WHEN c.era_lower>=2020 THEN 'late' ELSE 'crossing' END AS era
FROM review_dot_reports r JOIN cohort c USING(pid,hid) JOIN first_location l USING(pid,hid)
WHERE r.scope='plus_exact_reflex'
 AND r.t BETWEEN r.tm-INTERVAL '24 hours' AND r.tm+INTERVAL '24 hours'
 AND r.t-INTERVAL '24 hours'>=greatest(c.icu_in-INTERVAL '24 hours',r.tm-INTERVAL '72 hours',l.first_seen)
 AND r.t+INTERVAL '48 hours'<=r.tm+INTERVAL '72 hours';

CREATE TEMP TABLE therapy_dose_admin AS
SELECT DISTINCT e.pid,e.hid,e.agent,e.at_time,e.recorded,e.route_kind AS route
FROM culture_em e JOIN review_dot_agents a USING(agent)
WHERE NOT regexp_matches(e.name,'TROUGH|PEAK|RANDOM LEVEL|PLACEHOLDER|DOSING BY PHARMACY|PHARMACY TO DOSE');

CREATE TEMP TABLE therapy_dose_index AS
WITH clocks AS (
 SELECT DISTINCT pid,hid,t FROM therapy_dose_reports
), baseline AS (
 SELECT c.pid,c.hid,c.t,count(DISTINCT a.agent) AS baseline_agents,
 max(a.mrsa) AS mrsa,max(a.ap) AS ap,max(a.carb) AS carb
 FROM clocks c JOIN therapy_dose_admin e ON e.pid=c.pid AND e.hid=c.hid AND e.route='systemic'
 AND e.at_time>=c.t-INTERVAL '24 hours' AND e.at_time<c.t AND e.recorded<=c.t
 JOIN review_dot_agents a ON a.agent=e.agent GROUP BY c.pid,c.hid,c.t
)
SELECT r.*,b.baseline_agents,b.mrsa,b.ap,b.carb FROM therapy_dose_reports r JOIN baseline b USING(pid,hid,t)
QUALIFY row_number() OVER(PARTITION BY r.pid,r.hid,r.location ORDER BY r.t,
 CASE r.result WHEN 'direct_narrow_S' THEN 1 WHEN 'normal_flora' THEN 2 ELSE 3 END,r.specimen)=1;

CREATE TEMP TABLE therapy_dose_windows AS
SELECT i.pid,i.hid,i.location,i.t,i.hospital_end,q.phase,i.t+q.a*INTERVAL '1 hour' AS lo,
 i.t+q.b*INTERVAL '1 hour' AS hi
FROM therapy_dose_index i CROSS JOIN (VALUES('pre',-24,0),('post',24,48)) q(phase,a,b);

CREATE TEMP TABLE therapy_dose_window_values AS
WITH confirmed AS (
 SELECT w.pid,w.hid,w.location,w.phase,e.agent,
 count(DISTINCT e.at_time)>0 AS given
 FROM therapy_dose_windows w JOIN therapy_dose_admin e ON e.pid=w.pid AND e.hid=w.hid AND e.route='systemic' AND
 ((w.phase='pre' AND w.lo<=e.at_time AND e.at_time<w.hi AND e.recorded<=w.hi)
 OR (w.phase='post' AND w.lo<e.at_time AND e.at_time<=w.hi AND e.at_time<w.hospital_end))
 GROUP BY w.pid,w.hid,w.location,w.phase,e.agent
), broad AS (
 SELECT c.pid,c.hid,c.location,c.phase,count(*) AS agents,max(a.mrsa) AS mrsa,max(a.ap) AS ap,max(a.carb) AS carb
 FROM confirmed c JOIN review_dot_agents a USING(agent) GROUP BY c.pid,c.hid,c.location,c.phase
), log AS (
 SELECT w.pid,w.hid,w.location,w.phase,
 count(e.at_time) FILTER(WHERE e.at_time<w.lo+INTERVAL '12 hours')>0 AND
 count(e.at_time) FILTER(WHERE e.at_time>=w.lo+INTERVAL '12 hours')>0 AS documented
 FROM therapy_dose_windows w LEFT JOIN culture_em e ON e.pid=w.pid AND e.hid=w.hid AND
 ((w.phase='pre' AND w.lo<=e.at_time AND e.at_time<w.hi AND e.recorded<=w.hi)
 OR (w.phase='post' AND w.lo<e.at_time AND e.at_time<=w.hi AND e.at_time<w.hospital_end))
 GROUP BY w.pid,w.hid,w.location,w.phase
), ambiguous AS (
 SELECT pid,hid,agent,at_time,recorded FROM therapy_dose_admin WHERE route='uncertain'
 UNION SELECT e.pid,e.hid,e.agent,e.at_time,e.recorded FROM culture_amb_em e JOIN review_dot_agents a USING(agent)
), unresolved AS (
 SELECT DISTINCT w.pid,w.hid,w.location,w.phase
 FROM therapy_dose_windows w JOIN ambiguous u ON u.pid=w.pid AND u.hid=w.hid AND
 ((w.phase='pre' AND w.lo<=u.at_time AND u.at_time<w.hi AND u.recorded<=w.hi)
 OR (w.phase='post' AND w.lo<u.at_time AND u.at_time<=w.hi AND u.at_time<w.hospital_end))
 ANTI JOIN confirmed k ON k.pid=w.pid AND k.hid=w.hid AND k.location=w.location AND k.phase=w.phase AND k.agent=u.agent
)
SELECT w.pid,w.hid,w.location,w.phase,l.documented,u.pid IS NOT NULL AS uncertain,
 coalesce(b.agents,0) AS agents,coalesce(b.mrsa,0) AS mrsa,coalesce(b.ap,0) AS ap,coalesce(b.carb,0) AS carb
FROM therapy_dose_windows w JOIN log l USING(pid,hid,location,phase)
LEFT JOIN broad b USING(pid,hid,location,phase) LEFT JOIN unresolved u USING(pid,hid,location,phase);

CREATE TEMP TABLE therapy_dose_people AS
SELECT i.pid,i.hid,i.location,i.result,i.site_group AS site,i.age,i.era,'unknown' AS sex,
 greatest(0,epoch(i.t-i.icu_in)/86400.0) AS days_since_icu_entry,
 epoch(i.t-i.collected)/3600 AS specimen_age_hours,
 i.baseline_agents,i.mrsa,i.ap,i.carb,i.other_positive,
 CASE WHEN i.hospital_end<=i.t+INTERVAL '48 hours' THEN 'hospital_exit_by_48h'
      WHEN NOT b.documented OR NOT a.documented THEN 'incomplete_eMAR_documentation'
      WHEN b.uncertain OR a.uncertain THEN 'ambiguous_agent_or_route'
      ELSE 'evaluable' END AS flow,
 (a.mrsa<=b.mrsa AND a.ap<=b.ap AND a.carb<=b.carb AND
  (a.agents<b.agents OR a.mrsa<b.mrsa OR a.ap<b.ap OR a.carb<b.carb)) AS reduced,
 a.agents=0 AS no_broad
FROM therapy_dose_index i
JOIN therapy_dose_window_values b ON b.pid=i.pid AND b.hid=i.hid AND b.location=i.location AND b.phase='pre'
JOIN therapy_dose_window_values a ON a.pid=i.pid AND a.hid=i.hid AND a.location=i.location AND a.phase='post';
