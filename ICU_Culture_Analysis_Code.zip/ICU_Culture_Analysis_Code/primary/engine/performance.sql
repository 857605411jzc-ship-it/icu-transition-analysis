-- Work only on previously excluded accessions with the exact published label pair.
-- Preserve the collection-time workload even when a later report says no culture was performed.
CREATE TEMP TABLE reflex_evidence AS
WITH flags AS (
  SELECT k.era,k.pid,k.hid,k.specimen,
   bool_or(r.row_class='isolate' AND r.organism_category<>'morphology_only') AS identified,
   bool_or(r.row_class='no_growth') AS explicit_no_growth,
   bool_or(r.row_class='flora') AS flora,
   bool_or(r.row_class='null_no_growth') AS blank_final,
   bool_or(regexp_matches(concat_ws(' ',r.annotation,r.organism),
    'NOT (PERFORMED|CULTURED|INDICATED|REFLEXED|SET UP|PROCESSED)|NO (URINE )?CULTURE (INDICATED|REQUIRED|NEEDED|PERFORMED)|CULTURE (WAS |IS )?NOT (INDICATED|NEEDED|REQUIRED|DONE)|DID NOT (MEET|REFLEX)|CRITERIA (WERE )?NOT MET|CANCEL+ED|REJECTED|UNSATISFACTORY|INSUFFICIENT (SPECIMEN|QUANTITY)|INAPPROPRIATE SPECIMEN|NOT SENT FOR CULTURE')) AS no_culture
  FROM reflex_keys k LEFT JOIN culture_culture_rows r USING(pid,hid,specimen)
  GROUP BY k.era,k.pid,k.hid,k.specimen
)
SELECT *,CASE WHEN no_culture AND (identified OR explicit_no_growth OR flora) THEN 'conflicting_performance_evidence'
 WHEN no_culture THEN 'explicit_nonperformance_or_rejection'
 WHEN identified THEN 'named_isolate_recorded' WHEN flora THEN 'flora_reported'
 WHEN explicit_no_growth THEN 'explicit_no_growth' WHEN blank_final THEN 'blank_or_generic_final'
 ELSE 'other_indeterminate' END AS evidence
FROM flags;

UPDATE culture_culture_rows AS r SET row_class='uninterpretable',organism_category=NULL FROM reflex_evidence e
 WHERE r.pid=e.pid AND r.hid=e.hid AND r.specimen=e.specimen AND
  (e.evidence IN ('explicit_nonperformance_or_rejection','conflicting_performance_evidence') OR r.row_class='null_no_growth');
