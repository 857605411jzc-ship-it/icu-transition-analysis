-- Historical information available by each recorded row time.
-- Unordered records have no usable availability clock for this candidate strategy.
CREATE TEMP TABLE routing_provenance AS
WITH variants AS (
  SELECT pid,hid,specimen,collected,site_group,min(stored) AS first_seen
  FROM culture_culture_rows WHERE stored IS NOT NULL AND collected IS NOT NULL AND stored>=collected
  GROUP BY ALL
), ordered AS (
  SELECT *,row_number() OVER(PARTITION BY pid,hid,specimen ORDER BY first_seen,collected,site_group) AS seq
  FROM variants
), undated_collection AS (
  SELECT pid,hid,specimen,min(stored) AS unavailable_collection
  FROM culture_culture_rows WHERE stored IS NOT NULL AND collected IS NULL GROUP BY ALL
)
SELECT o.pid,o.hid,o.specimen,least(min(first_seen) FILTER(WHERE seq=2),u.unavailable_collection) AS ambiguous_at
FROM ordered o LEFT JOIN undated_collection u USING(pid,hid,specimen)
GROUP BY o.pid,o.hid,o.specimen,u.unavailable_collection;

CREATE TEMP TABLE routing_identity AS
WITH variants AS (
  SELECT pid,hid,specimen,org_code,isolate_number,organism,min(stored) AS first_seen
  FROM culture_culture_rows WHERE row_class='isolate' AND stored>=collected GROUP BY ALL
), by_key AS (
  SELECT *,row_number() OVER(PARTITION BY pid,hid,specimen,org_code,isolate_number ORDER BY first_seen,organism) AS seq
  FROM variants
), numbering AS (
  SELECT pid,hid,specimen,org_code,
    min(first_seen) FILTER(WHERE isolate_number IS NULL) AS anon_seen,
    min(first_seen) FILTER(WHERE isolate_number IS NOT NULL) AS numbered_seen FROM variants GROUP BY ALL
)
SELECT b.pid,b.hid,b.specimen,b.org_code,b.isolate_number,
       least(min(b.first_seen) FILTER(WHERE seq=2), CASE WHEN n.anon_seen IS NOT NULL AND n.numbered_seen IS NOT NULL
                  THEN greatest(n.anon_seen,n.numbered_seen) END) AS ambiguous_at
FROM by_key b JOIN numbering n USING(pid,hid,specimen,org_code)
GROUP BY b.pid,b.hid,b.specimen,b.org_code,b.isolate_number,n.anon_seen,n.numbered_seen;

CREATE TEMP TABLE routing_first_per_pair AS
SELECT r.pid,r.hid,r.specimen,r.org_code,r.isolate_number,d.agent,
       min(r.stored) FILTER(WHERE r.interpretation='S') AS first_s,
       min(r.stored) FILTER(WHERE r.interpretation IN ('I','R')) AS first_non_s
FROM culture_culture_rows r JOIN culture_drugs d ON d.name=culture_name(r.antibiotic)
WHERE r.row_class='isolate' AND r.organism_category<>'morphology_only'
  AND r.stored>=r.collected AND r.interpretation IN ('S','I','R')
  AND ((r.organism_category='yeast_fungus' AND d.family='antifungal') OR
       (r.organism_category<>'yeast_fungus' AND d.family IN ('broad','antibacterial')))
  AND NOT (d.agent IN ('nitrofurantoin','fosfomycin') AND r.site_group<>'urine')
  AND NOT (d.agent='daptomycin' AND r.site_group='respiratory')
  AND EXISTS (SELECT 1 FROM icu_intervals i WHERE i.pid=r.pid AND i.hid=r.hid
    AND r.collected>=i.began AND (r.collected<i.ended OR (i.ended=r.tm AND r.collected=r.tm)))
GROUP BY ALL;

CREATE TEMP TABLE routing_trigger AS
SELECT p.pid,p.hid,p.specimen,min(p.first_s) AS trigger_time
FROM routing_first_per_pair p JOIN cohort c USING(pid,hid) JOIN routing_provenance v USING(pid,hid,specimen)
 JOIN routing_identity i ON p.pid=i.pid AND p.hid=i.hid AND p.specimen=i.specimen AND p.org_code=i.org_code
   AND p.isolate_number IS NOT DISTINCT FROM i.isolate_number
WHERE p.first_s>c.tm AND p.first_s<=c.tm+INTERVAL '48 hours' AND p.first_s<c.hospital_end
  AND (p.first_non_s IS NULL OR p.first_non_s>p.first_s)
  AND (i.ambiguous_at IS NULL OR i.ambiguous_at>p.first_s)
  AND (v.ambiguous_at IS NULL OR v.ambiguous_at>p.first_s)
GROUP BY p.pid,p.hid,p.specimen;

CREATE TEMP TABLE routing_event_locations AS
WITH matches AS (
  SELECT e.pid,e.hid,e.specimen,e.trigger_time,c.tm,c.ward_end,
    count(l.began) AS possible_locations,
    bool_and(l.ended IS NOT NULL AND l.unit IS NOT NULL) AS named_bounded,
    min(l.unit_category) AS known_unit_class,
    bool_and(l.began=c.tm AND l.ended=c.ward_end AND l.unit=c.receiving_unit) AS in_index_ward
  FROM routing_trigger e JOIN cohort c USING(pid,hid)
  LEFT JOIN loc l ON l.pid=e.pid AND l.hid=e.hid AND l.began<=e.trigger_time
    AND (l.ended>e.trigger_time OR l.ended IS NULL)
  GROUP BY e.pid,e.hid,e.specimen,e.trigger_time,c.tm,c.ward_end
), labeled AS (
  SELECT *,CASE WHEN possible_locations<>1 OR NOT coalesce(named_bounded,false) THEN 'unknown'
    WHEN in_index_ward THEN 'first_ward'
    WHEN known_unit_class IN ('Medical','Surgical','Mixed or specialty') THEN 'other_ward'
    WHEN known_unit_class='ICU' THEN 'icu' ELSE 'other_named_unit' END AS destination
  FROM matches
)
SELECT pid,hid,specimen,trigger_time,epoch(trigger_time-tm)/3600 AS hours_from_transfer,
       trigger_time>=ward_end AS after_first_ward,destination,destination<>'unknown' AS unique_named_unit,
       destination IN ('first_ward','other_ward','icu') AS ward_or_icu_routable
FROM labeled;
