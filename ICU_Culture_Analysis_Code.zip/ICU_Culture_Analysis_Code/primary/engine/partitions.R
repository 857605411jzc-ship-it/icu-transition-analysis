partition_table_path <- function(work, name) {
  parent <- if (name %in% c("cohort","loc","icu_intervals")) "index" else name
  file.path(work,"inputs",parent,name)
}

partition_query <- function(con, path, shard=NULL) {
  # Pass files individually for one shard; unrelated patients' fragments are never opened.
  directory <- if (is.null(shard)) file.path(path,"blocks") else file.path(path,"blocks",paste0("part=",shard))
  files <- if (dir.exists(directory)) list.files(directory,pattern="[.]parquet$",full.names=TRUE,recursive=is.null(shard)) else character()
  if (!length(files)) files <- file.path(path,"schema.parquet")
  stopifnot(all(file.exists(files)))
  files <- normalizePath(files,winslash="/",mustWork=TRUE)
  # Disable implicit hive columns; part exists in the directory name only.
  paste0("SELECT * FROM read_parquet([",paste(DBI::dbQuoteString(con,files),collapse=","),"],hive_partitioning=false)")
}

bind_partition <- function(con,work,shard,n_shards,note=message) {
  stopifnot(length(shard)==1L,shard==as.integer(shard),shard>=0L,shard<n_shards)
  for(name in c("cohort","icu_intervals","loc","microbiologyevents","emar","prescriptions","pharmacy","emar_detail")) {
    view <- if (name %in% c("cohort","icu_intervals","loc")) name else paste0("src_",name)
    sql <- partition_query(con,partition_table_path(work,name),as.integer(shard))
    DBI::dbExecute(con,paste0("CREATE OR REPLACE TEMP VIEW ",view," AS ",sql))
  }
  invisible(TRUE)
}
