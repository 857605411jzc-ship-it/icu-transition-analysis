-- Revised mismatch and the strict first S-trigger on the implicated isolate at its final report.
CREATE TEMP TABLE coverage_revision_targets AS
SELECT t.pid,t.hid,t.specimen,t.report_time
FROM coverage_tiers t JOIN culture_reports r USING(pid,hid,specimen,report_time)
WHERE t.mode='transition' AND t.phase='ward' AND t.grade='T1' AND r.outcome_class='positive'
  AND r.report_time>r.tm AND r.report_time<=r.tm+INTERVAL '48 hours';

CREATE TEMP TABLE coverage_pair_acc AS
WITH culprit AS (
  SELECT DISTINCT t.pid,t.hid,t.specimen,w.org_code,w.isolate_number
  FROM coverage_revision_targets t JOIN coverage_isolate_tiers j USING(pid,hid,specimen,report_time)
  JOIN culture_work_rows w USING(pid,hid,specimen,isolate_key)
  WHERE j.mode='transition' AND j.phase='ward' AND j.grade='T1' AND w.row_class='isolate'
), seen AS (
  SELECT DISTINCT k.pid,k.hid,k.specimen
  FROM culprit k JOIN routing_event_locations e USING(pid,hid,specimen)
  JOIN routing_first_per_pair p ON p.pid=k.pid AND p.hid=k.hid AND p.specimen=k.specimen
    AND p.org_code=k.org_code AND p.isolate_number IS NOT DISTINCT FROM k.isolate_number
    AND p.first_s=e.trigger_time AND (p.first_non_s IS NULL OR p.first_non_s>p.first_s)
  JOIN routing_identity i ON i.pid=p.pid AND i.hid=p.hid AND i.specimen=p.specimen AND i.org_code=p.org_code
    AND i.isolate_number IS NOT DISTINCT FROM p.isolate_number
    AND (i.ambiguous_at IS NULL OR i.ambiguous_at>p.first_s)
), expanded AS (
  SELECT pid,hid,bool_or(red_flag IS TRUE) AS flagged FROM culture_red_flags GROUP BY pid,hid
)
SELECT t.*, c.era_lower,c.era_upper,r.red_flag IS TRUE AS red_direct, x.flagged AS red_expanded,
  coalesce(k.specimen IS NOT NULL AND e.trigger_time=t.report_time AND e.ward_or_icu_routable,false) AS strict_dynamic
FROM coverage_revision_targets t JOIN cohort c USING(pid,hid) JOIN culture_red_flags r USING(pid,hid,specimen)
JOIN expanded x USING(pid,hid) LEFT JOIN seen k USING(pid,hid,specimen)
LEFT JOIN routing_event_locations e USING(pid,hid,specimen);
