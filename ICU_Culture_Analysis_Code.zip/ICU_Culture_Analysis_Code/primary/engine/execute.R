execute_sql <- function(con, path) {
  lines <- readLines(path, warn=FALSE, encoding="UTF-8")
  lines <- lines[!grepl("^\\s*--",lines,perl=TRUE) & nzchar(trimws(lines))]
  ends <- which(grepl(";\\s*$",lines,perl=TRUE))
  stopifnot(length(ends)>0L,tail(ends,1)==length(lines))
  starts <- c(1L,head(ends,-1L)+1L)
  for(j in seq_along(ends)) {
    sql <- paste(lines[starts[j]:ends[j]],collapse="\n")
    tryCatch(DBI::dbExecute(con,sql),error=function(e) {
      stop(basename(path)," / ",lines[starts[j]]," — ",conditionMessage(e),call.=FALSE)
    })
  }
  invisible(NULL)
}
