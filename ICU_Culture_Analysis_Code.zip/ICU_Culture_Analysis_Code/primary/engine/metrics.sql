CREATE TEMP TABLE reflex_events AS
WITH universe AS (SELECT pid,hid,specimen FROM culture_red_flags UNION SELECT pid,hid,specimen FROM routing_event_locations),
result48 AS (SELECT pid,hid,specimen,report_time FROM culture_reports WHERE phase='ward' AND outcome_class='positive'
 AND report_time>tm AND report_time<=tm+INTERVAL '48 hours')
SELECT u.pid,u.hid,u.specimen,CASE WHEN c.era_upper<=2019 THEN 'early' WHEN c.era_lower>=2020 THEN 'late' ELSE 'boundary_or_unknown' END AS era,
 k.specimen IS NOT NULL AS added,f.specimen IS NOT NULL AS pending,
 (f.specimen IS NOT NULL AND s.gram_pos_pre IS TRUE) AS gram,
 (f.red_flag IS TRUE AND s.site_group<>'blood') OR (f.specimen IS NOT NULL AND s.site_group='blood' AND s.gram_pos_pre IS TRUE) AS nonblood_plus_gram_blood,
 p.specimen IS NOT NULL AS positive, x.specimen IS NOT NULL AS mismatch,
 a.specimen IS NOT NULL AS dynamic,a.after_first_ward IS TRUE AS after_first_ward,
 (p.specimen IS NOT NULL AND a.trigger_time<=p.report_time AND a.ward_or_icu_routable IS TRUE) IS TRUE AS dynamic_positive,
 x.strict_dynamic IS TRUE AS dynamic_mismatch
FROM universe u JOIN cohort c USING(pid,hid) LEFT JOIN reflex_keys k USING(pid,hid,specimen)
 LEFT JOIN culture_spec s USING(pid,hid,specimen) LEFT JOIN culture_red_flags f USING(pid,hid,specimen)
 LEFT JOIN result48 p USING(pid,hid,specimen) LEFT JOIN coverage_pair_acc x USING(pid,hid,specimen)
 LEFT JOIN routing_event_locations a USING(pid,hid,specimen);
