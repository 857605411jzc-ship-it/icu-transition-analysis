-- Restrict new medication work to indexed hospitalizations with a timed positive culture.
CREATE TEMP TABLE coverage_windows0 AS
SELECT w.*,r.tm,r.hospital_end,r.era_lower,r.era_upper,
  CASE WHEN w.mode='transition' THEN r.tm ELSE w.hi END AS order_anchor
FROM culture_windows w JOIN culture_reports r USING(pid,hid,specimen,phase,report_time)
WHERE w.mode IN ('report','transition') AND r.outcome_class='positive';

CREATE TEMP TABLE coverage_person_hospital AS
SELECT DISTINCT pid,hid FROM coverage_windows0;

CREATE TEMP TABLE coverage_pharmacy0 AS
SELECT DISTINCT h.pid,h.hid,try_cast(p.pharmacy_id AS BIGINT) AS pharmacy_id,
 culture_name(p.medication) AS name,culture_name(p.route) AS route,
 try_cast(p.starttime AS TIMESTAMP) AS started,try_cast(p.stoptime AS TIMESTAMP) AS stopped,
 try_cast(p.entertime AS TIMESTAMP) AS entered
FROM src_pharmacy p JOIN coverage_person_hospital h
 ON h.pid=try_cast(p.subject_id AS BIGINT) AND h.hid=try_cast(p.hadm_id AS BIGINT);

-- Link only unique pharmacy metadata to a prescription, preserving its active ingredients.
CREATE TEMP TABLE coverage_orders0 AS
WITH pharm_key AS (
  SELECT pid,hid,pharmacy_id,
    CASE WHEN count(DISTINCT entered)=1 THEN min(entered) END AS entered,
    CASE WHEN count(DISTINCT started)=1 THEN min(started) END AS started,
    CASE WHEN count(DISTINCT stopped)=1 THEN min(stopped) END AS stopped,
    CASE WHEN count(DISTINCT nullif(route,''))=1 THEN min(nullif(route,'')) END AS route
  FROM coverage_pharmacy0 WHERE pharmacy_id IS NOT NULL GROUP BY ALL
), prescriptions AS (
  SELECT r.pid,r.hid,r.pharmacy_id,r.name,coalesce(nullif(r.route,''),p.route,'') AS route,
    r.started,coalesce(r.stopped,CASE WHEN r.started=p.started THEN p.stopped END) AS stopped,
    p.entered,'prescription' AS source
  FROM culture_r0 r JOIN coverage_person_hospital h USING(pid,hid)
  LEFT JOIN pharm_key p USING(pid,hid,pharmacy_id)
  WHERE r.name<>''
), linked_ingredients AS (
  SELECT DISTINCT r.pid,r.hid,r.pharmacy_id FROM prescriptions r JOIN susceptibility_transition_drugs d ON d.name=r.name
  WHERE d.family IN ('broad','antibacterial','antifungal')
), antimicrobial_pharmacy_names AS (
  SELECT DISTINCT n.name FROM (SELECT DISTINCT name FROM coverage_pharmacy0) n JOIN culture_drug_patterns d
    ON regexp_matches(n.name,d.pattern) WHERE d.family IN ('broad','antibacterial','antifungal')
), pharmacy AS (
  SELECT p.pid,p.hid,p.pharmacy_id,p.name,p.route,p.started,p.stopped,p.entered,'pharmacy' AS source
  FROM coverage_pharmacy0 p WHERE p.name<>'' AND p.entered IS NOT NULL
    AND (NOT EXISTS (SELECT 1 FROM prescriptions r WHERE r.pid=p.pid AND r.hid=p.hid
      AND r.pharmacy_id=p.pharmacy_id)
      OR (EXISTS(SELECT 1 FROM antimicrobial_pharmacy_names n WHERE n.name=p.name)
          AND NOT EXISTS(SELECT 1 FROM linked_ingredients r WHERE r.pid=p.pid AND r.hid=p.hid
                        AND r.pharmacy_id=p.pharmacy_id)))
)
SELECT DISTINCT * FROM (SELECT * FROM prescriptions UNION ALL SELECT * FROM pharmacy)
WHERE started IS NOT NULL AND (stopped IS NULL OR stopped>=started);

CREATE TEMP TABLE coverage_order_names AS
WITH names AS (SELECT DISTINCT name FROM coverage_orders0)
SELECT n.name,p.agent,p.family FROM names n LEFT JOIN culture_drug_patterns p ON regexp_matches(n.name,p.pattern)
QUALIFY row_number() OVER(PARTITION BY n.name ORDER BY p.priority NULLS LAST)=1;

-- Complete courses feed response measures; null stop dates can never prove discontinuation.
CREATE TEMP TABLE coverage_rx AS
SELECT DISTINCT o.*,n.agent,n.family,culture_route_kind(o.route,n.agent,o.name) AS route_kind
FROM coverage_orders0 o JOIN coverage_order_names n USING(name)
WHERE n.family IN ('broad','antibacterial','antifungal');

CREATE TEMP TABLE coverage_win_index AS
SELECT DISTINCT win,pid,hid,lo,hi,exclude_at,order_anchor FROM coverage_windows0;

-- Separate the keys when the transition anchor differs from an otherwise identical report window.
CREATE TEMP TABLE coverage_clock AS
SELECT *,row_number() OVER(ORDER BY win,order_anchor) AS medwin FROM coverage_win_index;

CREATE TEMP TABLE coverage_order_window AS
SELECT w.medwin,o.pharmacy_id,o.name,o.source,o.entered,o.started,o.stopped,n.agent,n.family,
 culture_route_kind(o.route,n.agent,o.name) AS route_kind,
 o.stopped IS NULL OR o.stopped=o.started AS uncertain_duration
FROM coverage_clock w JOIN coverage_orders0 o ON o.pid=w.pid AND o.hid=w.hid
 AND o.started<=w.hi AND o.started<w.exclude_at
 AND (o.entered IS NULL OR (o.entered<=w.hi AND o.entered<w.exclude_at))
 AND ((o.stopped>o.started AND o.stopped>=w.order_anchor AND
       (o.stopped>w.order_anchor OR w.order_anchor=w.exclude_at))
   OR ((o.stopped IS NULL OR o.stopped=o.started) AND o.started BETWEEN w.lo AND w.hi))
JOIN coverage_order_names n USING(name);

CREATE TEMP TABLE coverage_med_seen AS
SELECT w.medwin,
 count(DISTINCT e.at_time)>=2 AS multiple_emar,
 count(e.emar_id) FILTER(WHERE e.at_time>=w.hi-INTERVAL '12 hours')>0 AS near_emar,
 count(e.emar_id)>0 AS any_emar
FROM coverage_clock w LEFT JOIN culture_em e ON e.pid=w.pid AND e.hid=w.hid AND e.at_time BETWEEN w.lo AND w.hi
 AND e.at_time<w.exclude_at AND e.recorded<=w.hi AND e.recorded<w.exclude_at GROUP BY w.medwin;

CREATE TEMP TABLE coverage_admin_window AS
SELECT DISTINCT w.medwin,d.agent,d.family,d.route_kind
FROM coverage_clock w JOIN culture_dose d ON d.pid=w.pid AND d.hid=w.hid AND d.at_time BETWEEN w.lo AND w.hi
 AND d.at_time<w.exclude_at AND d.recorded<=w.hi AND d.recorded<w.exclude_at;

CREATE TEMP TABLE coverage_amb_window AS
SELECT DISTINCT w.medwin,d.agent,d.family
FROM coverage_clock w JOIN culture_amb_em d ON d.pid=w.pid AND d.hid=w.hid AND d.at_time BETWEEN w.lo AND w.hi
 AND d.at_time<w.exclude_at AND d.recorded<=w.hi AND d.recorded<w.exclude_at;

CREATE TEMP TABLE coverage_source0 AS
WITH inventory AS (
 SELECT a.*, a.near_emar AND a.multiple_emar AS adequate_emar,
    EXISTS(SELECT 1 FROM coverage_order_window q WHERE q.medwin=a.medwin AND NOT q.uncertain_duration) AS any_order,
    EXISTS(SELECT 1 FROM coverage_order_window q WHERE q.medwin=a.medwin AND q.route_kind<>'local'
       AND q.family IN ('broad','antibacterial','antifungal') AND NOT q.uncertain_duration) AS antimicrobial_order,
    EXISTS(SELECT 1 FROM coverage_admin_window d WHERE d.medwin=a.medwin AND d.route_kind='systemic') AS any_systemic_dose,
    EXISTS(SELECT 1 FROM coverage_order_window q WHERE q.medwin=a.medwin AND q.route_kind<>'local'
       AND q.family IN ('broad','antibacterial','antifungal') AND NOT EXISTS(SELECT 1 FROM coverage_admin_window d
          WHERE d.medwin=q.medwin AND d.agent=q.agent AND d.route_kind='systemic')) AS order_only_extra,
    EXISTS(SELECT 1 FROM coverage_amb_window b WHERE b.medwin=a.medwin AND NOT EXISTS(SELECT 1 FROM coverage_admin_window d
          WHERE d.medwin=b.medwin AND d.agent=b.agent AND d.route_kind='systemic')) AS ambiguous_admin
 FROM coverage_med_seen a
)
SELECT *,CASE WHEN adequate_emar THEN 'emar'
  WHEN any_order THEN 'prescription_proxy'
  WHEN any_systemic_dose THEN 'emar' ELSE 'unknown' END AS source,
  adequate_emar OR any_order AS zero_supported
FROM inventory;

-- Under sparse eMAR the ordered regimen is supplemented by any actual documented dose.
-- Under adequate eMAR unmatched orders are recorded as a discrepancy without inventing a dose.
CREATE TEMP TABLE coverage_regimen AS
SELECT d.medwin AS win,d.agent,d.family,d.route_kind,'administered' AS evidence FROM coverage_admin_window d
UNION
SELECT DISTINCT q.medwin AS win,q.agent,q.family,
  CASE WHEN s.source='prescription_proxy' AND NOT q.uncertain_duration THEN q.route_kind ELSE 'uncertain' END,
  CASE WHEN s.source='prescription_proxy' AND NOT q.uncertain_duration THEN q.source ELSE 'order_unconfirmed' END
FROM coverage_order_window q JOIN coverage_source0 s USING(medwin)
WHERE NOT s.adequate_emar AND q.family IN ('broad','antibacterial','antifungal') AND q.route_kind<>'local'
 AND NOT EXISTS(SELECT 1 FROM coverage_admin_window d WHERE d.medwin=q.medwin AND d.agent=q.agent AND d.route_kind='systemic')
UNION
SELECT b.medwin AS win,b.agent,b.family,'uncertain','administration_uncertain' FROM coverage_amb_window b
WHERE NOT EXISTS(SELECT 1 FROM coverage_admin_window d WHERE d.medwin=b.medwin AND d.agent=b.agent AND d.route_kind='systemic');

CREATE TEMP VIEW coverage_med_regimen AS SELECT * FROM coverage_regimen;

CREATE TEMP VIEW coverage_wamb AS
SELECT DISTINCT win,agent,family FROM coverage_regimen WHERE route_kind='uncertain';

CREATE TEMP TABLE coverage_wsource AS
SELECT medwin AS win,s.* EXCLUDE(medwin),
 EXISTS(SELECT 1 FROM coverage_wamb u WHERE u.win=s.medwin) AS ambiguous_drug
FROM coverage_source0 s;

CREATE TEMP TABLE coverage_report_location AS
SELECT r.pid,r.hid,r.specimen,r.report_time,
 CASE WHEN r.report_time=r.tm THEN 'transfer_boundary'
      WHEN count(l.tid)<>1 OR count(l.ended)<>1 OR count(l.unit)<>1 THEN 'other_or_unknown'
      WHEN r.report_time<r.tm AND min(l.unit_category)='ICU' THEN 'ICU_pre'
      WHEN r.report_time>r.tm AND min(l.unit_category) IN ('Medical','Surgical','Mixed or specialty') THEN 'ward_post'
      WHEN r.report_time>r.tm AND min(l.unit_category)='ICU' THEN 'ICU_post'
      ELSE 'other_or_unknown' END AS care_at_report
FROM culture_reports r LEFT JOIN loc l ON l.pid=r.pid AND l.hid=r.hid AND r.report_time>=l.began
 AND (r.report_time<l.ended OR l.ended IS NULL)
WHERE r.outcome_class='positive' GROUP BY r.pid,r.hid,r.specimen,r.report_time,r.tm;

CREATE TEMP TABLE coverage_med_windows AS
SELECT w.* EXCLUDE(win),w.win AS legacy_win,s.win,l.care_at_report,s.source AS drug_source,s.* EXCLUDE(win,source),
 coalesce(w.era_lower>=2020 AND s.source='emar' AND s.adequate_emar AND NOT s.order_only_extra
     AND NOT s.ambiguous_drug,false) AS late_emar
FROM coverage_windows0 w JOIN coverage_clock k ON k.win=w.win AND k.order_anchor=w.order_anchor
 JOIN coverage_wsource s ON s.win=k.medwin
 JOIN coverage_report_location l ON l.pid=w.pid AND l.hid=w.hid AND l.specimen=w.specimen AND l.report_time=w.report_time;
