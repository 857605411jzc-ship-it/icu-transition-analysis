-- Drug identities are exact ingredient groups; combinations precede components.
CREATE TEMP TABLE culture_drug_patterns AS SELECT * FROM (VALUES
 (1,'piperacillin_tazobactam','broad','PIPERACILLIN.{0,15}TAZ|PIP.{0,4}TAZO|ZOSYN'),
 (2,'ceftazidime_avibactam','broad','CEFTAZIDIME.{0,12}AVI|AVYCAZ'),
 (3,'ceftolozane_tazobactam','broad','CEFTOLOZANE|ZERBAXA'),
 (4,'meropenem_vaborbactam','broad','MEROPENEM.{0,12}VABOR|VABOMERE'),
 (5,'imipenem_relebactam','broad','IMIPENEM.{0,20}RELEBACTAM|RECARBRIO'),
 (6,'meropenem','broad','MEROPENEM|MERREM'),
 (7,'imipenem','broad','IMIPENEM|PRIMAXIN'),
 (8,'ertapenem','broad','ERTAPENEM|INVANZ'),
 (9,'doripenem','broad','DORIPENEM|DORIBAX'),
 (10,'cefepime','broad','CEFEPIME|MAXIPIME'),
 (11,'vancomycin','broad','VANCOMYCIN|VANCOCIN'),
 (12,'linezolid','broad','LINEZOLID|ZYVOX'),
 (13,'ampicillin_sulbactam','antibacterial','AMPICILLIN.{0,16}SULB|UNASYN'),
 (14,'amoxicillin_clavulanate','antibacterial','AMOXICILLIN.{0,20}CLAV|AUGMENTIN'),
 (15,'trimethoprim_sulfamethoxazole','antibacterial','TRIMETHOPRIM.{0,25}SULF|SULFAMETHOXAZOLE.{0,25}TRIM|BACTRIM|SEPTRA|CO.TRIMOXAZOLE'),
 (16,'penicillin_g','antibacterial','PENICILLIN G|BENZYLPENICILLIN|PFIZERPEN'),
 (17,'penicillin_v','antibacterial','PENICILLIN V|PHENOXYMETHYLPENICILLIN'),
 (18,'amikacin','antibacterial','AMIKACIN'),
 (19,'amoxicillin','antibacterial','AMOXICILLIN|AMOXIL'),
 (20,'ampicillin','antibacterial','AMPICILLIN|OMNIPEN'),
 (21,'azithromycin','antibacterial','AZITHROMYCIN|ZITHROMAX'),
 (22,'aztreonam','antibacterial','AZTREONAM|AZACTAM'),
 (23,'cefazolin','antibacterial','CEFAZOLIN|ANCEF|KEFZOL'),
 (24,'ceftriaxone','antibacterial','CEFTRIAXONE|ROCEPHIN'),
 (25,'ceftazidime','antibacterial','CEFTAZIDIME|FORTAZ'),
 (26,'cefotaxime','antibacterial','CEFOTAXIME|CLAFORAN'),
 (27,'cefuroxime','antibacterial','CEFUROXIME|ZINACEF|CEFTIN'),
 (28,'cephalexin','antibacterial','CEPHALEXIN|KEFLEX'),
 (29,'cefoxitin','antibacterial','CEFOXITIN|MEFOXIN'),
 (30,'cefpodoxime','antibacterial','CEFPODOXIME|VANTIN'),
 (31,'cefdinir','antibacterial','CEFDINIR|OMNICEF'),
 (32,'cefadroxil','antibacterial','CEFADROXIL'),
 (33,'cefixime','antibacterial','CEFIXIME|SUPRAX'),
 (34,'cefotetan','antibacterial','CEFOTETAN'),
 (35,'ceftaroline','antibacterial','CEFTAROLINE|TEFLARO'),
 (36,'cefiderocol','antibacterial','CEFIDEROCOL|FETROJA'),
 (37,'ceftibuten','antibacterial','CEFTIBUTEN'),
 (38,'cefaclor','antibacterial','CEFACLOR'),
 (39,'ceftizoxime','antibacterial','CEFTIZOXIME'),
 (40,'ciprofloxacin','antibacterial','CIPROFLOXACIN|CIPRO'),
 (41,'clarithromycin','antibacterial','CLARITHROMYCIN|BIAXIN'),
 (42,'clindamycin','antibacterial','CLINDAMYCIN|CLEOCIN'),
 (43,'colistin','antibacterial','COLISTIN|COLISTIMETHATE'),
 (44,'dalbavancin','antibacterial','DALBAVANCIN'),
 (45,'daptomycin','antibacterial','DAPTOMYCIN|CUBICIN'),
 (46,'dicloxacillin','antibacterial','DICLOXACILLIN'),
 (47,'doxycycline','antibacterial','DOXYCYCLINE|VIBRAMYCIN'),
 (48,'erythromycin','antibacterial','ERYTHROMYCIN|ERY.TAB'),
 (49,'fosfomycin','antibacterial','FOSFOMYCIN|MONUROL'),
 (50,'gentamicin','antibacterial','GENTAMICIN'),
 (51,'levofloxacin','antibacterial','LEVOFLOXACIN|LEVAQUIN'),
 (52,'metronidazole','antibacterial','METRONIDAZOLE|FLAGYL'),
 (53,'minocycline','antibacterial','MINOCYCLINE|MINOCIN'),
 (54,'moxifloxacin','antibacterial','MOXIFLOXACIN|AVELOX'),
 (55,'nafcillin','antibacterial','NAFCILLIN|NAFCIL'),
 (56,'nitrofurantoin','antibacterial','NITROFURANTOIN|MACROBID|MACRODANTIN'),
 (57,'oxacillin','antibacterial','OXACILLIN'),
 (58,'polymyxin_b','antibacterial','POLYMYXIN B'),
 (59,'rifampin','antibacterial','RIFAMPIN|RIFAMPICIN|RIFADIN'),
 (60,'streptomycin','antibacterial','STREPTOMYCIN'),
 (61,'sulfadiazine','antibacterial','SULFADIAZINE'),
 (62,'sulfamethoxazole','antibacterial','SULFAMETHOXAZOLE'),
 (63,'tetracycline','antibacterial','TETRACYCLINE'),
 (64,'tigecycline','antibacterial','TIGECYCLINE|TYGACIL'),
 (65,'tobramycin','antibacterial','TOBRAMYCIN|NEBCIN'),
 (66,'trimethoprim','antibacterial','TRIMETHOPRIM'),
 (67,'tedizolid','antibacterial','TEDIZOLID'),
 (68,'quinupristin_dalfopristin','antibacterial','QUINUPRISTIN|SYNERCID'),
 (69,'chloramphenicol','antibacterial','CHLORAMPHENICOL'),
 (70,'rifabutin','antibacterial','RIFABUTIN'),
 (71,'ethambutol','antibacterial','ETHAMBUTOL'),
 (72,'pyrazinamide','antibacterial','PYRAZINAMIDE'),
 (73,'isoniazid','antibacterial','ISONIAZID'),
 (74,'clofazimine','antibacterial','CLOFAZIMINE'),
 (75,'telavancin','antibacterial','TELAVANCIN'),
 (76,'indeterminate_antibacterial','antibacterial','TICARCILLIN|PIPERACILLIN|ORITAVANCIN|PLAZOMICIN|CEPHRADINE|CEPHALOTHIN|ERAVACYCLINE|OMADACYCLINE|GEMIFLOXACIN|DELAFLOXACIN|QUINUPRISTIN|TELITHROMYCIN|DIRITHROMYCIN|PAROMOMYCIN|NEOMYCIN|DAPSONE|AZLOCILLIN|CARBENICILLIN|CEFTOBIPROLE|ANTIBIOTIC'),
 (77,'fluconazole','antifungal','FLUCONAZOLE'),
 (78,'voriconazole','antifungal','VORICONAZOLE'),
 (79,'posaconazole','antifungal','POSACONAZOLE'),
 (80,'isavuconazole','antifungal','ISAVUCONAZOLE'),
 (81,'itraconazole','antifungal','ITRACONAZOLE'),
 (82,'caspofungin','antifungal','CASPOFUNGIN'),
 (83,'micafungin','antifungal','MICAFUNGIN'),
 (84,'anidulafungin','antifungal','ANIDULAFUNGIN'),
 (85,'amphotericin','antifungal','AMPHOTERICIN'),
 (86,'flucytosine','antifungal','FLUCYTOSINE'),
 (87,'terbinafine','antifungal','TERBINAFINE'),
 (88,'griseofulvin','antifungal','GRISEOFULVIN'),
 (89,'ketoconazole','antifungal','KETOCONAZOLE'),
 (90,'fluconazole','antifungal','DIFLUCAN'),
 (91,'voriconazole','antifungal','VFEND'),
 (92,'micafungin','antifungal','MYCAMINE'),
 (93,'caspofungin','antifungal','CANCIDAS'),
 (94,'anidulafungin','antifungal','ERAXIS'),
 (95,'amphotericin','antifungal','AMBISOME|ABELCET'),
 (96,'isavuconazole','antifungal','ISAVUCONAZONIUM|CRESEMBA'),
 (97,'posaconazole','antifungal','NOXAFIL'),
 (98,'non_systemic','local','RIFAXIMIN|XIFAXAN|FIDAXOMICIN|DIFICID|NYSTATIN|MUPIROCIN|BACITRACIN')
) v(priority,agent,family,pattern);
CREATE TEMP MACRO culture_name(x) AS upper(trim(coalesce(x,'')));
CREATE TEMP MACRO culture_route_kind(route0,agent0,name0) AS CASE
 WHEN regexp_matches(culture_name(name0),'OPHTH|OTIC|TOPICAL|OINTMENT|CREAM|IRRIGAT|INHAL|NEBUL|VAGINAL|INTRATHECAL|CATHETER LOCK|INTRAVITREAL') OR agent0='non_systemic' THEN 'local'
 WHEN culture_name(route0) IN ('IV','IV DRIP','IV BOLUS','IV INFUSION','IV PUSH','IVP','IVPB','INTRAVENOUS','INTRAVENOUS PUSH','IVPB/IM','IM','INTRAMUSCULAR','SC','SQ','SUBCUT','SUBCUTANEOUS') THEN 'systemic'
 WHEN culture_name(route0) IN ('PO','PO/NG','ORAL','NG','NGT','OG','OGT','G TUBE','PEG','G-TUBE','J-TUBE','GT','PO/GT') THEN CASE WHEN agent0 IN ('vancomycin','amphotericin','gentamicin','tobramycin','amikacin','colistin','polymyxin_b','non_systemic') THEN 'local' ELSE 'systemic' END
 WHEN culture_name(route0) IN ('TP','NU','IH','PR','TD','NEB','DWELL','VG','OU','OS','OD','NAS','IR','IRR','IT','ID','LEFT EYE','RIGHT EYE','BOTH EYES','LEFT EAR','RIGHT EAR') THEN 'local' ELSE 'uncertain' END;

CREATE TEMP TABLE culture_em0 AS
SELECT c.pid,c.hid,e.emar_id,try_cast(e.pharmacy_id AS BIGINT) AS pharmacy_id,
  culture_name(e.medication) AS name,culture_name(e.event_txt) AS event,
  try_cast(e.charttime AS TIMESTAMP) AS at_time,try_cast(e.storetime AS TIMESTAMP) AS recorded
FROM src_emar e INNER JOIN cohort c ON c.pid=try_cast(e.subject_id AS BIGINT) AND c.hid=try_cast(e.hadm_id AS BIGINT)
WHERE try_cast(e.charttime AS TIMESTAMP) BETWEEN c.icu_in-INTERVAL '1 day' AND c.hospital_end;

CREATE TEMP TABLE culture_r0 AS
SELECT c.pid,c.hid,try_cast(p.pharmacy_id AS BIGINT) AS pharmacy_id,culture_name(p.drug) AS name,
 culture_name(p.route) AS route,try_cast(p.starttime AS TIMESTAMP) AS started, try_cast(p.stoptime AS TIMESTAMP) AS stopped
FROM src_prescriptions p INNER JOIN cohort c ON c.pid=try_cast(p.subject_id AS BIGINT) AND c.hid=try_cast(p.hadm_id AS BIGINT)
WHERE coalesce(culture_name(p.drug_type),'') <> 'BASE' AND try_cast(p.starttime AS TIMESTAMP)<c.hospital_end;

CREATE TEMP TABLE culture_drugs AS
WITH names AS (SELECT name FROM culture_em0 UNION SELECT name FROM culture_r0 UNION SELECT culture_name(antibiotic) FROM culture_ast)
SELECT n.name,d.agent,d.family FROM names n LEFT JOIN culture_drug_patterns d ON regexp_matches(n.name,d.pattern)
QUALIFY row_number() OVER(PARTITION BY name ORDER BY d.priority NULLS LAST)=1;

CREATE TEMP TABLE culture_rx AS SELECT r.*,d.agent,d.family,culture_route_kind(r.route,d.agent,r.name) AS route_kind
FROM culture_r0 r JOIN culture_drugs d USING(name) WHERE d.agent IS NOT NULL AND d.family<>'local' AND started IS NOT NULL AND stopped>started;

CREATE TEMP TABLE culture_ed AS
SELECT e.pid,e.hid,e.emar_id,
  count(DISTINCT nullif(culture_name(d.route),'')) AS n_route,max(nullif(culture_name(d.route),'')) AS any_route,
  bool_or(culture_name(d.complete_dose_not_given)='YES') AS partial_warning,
  bool_or(try_cast(d.dose_given AS DOUBLE)>0 OR try_cast(d.product_amount_given AS DOUBLE)>0) AS some_dose
FROM culture_em0 e JOIN src_emar_detail d ON e.emar_id=d.emar_id AND e.pid=try_cast(d.subject_id AS BIGINT)
GROUP BY e.pid,e.hid,e.emar_id;

CREATE TEMP TABLE culture_rxroute AS
SELECT pid,hid,pharmacy_id,agent,
CASE WHEN count(DISTINCT route_kind)=1 THEN min(route_kind) ELSE 'uncertain' END AS order_route
FROM culture_rx WHERE pharmacy_id IS NOT NULL GROUP BY ALL;

CREATE TEMP TABLE culture_em AS
SELECT e.*,d.agent,d.family,
 CASE WHEN coalesce(ed.n_route,0)>1 THEN 'uncertain'
      WHEN ed.n_route=1 THEN culture_route_kind(ed.any_route,d.agent,e.name)
      WHEN rr.order_route IS NOT NULL THEN rr.order_route
      ELSE culture_route_kind('',d.agent,e.name) END AS route_kind
FROM culture_em0 e JOIN culture_drugs d USING(name)
LEFT JOIN culture_ed ed USING(pid,hid,emar_id) LEFT JOIN culture_rxroute rr ON rr.pid=e.pid AND rr.hid=e.hid
 AND rr.pharmacy_id=e.pharmacy_id AND rr.agent=d.agent
WHERE e.event IN ('ADMINISTERED','DELAYED ADMINISTERED','PARTIAL ADMINISTERED','ADMINISTERED BOLUS FROM IV DRIP',
 'ADMINISTERED IN OTHER LOCATION','STARTED','RESTARTED','DELAYED STARTED','STARTED IN OTHER LOCATION')
 AND (NOT coalesce(ed.partial_warning,false) OR coalesce(ed.some_dose,false))
 AND e.at_time IS NOT NULL AND e.recorded IS NOT NULL;

CREATE TEMP TABLE culture_dose AS SELECT DISTINCT pid,hid,agent,family,at_time,recorded,route_kind
FROM culture_em WHERE agent IS NOT NULL AND family<>'local' AND route_kind<>'local';

-- Infusion confirmations and reconciliation are not counted as administered doses.
-- If a linked systemic drug lacks a definite dose, these entries can prevent a claim of absence.
CREATE TEMP TABLE culture_amb_em AS
SELECT DISTINCT e.pid,e.hid,d.agent,d.family,e.at_time,e.recorded
FROM culture_em0 e JOIN culture_drugs d USING(name)
LEFT JOIN culture_ed ed USING(pid,hid,emar_id)
LEFT JOIN culture_rxroute rr ON rr.pid=e.pid AND rr.hid=e.hid AND rr.pharmacy_id=e.pharmacy_id AND rr.agent=d.agent
WHERE d.family IN ('broad','antibacterial','antifungal') AND
 (e.event IN ('CONFIRMED','DELAYED CONFIRMED','CONFIRMED IN OTHER LOCATION','INFUSION RECONCILIATION','RATE CHANGE')
 OR (coalesce(ed.partial_warning,false) AND NOT coalesce(ed.some_dose,false)
 AND e.event IN ('ADMINISTERED','PARTIAL ADMINISTERED','DELAYED ADMINISTERED')))
 AND CASE WHEN ed.n_route=1 THEN culture_route_kind(ed.any_route,d.agent,e.name)
          ELSE coalesce(rr.order_route,'uncertain') END<>'local';
