ALTER TABLE culture_drugs RENAME TO susceptibility_transition_drugs;
CREATE TEMP TABLE culture_drugs AS WITH nm AS (SELECT DISTINCT culture_name(antibiotic) AS name FROM culture_culture_rows WHERE antibiotic IS NOT NULL)
 SELECT n.name,d.agent,d.family FROM nm n LEFT JOIN culture_drug_patterns d ON regexp_matches(n.name,d.pattern)
 QUALIFY row_number() OVER(PARTITION BY name ORDER BY d.priority NULLS LAST)=1;
