CREATE TEMP TABLE culture_raw AS
SELECT *,CASE WHEN (site_name IN ('BLOOD CULTURE','BLOOD','BLOOD, PERIPHERAL','BLOOD, CENTRAL LINE') AND
       test_label IN ('BLOOD CULTURE, ROUTINE','BLOOD CULTURE','BLOOD CULTURE ROUTINE','ROUTINE BLOOD CULTURE'))
       OR scope='dedicated_blood_fungal' THEN 'blood'
    WHEN site_name IN ('CSF','CSF;SPINAL FLUID','CEREBROSPINAL FLUID','SPINAL FLUID') THEN 'csf'
    WHEN site_name='PLEURAL FLUID' THEN 'pleural' WHEN site_name='PERITONEAL FLUID' THEN 'peritoneal'
    WHEN site_name IN ('JOINT FLUID','SYNOVIAL FLUID') THEN 'synovial' WHEN site_name='PERICARDIAL FLUID' THEN 'pericardial'
    WHEN site_name IN ('URINE','URINE,KIDNEY','URINE,URETERAL','URINE,STRAIGHT CATH','CATHETERIZED URINE') THEN 'urine'
    WHEN site_name IN ('SPUTUM','BRONCHIAL WASHINGS','BRONCHOALVEOLAR LAVAGE','MINI-BAL','BRONCHIAL BRUSH',
         'TRACHEAL ASPIRATE','ENDOTRACHEAL ASPIRATE','TRACHEAL SECRETIONS') THEN 'respiratory'
    WHEN (regexp_matches(coalesce(site_name,''),'^(DEEP|OPERATIVE|INTRAOPERATIVE|SURGICAL) (TISSUE|ABSCESS|PUS)|^(TISSUE|ABSCESS|PUS),? (DEEP|INTRAOPERATIVE|OPERATIVE)')
         OR site_name IN ('BRAIN ABSCESS','LIVER ABSCESS','SPLENIC ABSCESS','EPIDURAL ABSCESS','BRAIN BIOPSY','BONE BIOPSY')) THEN 'deep_tissue_pus'
    WHEN site_name IN ('ABSCESS','TISSUE','SWAB','FOOT CULTURE','PUS','WOUND') THEN 'wound_tissue'
    WHEN site_name IN ('FLUID,OTHER','FLUID RECEIVED IN BLOOD CULTURE BOTTLES') THEN 'other_fluid'
    ELSE 'other' END AS site_group,
    coalesce(regexp_matches(organism,'(MIXED|NORMAL|USUAL|COMMENSAL|RESPIRATORY|UROGENITAL|SKIN|ORAL|ENTERIC).*FLORA|^MIXED (CULTURE|ORGANISMS|BACTERIAL TYPES)'),false) AS flora_label,
    regexp_matches(annotation,'(MIXED|NORMAL|USUAL|COMMENSAL|RESPIRATORY|UROGENITAL|SKIN|ORAL|ENTERIC) (BACTERIAL |RESPIRATORY |UROGENITAL |SKIN |ORAL |ENTERIC )*FLORA|^THIS CULTURE CONTAINS MIXED BACTERIAL TYPES') AS flora_note,
    coalesce(regexp_matches(organism,'^((ANAEROBIC|AEROBIC) )?GRAM[ -](POSITIVE|NEGATIVE|VARIABLE)|^NON[ -]FERMENT'),false) AS morphology,
    coalesce(regexp_matches(organism,'^(STAPH(YLOCOCCUS)?[, ]+COAG(ULASE)?[ -]*(NEGATIVE|NEG)|COAGULASE[ -]NEGATIVE STAPH|STAPH(YLOCOCCUS)? (EPIDERMIDIS|HOMINIS|HAEMOLYTICUS|CAPITIS|WARNERI|SIMULANS|SACCHAROLYTICUS)|MICROCOCCUS|CUTIBACTERIUM ACNES|PROPIONIBACTERIUM ACNES|CORYNEBACTERIUM SPECIES [(]DIPHTHEROIDS[)]|DIPHTHEROIDS)'),false) OR (coalesce(regexp_matches(organism,'^BACILLUS( |$)'),false) AND NOT regexp_matches(organism,'^BACILLUS (ANTHRACIS|CEREUS)')) AS common_label,
    coalesce(regexp_matches(organism,'^(NO |NOT |NEGATIVE|CANCEL|PENDING|TEST NOT|UNABLE|REJECT|SPECIMEN|POSITIVE$|GROWTH$|ISOLATE$)'),false) AS nonisolate_label,
    regexp_matches(annotation,'^(TEST |CULTURE |SPECIMEN )?(CANCELLED|CANCELED|REJECTED|UNSATISFACTORY|NOT PERFORMED)|INSUFFICIENT (QUANTITY|SPECIMEN)|INAPPROPRIATE SPECIMEN') AS invalid_note,
    test_label IN ('GRAM STAIN','AEROBIC BOTTLE GRAM STAIN','ANAEROBIC BOTTLE GRAM STAIN') AS gram_test
FROM culture_culture_scope WHERE specimen IS NOT NULL AND scope IN ('legacy_routine','additional_routine','gram_only','dedicated_blood_fungal');

CREATE TEMP TABLE culture_culture_rows AS
WITH named AS (
 SELECT *,CASE
  WHEN org_code=90856 OR organism IS NULL OR org_code IS NULL OR flora_label OR nonisolate_label THEN NULL
  WHEN morphology THEN 'morphology_only'
  WHEN regexp_matches(organism,'(^| )(STAPH(YLOCOCCUS)?[ .]+AUREUS|MRSA($| ))') THEN 'staph_aureus'
  WHEN common_label THEN 'common_commensal'
  WHEN regexp_matches(organism,'^(ESCHERICHIA|KLEBSIELLA|ENTEROBACTER|CITROBACTER|PROTEUS|MORGANELLA|PROVIDENCIA|SERRATIA|HAFNIA|RAOULTELLA|KL(U|UY)Y?VERA|SALMONELLA|SHIGELLA|YERSINIA|PANTOEA|LECLERCIA)( |$)') THEN 'enterobacterales'
  WHEN regexp_matches(organism,'^(PSEUDOMONAS)( |$)') THEN 'pseudomonas'
  WHEN regexp_matches(organism,'^(ACINETOBACTER)( |$)') THEN 'acinetobacter'
  WHEN regexp_matches(organism,'^(ENTEROCOCCUS|ENTEROCOCCI|VANCOMYCIN[ -]RESISTANT ENTEROCOCC)') THEN 'enterococcus'
  WHEN regexp_matches(organism,'^((ALPHA |BETA |VIRIDANS |GROUP [A-G] )?(HEMOLYTIC |HAEMOLYTIC )?STREP|PNEUMOCOCCUS)') THEN 'streptococcus'
  WHEN regexp_matches(organism,'^(CANDIDA|YEAST|ASPERGILLUS|CRYPTOCOCCUS|SACCHAROMYCES|MOLD|FUSARIUM|RHODOTORULA|MALASSEZIA|KODAMAEA)( |,|$)') THEN 'yeast_fungus'
  WHEN regexp_matches(organism,'^(BACTEROIDES|PARABACTEROIDES|PREVOTELLA|PORPHYROMONAS|FUSOBACTERIUM|CLOSTRIDIUM|CLOSTRIDIOIDES|FINEGOLDIA|PEPTONIPHILUS|PEPTOSTREPTOCOCCUS|VEILLONELLA|PARVIMONAS|BILOPHILA)( |$)') THEN 'anaerobe'
  WHEN regexp_matches(organism,'^(ABIOTROPHIA|ACHROMOBACTER|ACTINOBACILLUS|ACTINOMYCES|AEROCOCCUS|AEROMONAS|AGGREGATIBACTER|ALCALIGENES|ARCANOBACTERIUM|BACILLUS|BIFIDOBACTERIUM|BORDETELLA|BREVIBACTERIUM|BURKHOLDERIA|CAMPYLOBACTER|CAPNOCYTOPHAGA|CHRYSEOBACTERIUM|COMAMONAS|CORYNEBACTERIUM|CUTIBACTERIUM|DERMABACTER|DIALISTER|EIKENELLA|ELIZABETHKINGIA|ERYSIPELOTHRIX|EUBACTERIUM|FLAVOBACTERIUM|GARDNERELLA|GEMELLA|GRANULICATELLA|HAEMOPHILUS|KOCURIA|LACTOBACILLUS|LACTOCOCCUS|LEPTOTRICHIA|LEUCONOSTOC|LISTERIA|MICROBACTERIUM|MICROCOCCUS|MORAXELLA|MYCOBACTERIUM|NEISSERIA|NOCARDIA|OCHROBACTRUM|OLIGELLA|PAENIBACILLUS|PASTEURELLA|PEDIOCOCCUS|PLESIOMONAS|PROPIONIBACTERIUM|RALSTONIA|RHODOCOCCUS|ROSEOMONAS|ROTHIA|SCHAALIA|SHEWANELLA|SPHINGOMONAS|STAPHYLOCOCCUS|STENOTROPHOMONAS|TRUEPERELLA|VAGOCOCCUS|VIBRIO)( |/|,|$)|^PRESUMPTIVE GARDNERELLA') THEN 'other_bacterium'
  ELSE NULL END AS organism_category
 FROM culture_raw WHERE NOT gram_test
)
SELECT *,CASE WHEN invalid_note OR coalesce(regexp_matches(organism,'^(CANCEL|REJECT|PENDING|NOT PERFORMED)'),false) THEN 'uninterpretable'
   WHEN organism_category IS NOT NULL THEN 'isolate'
   WHEN flora_label OR flora_note THEN 'flora'
   WHEN (org_code=90856 AND (organism IS NULL OR organism IN ('NEGATIVE','NO GROWTH','NO GROWTH.'))) OR organism IN ('NEGATIVE','NO GROWTH','NO GROWTH.') THEN 'no_growth'
   WHEN (organism IS NULL OR nonisolate_label) AND
    (regexp_matches(annotation,'^NO GROWTH([.]|$|, <[0-9,]+ CFU/ML[.]?$)')
      OR (test_label='ANAEROBIC CULTURE' AND regexp_matches(annotation,'^NO ANAEROBES ISOLATED[.]?$'))
      OR (scope='dedicated_blood_fungal' AND regexp_matches(annotation,'^NO FUNG(US|I) (ISOLATED|RECOVERED)[.]?$')))
    AND NOT regexp_matches(annotation,'TO DATE|SO FAR|PRELIM|REINCUBAT|PENDING|AT [0-9]+ (H|DAY)|AFTER [0-9]+ H') THEN 'no_growth'
   WHEN organism IS NULL AND org_code IS NULL AND antibiotic IS NULL AND interpretation IS NULL AND isolate_number IS NULL
     AND stored>=collected AND annotation IN ('','FINAL','FINAL.') THEN 'null_no_growth'
   WHEN organism IS NOT NULL AND org_code IS NOT NULL AND NOT nonisolate_label THEN 'unknown_label'
   ELSE 'uninterpretable' END AS row_class
FROM named;

CREATE TEMP TABLE culture_collection_audit AS
SELECT pid,hid,sid,specimen,min(collected) AS collected,min(site_group) AS site_group,
       count(DISTINCT collected) AS n_clocks,count(*) FILTER(WHERE collected IS NULL) AS null_clocks,
       count(DISTINCT site_group) AS n_sites,count(*) AS source_rows
FROM culture_culture_rows GROUP BY pid,hid,sid,specimen;

CREATE TEMP TABLE culture_index_samples AS
SELECT a.* FROM culture_collection_audit a
WHERE a.n_clocks=1 AND a.null_clocks=0 AND a.n_sites=1 AND EXISTS(
 SELECT 1 FROM icu_intervals i JOIN cohort c ON c.pid=i.pid AND c.hid=i.hid
 WHERE i.pid=a.pid AND i.hid=a.hid AND a.collected>=i.began
   AND (a.collected<i.ended OR (i.ended=c.tm AND a.collected=c.tm)));

CREATE TEMP TABLE culture_work_rows AS
SELECT r.*,concat('o',cast(r.org_code AS VARCHAR),'/n',coalesce(cast(r.isolate_number AS VARCHAR),'?')) AS isolate_key
FROM culture_culture_rows r JOIN culture_index_samples i USING(pid,hid,sid,specimen);

CREATE TEMP TABLE culture_ast AS
SELECT DISTINCT pid,hid,sid,specimen,isolate_key,antibiotic,interpretation,
       CASE WHEN stored>=collected THEN stored END AS ast_time
FROM culture_work_rows
WHERE row_class='isolate' AND antibiotic IS NOT NULL AND interpretation IN ('S','I','R');

CREATE TEMP TABLE culture_blood_comp AS
SELECT r.pid,r.hid,r.specimen,r.collected,
    bool_and(r.row_class IN ('no_growth','null_no_growth')) AS only_no_growth,
    CASE WHEN bool_and(r.stored IS NOT NULL AND r.stored>=r.collected) THEN max(r.stored) END AS result_epoch,
    count(DISTINCT r.organism) FILTER(WHERE r.row_class='isolate') AS n_org
FROM culture_culture_rows r JOIN culture_collection_audit a USING(pid,hid,sid,specimen)
WHERE r.site_group='blood' AND r.scope<>'dedicated_blood_fungal' AND a.n_clocks=1 AND a.null_clocks=0 AND a.n_sites=1
GROUP BY r.pid,r.hid,r.specimen,r.collected;

CREATE TEMP TABLE culture_blood_org AS
SELECT pid,hid,specimen,collected,organism,min(stored) FILTER(WHERE stored>=collected) AS org_epoch
FROM culture_culture_rows WHERE site_group='blood' AND row_class='isolate'
GROUP BY pid,hid,specimen,collected,organism;

CREATE TEMP TABLE culture_complete_clock AS
SELECT pid,hid,specimen,CASE WHEN bool_and(stored IS NOT NULL AND stored>=collected) THEN max(stored) END AS spec_epoch
FROM culture_work_rows GROUP BY pid,hid,specimen;

CREATE TEMP TABLE culture_iso0 AS
SELECT r.pid,r.hid,r.sid,r.specimen,r.isolate_key,min(r.organism) AS organism,min(r.organism_category) AS organism_category,
       min(r.site_group) AS site_group,min(r.collected) AS collected,
       bool_or(r.common_label) AS is_commensal,bool_or(regexp_matches(r.organism,'^CANDIDA( |$)')) AS is_candida,
       bool_or(r.organism_category='staph_aureus' AND
          (regexp_matches(r.organism,'METHICILLIN[ -](RESISTANT|RES)|(^| )MRSA($| )') OR
          (r.antibiotic IN ('OXACILLIN','CEFOXITIN') AND r.interpretation='R'))) AS is_mrsa,
       min(r.stored) FILTER(WHERE r.stored>=r.collected) AS first_org_time,
       max(r.stored) FILTER(WHERE r.stored>=r.collected) AS last_org_time,
       count(DISTINCT r.organism)>1 OR (bool_or(r.isolate_number IS NULL) AND bool_or(k.numbered_isolate)) AS label_conflict,
       bool_or(r.isolate_number IS NULL) AS isolate_number_missing,
       bool_or(r.stored IS NULL OR r.stored<r.collected) AS incomplete_org_clock
FROM culture_work_rows r JOIN (
 SELECT pid,hid,specimen,org_code,bool_or(isolate_number IS NOT NULL) AS numbered_isolate
 FROM culture_work_rows WHERE row_class='isolate' GROUP BY pid,hid,specimen,org_code
) k USING(pid,hid,specimen,org_code) WHERE r.row_class='isolate'
GROUP BY r.pid,r.hid,r.sid,r.specimen,r.isolate_key;

CREATE TEMP TABLE culture_iso AS
WITH companion AS (
 SELECT r.*,
   EXISTS (SELECT 1 FROM culture_blood_comp b JOIN culture_blood_org o USING(pid,hid,specimen,collected)
     WHERE r.site_group='blood' AND r.is_commensal AND b.pid=r.pid AND b.hid=r.hid AND b.specimen<>r.specimen
       AND b.collected<>r.collected AND abs(epoch(b.collected-r.collected))<=86400 AND o.organism=r.organism AND o.org_epoch<=t.spec_epoch) AS matching_draw,
   EXISTS (SELECT 1 FROM culture_blood_comp b WHERE r.site_group='blood' AND r.is_commensal AND b.pid=r.pid AND b.hid=r.hid
       AND b.specimen<>r.specimen AND b.collected<>r.collected AND abs(epoch(b.collected-r.collected))<=86400
       AND b.only_no_growth AND b.result_epoch<=t.spec_epoch) AS negative_draw,
   EXISTS (SELECT 1 FROM culture_blood_org b WHERE b.pid=r.pid AND b.hid=r.hid AND regexp_matches(b.organism,'^CANDIDA( |$)')
      AND abs(epoch(b.collected-r.collected))<=172800 AND b.org_epoch<=t.spec_epoch) AS concurrent_blood_candida
 FROM culture_iso0 r LEFT JOIN culture_complete_clock t USING(pid,hid,specimen)
)
SELECT *,CASE WHEN label_conflict THEN 'ambiguous_isolate'
  WHEN organism_category='morphology_only' THEN 'morphology_only'
  WHEN is_candida AND site_group IN ('urine','respiratory') AND concurrent_blood_candida THEN 'nonsterile_candida_with_blood'
  WHEN is_candida AND site_group IN ('urine','respiratory') THEN 'nonsterile_candida_only'
  WHEN site_group='blood' AND is_commensal AND matching_draw THEN 'repeat_commensal'
  WHEN site_group='blood' AND is_commensal AND negative_draw THEN 'possible_contamination'
  WHEN site_group='blood' AND is_commensal THEN 'commensal_uncertain'
  ELSE 'reported_isolate' END AS clinical_class
FROM companion;

CREATE TEMP TABLE culture_gram_clause AS
SELECT r.pid,r.hid,r.specimen,r.stored AS gram_time,upper(trim(v.clause)) AS clause
FROM culture_raw r JOIN culture_index_samples i USING(pid,hid,sid,specimen)
CROSS JOIN unnest(regexp_split_to_array(concat_ws('. ',r.organism,r.annotation),'[.;]')) v(clause)
WHERE r.gram_test AND r.stored>=i.collected AND (r.collected IS NULL OR (r.collected=i.collected AND r.stored>=r.collected))
  AND NOT regexp_matches(r.annotation,'(EXTENSIVE CONTAMINATION|UNSUITABLE|UNSATISFACTORY|REJECTED|TEST CANCEL|NOT PERFORMED|RESULTS ARE INVALID|CORRECTED REPORT|PREVIOUSLY REPORTED IN ERROR)');

CREATE TEMP TABLE culture_gram_evidence AS
WITH matched AS (
 SELECT *,regexp_matches(clause,'(GRAM[ -]*POSITIVE (COCC|ROD|BACILL|BACTER|COCCOBACILL)|(^| )GPC($| )|(^| )GPR($| ))') AS gp,
          regexp_matches(clause,'(GRAM[ -]*NEGATIVE (COCC|ROD|BACILL|BACTER|COCCOBACILL)|(^| )GNC($| )|(^| )GNR($| ))') AS gn,
          regexp_matches(clause,'GRAM[ -]*VARIABLE (COCC|ROD|BACILL|BACTER|COCCOBACILL)|(^| )YEAST( CELLS| WITH|$)|BUDDING YEAST') AS other_morph
 FROM culture_gram_clause
 WHERE NOT regexp_matches(clause,'(^| )(NO|NOT|NONE|NEGATIVE FOR|WITHOUT|ABSENCE OF|UNABLE|QUESTIONABLE|POSSIBLE|CANNOT EXCLUDE)( |$)|RULE[ -]?OUT|QUALITY CONTROL')
)
SELECT DISTINCT pid,hid,specimen,gram_time,CASE WHEN gp AND gn THEN 'both' WHEN gp THEN 'gram_positive'
 WHEN gn THEN 'gram_negative' ELSE 'other_morphology' END AS gram_polarity
FROM matched WHERE gp OR gn OR other_morph;

CREATE TEMP TABLE culture_test_class AS
SELECT pid,hid,sid,specimen,test_label,bool_or(row_class IN ('no_growth','null_no_growth')) AS neg,
       bool_or(row_class IN ('unknown_label','uninterpretable','flora','isolate')) AS other
FROM culture_work_rows GROUP BY pid,hid,sid,specimen,test_label;

CREATE TEMP TABLE culture_spec AS
WITH raw_times AS (
 SELECT pid,hid,sid,specimen,min(collected) AS collected,min(site_group) AS site_group,
  min(stored) FILTER(WHERE stored>=collected) AS first_known_update,
  max(stored) FILTER(WHERE stored>=collected) AS last_known_update,
  max(stored) FILTER(WHERE stored>=collected AND stored<=tm) AS last_pre_routine,
  min(stored) FILTER(WHERE stored>=collected AND stored>tm) AS first_post_routine,
  bool_and(stored IS NOT NULL AND stored>=collected) AS timing_complete,
  bool_or(row_class='no_growth') AS explicit_no_growth,bool_or(row_class='null_no_growth') AS structural_no_growth,
  bool_and(scope='legacy_routine') AS legacy_scope_only,bool_or(scope='dedicated_blood_fungal') AS dedicated_blood_fungal,bool_or(row_class='flora') AS mixed_flora,
  bool_or(row_class='unknown_label') AS has_unknown_label,bool_or(row_class='uninterpretable') AS has_uninterpretable
 FROM culture_work_rows GROUP BY pid,hid,sid,specimen
), isolates AS (
 SELECT pid,hid,specimen,count(*) AS n_isolates,count(*) FILTER(WHERE is_commensal) AS n_common_isolates,
   bool_or(clinical_class IN ('reported_isolate','repeat_commensal')) AS reported,
   bool_or(clinical_class='possible_contamination') AS contamination,
   bool_or(clinical_class='nonsterile_candida_only') AS colonization,
   bool_or(clinical_class='nonsterile_candida_with_blood') AS candida_with_blood,
   bool_or(clinical_class IN ('ambiguous_isolate','morphology_only','commensal_uncertain')) AS uncertain_iso,
   min(first_org_time) AS first_org_time,max(last_org_time) AS last_org_time
 FROM culture_iso GROUP BY pid,hid,specimen
), gram AS (
 SELECT g.pid,g.hid,g.specimen,
  bool_or(g.gram_time<=c.tm) AS gram_morph_pre,
  bool_or(g.gram_time<=c.tm AND g.gram_polarity IN ('gram_positive','both')) AS gram_gp_pre,
  min(g.gram_time) AS first_gram_morph_time
 FROM culture_gram_evidence g JOIN cohort c USING(pid,hid) GROUP BY g.pid,g.hid,g.specimen
), base AS (
 SELECT t.*,c.tm,c.hospital_end,c.ward_end,c.era_lower,c.era_upper,c.age_at_exit,
  t.collected=c.tm AS sampled_at_handoff,
  t.site_group IN ('blood','csf','pleural','peritoneal','synovial','pericardial','deep_tissue_pus') AS sterile,
  t.site_group IN ('blood','csf','pleural','peritoneal','synovial','pericardial') AS strict_sterile_fluid,
  t.site_group='deep_tissue_pus' AS deep_tissue_pus,
  coalesce(i.candida_with_blood,false) AS nonsterile_candida_with_blood,
  coalesce(i.colonization,false) AS nonsterile_candida_only,
  CASE WHEN t.timing_complete THEN t.last_known_update END AS final_time,
  CASE WHEN t.last_known_update>c.tm THEN true WHEN t.timing_complete THEN false END AS pending,
  t.last_pre_routine IS NOT NULL AS prior_routine,
  coalesce(i.n_isolates,0) AS n_isolates,coalesce(i.n_common_isolates,0) AS n_common_isolates,
  i.first_org_time,i.last_org_time,coalesce(i.first_org_time<=c.tm,false) AS pre_named,
  coalesce(g.gram_morph_pre,false) AS gram_pos_pre,coalesce(g.gram_gp_pre,false) AS gram_positive_polarity_pre,
  g.first_gram_morph_time,coalesce(i.reported,false) AS has_reported_isolate,coalesce(i.uncertain_iso,false) AS has_uncertain_isolate,
  CASE WHEN i.reported THEN 'positive'
    WHEN i.uncertain_iso OR i.candida_with_blood OR t.has_unknown_label THEN 'indeterminate'
    WHEN i.colonization THEN 'likely_colonization'
    WHEN i.contamination THEN 'likely_contaminant'
    WHEN t.mixed_flora THEN 'mixed_flora'
    WHEN NOT t.has_uninterpretable AND coalesce(n.all_neg,false) THEN 'no_growth'
    ELSE 'indeterminate' END AS outcome_class
 FROM raw_times t JOIN cohort c USING(pid,hid,sid) LEFT JOIN isolates i USING(pid,hid,specimen)
 LEFT JOIN gram g USING(pid,hid,specimen)
 LEFT JOIN (SELECT pid,hid,specimen,bool_and(neg AND NOT other) AS all_neg
   FROM culture_test_class GROUP BY pid,hid,specimen) n USING(pid,hid,specimen)
), windows AS (
 SELECT *,
  coalesce(final_time BETWEEN tm-INTERVAL '48 hours' AND tm AND (final_time=tm OR EXISTS (
    SELECT 1 FROM icu_intervals x WHERE x.pid=b.pid AND x.hid=b.hid AND b.final_time>=x.began AND b.final_time<x.ended)),false) AS pre_handoff_48,
  coalesce(final_time>tm AND final_time<=tm+INTERVAL '48 hours' AND final_time<hospital_end,false) AS post_handoff_48,
  coalesce(final_time>tm AND final_time<=tm+INTERVAL '48 hours' AND final_time<hospital_end AND final_time<ward_end,false) AS first_ward48
 FROM base b
)
SELECT *,CASE WHEN final_time IS NULL THEN 'unknown'
 WHEN pre_handoff_48 THEN 'pre_icu_48h'
 WHEN final_time<=tm AND EXISTS (SELECT 1 FROM icu_intervals x WHERE x.pid=w.pid AND x.hid=w.hid AND w.final_time>=x.began AND w.final_time<x.ended) THEN 'earlier_icu'
 WHEN final_time<=tm THEN 'pre_other' WHEN first_ward48 THEN 'post_first_ward_48h'
 WHEN post_handoff_48 THEN 'post_other_inpatient_48h' WHEN final_time<hospital_end THEN 'later_inpatient'
 ELSE 'after_hospital_end' END AS report_phase
FROM windows w;
