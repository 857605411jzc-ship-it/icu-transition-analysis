CREATE TEMP TABLE culture_reports AS
SELECT s.*,s.final_time AS report_time,'ward' AS phase
FROM culture_spec s WHERE s.pending AND s.outcome_class='positive'
  AND s.final_time>s.tm AND s.final_time<=s.tm+INTERVAL '48 hours' AND s.final_time<s.hospital_end;

CREATE TEMP TABLE culture_windows AS
SELECT *,dense_rank() OVER (ORDER BY pid,hid,lo,hi,exclude_at) AS win FROM (
 SELECT r.pid,r.hid,r.specimen,r.phase,r.report_time,'transition' AS mode,
        r.tm-INTERVAL '24 hours' AS lo,least(r.tm+INTERVAL '6 hours',r.report_time,r.hospital_end) AS hi,
        r.report_time AS exclude_at
 FROM culture_reports r
 UNION ALL
 SELECT c.pid,c.hid,NULL::BIGINT,'ward',NULL::TIMESTAMP,'red',
        c.tm-INTERVAL '24 hours',c.tm,'infinity'::TIMESTAMP FROM cohort c
) w;

CREATE TEMP TABLE culture_w AS SELECT DISTINCT win,pid,hid,lo,hi,exclude_at FROM culture_windows WHERE mode='red';

CREATE TEMP TABLE culture_seen AS
SELECT w.win,count(e.emar_id)>0 AS seen,
 count(e.emar_id) FILTER(WHERE e.at_time>=w.hi-INTERVAL '12 hours')>0 AS near,
 count(DISTINCT e.at_time)>=2 AS multiple
FROM culture_w w LEFT JOIN culture_em e ON e.pid=w.pid AND e.hid=w.hid AND e.at_time BETWEEN w.lo AND w.hi
 AND e.at_time<w.exclude_at AND e.recorded<=w.hi AND e.recorded<w.exclude_at
GROUP BY w.win;

CREATE TEMP TABLE culture_wdose AS
SELECT DISTINCT w.win,d.agent,d.family,d.route_kind FROM culture_w w JOIN culture_dose d ON d.pid=w.pid AND d.hid=w.hid
 AND d.at_time BETWEEN w.lo AND w.hi AND d.at_time<w.exclude_at AND d.recorded<=w.hi AND d.recorded<w.exclude_at;

CREATE TEMP TABLE culture_worder AS SELECT DISTINCT w.win,r.agent,r.family,r.route_kind FROM culture_w w JOIN culture_rx r
 ON r.pid=w.pid AND r.hid=w.hid AND r.started<=w.hi AND r.started<w.exclude_at AND r.stopped>w.lo AND r.route_kind<>'local';

CREATE TEMP TABLE culture_wamb AS SELECT DISTINCT w.win,a.agent,a.family FROM culture_w w JOIN culture_amb_em a ON a.pid=w.pid AND a.hid=w.hid AND a.at_time BETWEEN w.lo AND w.hi AND a.at_time<w.exclude_at AND a.recorded<=w.hi AND a.recorded<w.exclude_at;

CREATE TEMP TABLE culture_wsource AS SELECT s.*,
 CASE WHEN s.seen THEN 'emar' WHEN EXISTS(SELECT 1 FROM culture_worder r WHERE r.win=s.win) THEN 'prescription_proxy' ELSE 'unknown' END AS drug_source,
 EXISTS(SELECT 1 FROM culture_worder r WHERE s.win=r.win AND NOT EXISTS
    (SELECT 1 FROM culture_wdose d WHERE d.win=r.win AND d.agent=r.agent AND d.route_kind='systemic')) OR EXISTS(SELECT 1 FROM culture_wamb a WHERE a.win=s.win AND NOT EXISTS (SELECT 1 FROM culture_wdose d WHERE d.win=s.win AND d.agent=a.agent AND d.route_kind='systemic')) AS additional_order,
 EXISTS(SELECT 1 FROM culture_worder r WHERE r.win=s.win AND r.family IN ('broad','antibacterial')) OR EXISTS(SELECT 1 FROM culture_wamb a WHERE a.win=s.win AND a.family IN ('broad','antibacterial')) AS ab_order
FROM culture_seen s;

CREATE TEMP TABLE culture_red_flags AS
WITH flags AS (SELECT p.pid,p.hid,p.sid,p.specimen,p.tm,coalesce(p.sterile,false) AS sterile_flag,
  (coalesce(p.gram_pos_pre,false) AND NOT coalesce(p.sterile,false)) AS gram_flag,
 CASE WHEN EXISTS(SELECT 1 FROM culture_wdose d WHERE d.win=w.win AND d.route_kind='systemic' AND d.family IN ('antibacterial','broad')) THEN false
      WHEN ss.near AND ss.multiple AND NOT ss.ab_order AND NOT EXISTS(SELECT 1 FROM culture_wdose d WHERE d.win=w.win AND d.family IN ('antibacterial','broad')) THEN true ELSE NULL END AS off_abx_flag
FROM culture_spec p JOIN culture_windows w ON w.pid=p.pid AND w.hid=p.hid AND w.mode='red'
JOIN culture_wsource ss USING(win) WHERE p.pending) SELECT *, (sterile_flag OR gram_flag OR off_abx_flag) AS red_flag FROM flags;

CREATE TEMP TABLE culture_tested AS
SELECT r.pid,r.hid,r.specimen,a.isolate_key,d.agent,
 CASE WHEN count(DISTINCT upper(a.interpretation))=1 THEN min(upper(a.interpretation)) ELSE 'conflict' END AS sir
FROM culture_reports r JOIN culture_ast a USING(pid,hid,specimen) JOIN culture_drugs d ON d.name=culture_name(a.antibiotic)
WHERE a.ast_time<=r.report_time AND d.agent IS NOT NULL AND upper(a.interpretation) IN ('S','I','R')
GROUP BY r.pid,r.hid,r.specimen,a.isolate_key,d.agent;

CREATE TEMP TABLE culture_competing AS
SELECT DISTINCT a.pid,a.hid,a.specimen FROM culture_reports a
JOIN culture_iso i ON i.pid=a.pid AND i.hid=a.hid AND i.specimen=a.specimen
JOIN culture_iso b ON b.pid=a.pid AND b.hid=a.hid AND upper(b.organism)<>upper(i.organism)
 AND b.first_org_time BETWEEN a.report_time-INTERVAL '72 hours' AND a.report_time
WHERE b.clinical_class IN ('reported_isolate','repeat_commensal','nonsterile_candida_with_blood');
