CREATE TEMP TABLE coverage_iso_profile AS
WITH isolates AS (
 SELECT i.*,r.report_time,r.sterile,r.era_lower,r.tm,r.hospital_end,r.ward_end,r.phase,
    r.has_unknown_label
 FROM culture_reports r JOIN culture_iso i USING(pid,hid,specimen)
 WHERE r.outcome_class='positive' AND i.first_org_time<=r.report_time
), phenotype AS (
 SELECT i.pid,i.hid,i.specimen,i.isolate_key,
   bool_or(t.sir='S' AND t.agent IN ('cefoxitin','oxacillin')) AS meth_s,
   bool_or(t.sir IN ('I','R','conflict') AND t.agent IN ('cefoxitin','oxacillin')) AS meth_ns,
   bool_or(t.sir='S' AND t.agent='ampicillin') AS amp_s,
   bool_or(t.sir='S' AND t.agent='ceftriaxone') AS cro_s,
   count(DISTINCT t.agent) FILTER(WHERE t.sir IN ('R','I','conflict') AND t.agent IN ('ertapenem','meropenem','imipenem','cefepime')) AS beta_warning,
   count(DISTINCT t.agent) FILTER(WHERE t.sir IN ('R','I','conflict') AND t.agent IN ('meropenem','imipenem','cefepime','ceftazidime','piperacillin_tazobactam','aztreonam')) AS pa_warning,
   count(DISTINCT t.agent) FILTER(WHERE t.sir IN ('R','I','conflict') AND t.agent IN ('micafungin','caspofungin','anidulafungin')) AS echino_warning
 FROM isolates i LEFT JOIN culture_tested t USING(pid,hid,specimen,isolate_key)
 GROUP BY i.pid,i.hid,i.specimen,i.isolate_key
)
SELECT i.*,p.* EXCLUDE(pid,hid,specimen,isolate_key),
 i.organism_category='staph_aureus' AND NOT i.is_mrsa AND coalesce(p.meth_s,false) AND NOT coalesce(p.meth_ns,false) AS mssa,
 (i.organism_category='yeast_fungus') AS fungal,
 regexp_matches(i.organism,'^(ESCHERICHIA COLI|KLEBSIELLA PNEUMONIAE|KLEBSIELLA OXYTOCA|PROTEUS MIRABILIS)($|[^A-Z])') AS common_enteric,
 regexp_matches(i.organism,'^(ENTEROBACTER CLOACAE|KLEBSIELLA AEROGENES|ENTEROBACTER AEROGENES|CITROBACTER FREUNDII|HAFNIA ALVEI)($|[^A-Z])') AS ampc_risk,
 regexp_matches(i.organism,'^PSEUDOMONAS AERUGINOSA($|[^A-Z])') AS pa,
 regexp_matches(i.organism,'^ENTEROCOCCUS FAECALIS($|[^A-Z])') AS efaecalis,
 regexp_matches(i.organism,'^(STREPTOCOCCUS PYOGENES|GROUP A STREPTOCOCCUS)($|[^A-Z])') AS gas,
 CASE WHEN i.clinical_class IN ('possible_contamination','nonsterile_candida_only') THEN 'low'
      WHEN i.clinical_class NOT IN ('reported_isolate','repeat_commensal') OR i.label_conflict
           OR (i.organism_category='yeast_fungus' AND NOT i.sterile) THEN 'unknown'
      ELSE 'eligible' END AS target_type
FROM isolates i JOIN phenotype p USING(pid,hid,specimen,isolate_key);

CREATE TEMP TABLE coverage_drug_activity AS
WITH candidates AS (
 SELECT DISTINCT agent,family FROM culture_drug_patterns WHERE family<>'local'
), matrix AS (
 SELECT i.*,d.agent,d.family,t.sir,
   CASE
    WHEN i.ampc_risk AND i.site_group<>'urine' AND d.agent IN ('ceftriaxone','ceftazidime','cefotaxime') THEN 'ampc_invasive_site'
    WHEN d.agent IN ('nitrofurantoin','fosfomycin') THEN 'lower_urinary_indication_unverified'
    WHEN d.agent='daptomycin' AND i.site_group='respiratory' THEN 'respiratory_daptomycin'
    WHEN d.agent IN ('rifampin','rifabutin') THEN 'adjunct_only'
    WHEN i.organism_category='enterococcus' AND d.agent IN ('gentamicin','streptomycin','amikacin','tobramycin') THEN 'adjunct_only'
    WHEN i.site_group='csf' AND d.agent NOT IN ('meropenem','cefepime','ceftazidime','ceftriaxone','cefotaxime','vancomycin','oxacillin','nafcillin','ampicillin','penicillin_g','trimethoprim_sulfamethoxazole','linezolid') THEN 'cns_exposure_unverified'
    WHEN i.fungal AND i.site_group='csf' THEN 'cns_fungal_evaluation'
    WHEN i.site_group='blood' AND i.organism_category='staph_aureus' AND d.agent IN ('linezolid','clindamycin','doxycycline','gentamicin','erythromycin','azithromycin','ciprofloxacin','levofloxacin') THEN 'bloodstream_indication_unverified'
    ELSE NULL END AS site_guard,
   CASE
    WHEN i.is_mrsa AND d.agent IN ('oxacillin','nafcillin','dicloxacillin','cefazolin','ceftriaxone','cefepime','cefotaxime','meropenem','imipenem','ertapenem','piperacillin_tazobactam','ampicillin_sulbactam','amoxicillin_clavulanate','cephalexin','cefuroxime','cefoxitin') THEN 'MRSA_standard_beta_lactam'
    WHEN i.organism_category='enterococcus' AND d.agent IN ('cefazolin','ceftriaxone','cefepime','ceftazidime','cefotaxime','cefuroxime','cefoxitin','cephalexin','cefpodoxime','cefdinir','ertapenem') THEN 'enterococcus_no_standalone_activity'
    WHEN i.pa AND d.agent IN ('ceftriaxone','ertapenem','cefazolin','cefotaxime','ampicillin','amoxicillin','amoxicillin_clavulanate','ampicillin_sulbactam','cefuroxime','cephalexin') THEN 'pseudomonas_off_spectrum'
    WHEN i.organism_category IN ('enterobacterales','pseudomonas','acinetobacter') AND d.agent IN ('vancomycin','linezolid','daptomycin','nafcillin','oxacillin','clindamycin','metronidazole') THEN 'aerobic_GNR_off_spectrum'
    WHEN i.organism_category IN ('staph_aureus','enterococcus','streptococcus') AND d.agent IN ('aztreonam','metronidazole') THEN 'aerobic_GPC_off_spectrum'
    ELSE NULL END AS inactive_rule,
   CASE
    WHEN i.mssa AND d.agent IN ('nafcillin','oxacillin','cefazolin','ceftriaxone','cefepime','cefotaxime','cefuroxime','piperacillin_tazobactam','ampicillin_sulbactam','amoxicillin_clavulanate','meropenem','imipenem','ertapenem') THEN 'MSSA_methicillin_surrogate'
    WHEN i.efaecalis AND i.amp_s AND d.agent IN ('amoxicillin','ampicillin_sulbactam','amoxicillin_clavulanate','piperacillin_tazobactam') THEN 'E_faecalis_ampicillin_surrogate'
    ELSE NULL END AS surrogate_rule,
   CASE
    WHEN i.common_enteric AND i.cro_s AND i.beta_warning <= CASE WHEN t.sir IN ('I','R','conflict') AND d.agent IN ('ertapenem','meropenem','imipenem','cefepime') THEN 1 ELSE 0 END AND d.agent IN ('meropenem','imipenem','ertapenem','cefepime','cefotaxime') THEN 'common_enteric_CRO_S_broader_beta_lactam'
    WHEN i.organism_category='staph_aureus' AND d.agent='vancomycin' THEN 'S_aureus_vancomycin'
    WHEN i.organism_category='staph_aureus' AND d.agent='linezolid' AND i.site_group='respiratory' THEN 'S_aureus_respiratory_linezolid'
    WHEN i.organism_category='staph_aureus' AND d.agent='daptomycin' AND i.site_group='blood' THEN 'S_aureus_blood_daptomycin'
    WHEN i.pa AND i.pa_warning <= CASE WHEN t.sir IN ('I','R','conflict') AND d.agent IN ('meropenem','imipenem','cefepime','ceftazidime','piperacillin_tazobactam','aztreonam') THEN 1 ELSE 0 END AND d.agent IN ('ceftazidime','cefepime','meropenem','imipenem','piperacillin_tazobactam') THEN 'P_aeruginosa_empiric_antipseudomonal'
    WHEN i.gas AND d.agent IN ('penicillin_g','ampicillin','amoxicillin') THEN 'GAS_penicillin_class'
    WHEN regexp_matches(i.organism,'^CANDIDA (ALBICANS|TROPICALIS)($|[^A-Z])') AND i.sterile AND i.site_group<>'csf'
     AND i.echino_warning <= CASE WHEN t.sir IN ('I','R','conflict') AND d.agent IN ('micafungin','caspofungin','anidulafungin') THEN 1 ELSE 0 END AND d.agent IN ('anidulafungin','caspofungin','micafungin') THEN 'sterile_Candida_expected_echinocandin'
    ELSE NULL END AS expected_rule
 FROM coverage_iso_profile i CROSS JOIN candidates d LEFT JOIN culture_tested t
 ON t.pid=i.pid AND t.hid=i.hid AND t.specimen=i.specimen AND t.isolate_key=i.isolate_key AND t.agent=d.agent
), ruled AS (
 SELECT *,CASE
  WHEN target_type<>'eligible' AND NOT (fungal AND clinical_class='reported_isolate' AND NOT label_conflict) THEN 'uncertain_identity_or_indication'
  WHEN sir='conflict' THEN 'uncertain_conflicting_AST'
  WHEN sir='R' THEN 'inactive_direct_R' WHEN sir='I' THEN 'inactive_direct_I'
  WHEN (fungal AND family<>'antifungal') OR (NOT fungal AND family='antifungal') THEN 'inactive_wrong_class'
  WHEN sir='S' AND inactive_rule IS NOT NULL THEN 'uncertain_discordant_phenotype'
  WHEN site_guard IS NOT NULL THEN 'uncertain_site_or_role'
  WHEN sir='S' THEN 'active_direct'
  WHEN inactive_rule IS NOT NULL THEN 'inactive_intrinsic'
  WHEN surrogate_rule IS NOT NULL THEN 'active_surrogate'
  WHEN expected_rule IS NOT NULL THEN 'active_expected'
  ELSE 'uncertain_untested' END AS activity
 FROM matrix
)
SELECT pid,hid,specimen,isolate_key,agent,family,sir,activity,inactive_rule,surrogate_rule,expected_rule,site_guard,
 activity IN ('active_direct','active_surrogate','active_expected') AS is_active,
 activity IN ('active_direct','active_surrogate') AS strict_active,
 starts_with(activity,'inactive_') AS is_inactive,
 (activity IN ('active_direct','active_surrogate') AND site_group<>'csf' AND
  ((mssa AND agent IN ('cefazolin','nafcillin','oxacillin')) OR
   (organism_category='enterococcus' AND amp_s AND agent='ampicillin') OR
   (common_enteric AND cro_s AND agent='ceftriaxone'))) AS narrow_option
FROM ruled;

CREATE TEMP TABLE coverage_regimen_input AS
WITH ongoing AS (
 SELECT DISTINCT w.win,r.agent FROM coverage_med_windows w JOIN coverage_rx r ON r.pid=w.pid AND r.hid=w.hid
  AND r.family='broad' AND r.route_kind='systemic' AND r.started<=w.order_anchor AND r.started<w.exclude_at AND r.stopped>w.order_anchor
  AND (r.entered IS NULL OR (r.entered<=w.order_anchor AND r.entered<w.exclude_at))
), metrics AS (
 SELECT i.pid,i.hid,i.specimen,i.isolate_key,w.win,w.mode,w.drug_source,
        bool_or(i.target_type='eligible') AS eligible,
        coalesce(bool_or(m.route_kind='systemic' AND a.is_active),false) AS active,
        coalesce(bool_or(m.route_kind='systemic' AND a.strict_active),false) AS strict_active,
        coalesce(bool_or(m.route_kind='systemic' AND a.activity='active_direct'),false) AS direct,
        coalesce(bool_or(m.route_kind='systemic' AND a.activity='active_surrogate'),false) AS surrogate,
        coalesce(bool_or(m.route_kind='systemic' AND a.activity='active_expected'),false) AS expected,
        count(m.agent) FILTER(WHERE (i.fungal AND m.family='antifungal') OR (NOT i.fungal AND m.family IN ('broad','antibacterial'))) AS relevant,
        count(m.agent) FILTER(WHERE ((i.fungal AND m.family='antifungal') OR (NOT i.fungal AND m.family IN ('antibacterial','broad'))) AND (m.route_kind<>'systemic' OR a.agent IS NULL OR NOT a.is_inactive)) AS possible_active,
        coalesce(bool_or(m.route_kind='systemic' AND a.activity='inactive_direct_I'),false) AS any_i,
        coalesce(bool_or(m.route_kind='systemic' AND a.narrow_option),false) AS narrow_on,
        coalesce(bool_or(m.route_kind='systemic' AND m.family='broad' AND a.is_active AND q.agent IS NOT NULL),false) AS broad_active,
        coalesce(bool_or(m.route_kind='systemic' AND m.family='broad' AND a.strict_active AND q.agent IS NOT NULL),false) AS strict_broad_active,
        coalesce(bool_or(m.route_kind='systemic' AND NOT a.narrow_option),false) AS non_narrow_on
 FROM coverage_iso_profile i JOIN coverage_med_windows w USING(pid,hid,specimen,phase,report_time)
 LEFT JOIN coverage_med_regimen m USING(win)
 LEFT JOIN ongoing q ON q.win=w.win AND q.agent=m.agent
 LEFT JOIN coverage_drug_activity a ON a.pid=i.pid AND a.hid=i.hid AND a.specimen=i.specimen AND a.isolate_key=i.isolate_key AND a.agent=m.agent
 GROUP BY i.pid,i.hid,i.specimen,i.isolate_key,w.win,w.mode,w.drug_source
), opts AS (
 SELECT pid,hid,specimen,isolate_key,bool_or(narrow_option) AS has_narrow FROM coverage_drug_activity GROUP BY ALL
)
SELECT m.*,i.target_type,i.clinical_class,i.label_conflict,i.organism,i.fungal,i.site_group,i.phase,i.report_time,i.sterile,i.tm,
 i.hospital_end,i.ward_end,i.era_lower,i.has_unknown_label,w.zero_supported,w.adequate_emar,
 (i.era_lower>=2020 AND w.drug_source='emar' AND w.adequate_emar AND NOT w.order_only_extra AND NOT w.ambiguous_drug) AS late_emar,
 o.has_narrow,c.specimen IS NOT NULL AS competing
FROM metrics m JOIN coverage_iso_profile i USING(pid,hid,specimen,isolate_key)
 JOIN coverage_med_windows w USING(pid,hid,specimen,phase,report_time,win,mode,drug_source)
 JOIN opts o USING(pid,hid,specimen,isolate_key) LEFT JOIN culture_competing c USING(pid,hid,specimen);

CREATE TEMP MACRO coverage_grade(which_active,which_broad,require_robust_i,target,known_med,zero_ok,maybe_active,non_s_i,has_option,broad_narrow_competing,on_narrow,other_drug) AS
 CASE WHEN target='low' THEN 'T3' WHEN target<>'eligible' OR NOT known_med THEN 'U'
      WHEN which_active THEN CASE WHEN which_broad AND has_option AND NOT broad_narrow_competing THEN 'T2'
        WHEN on_narrow AND NOT other_drug THEN 'T3' ELSE 'COVERED' END
      WHEN zero_ok AND maybe_active=0 AND NOT(require_robust_i AND non_s_i) THEN 'T1' ELSE 'U' END;

CREATE TEMP TABLE coverage_isolate_tiers AS
WITH g AS (
 SELECT *,
  coverage_grade(active,broad_active,false,target_type,drug_source<>'unknown',zero_supported,possible_active,any_i,has_narrow,competing,narrow_on,non_narrow_on) AS grade,
  coverage_grade(strict_active,strict_broad_active,false,target_type,drug_source<>'unknown',zero_supported,possible_active,any_i,has_narrow,competing,narrow_on,non_narrow_on) AS strict_grade,
  coverage_grade(active,broad_active,true,target_type,drug_source<>'unknown',zero_supported,possible_active,any_i,has_narrow,competing,narrow_on,non_narrow_on) AS i_uncertain_grade
 FROM coverage_regimen_input
)
SELECT *,CASE WHEN target_type='low' THEN 'low_clinical_relevance'
 WHEN target_type='unknown' AND (NOT fungal OR clinical_class<>'reported_isolate' OR label_conflict) THEN 'indeterminate'
 WHEN active THEN 'active' WHEN zero_supported AND drug_source<>'unknown' AND relevant=0 THEN 'no_relevant_agent'
 WHEN zero_supported AND drug_source<>'unknown' AND possible_active=0 THEN 'all_options_discordant' ELSE 'indeterminate' END AS pharmacological_state,
 CASE WHEN target_type='low' THEN 'low_likelihood_target'
 WHEN target_type<>'eligible' THEN 'isolate_or_indication_uncertain'
 WHEN grade='T1' AND relevant=0 THEN 'no_documented_relevant_agent'
 WHEN grade='T1' THEN 'all_regimen_options_discordant'
 WHEN grade='U' AND (drug_source='unknown' OR NOT zero_supported) THEN 'medication_evidence_insufficient'
 WHEN grade='U' THEN 'activity_route_or_indication_uncertain'
 WHEN grade='T2' THEN 'narrower_supported_option'
 WHEN grade='T3' THEN 'targeted_narrow_regimen'
 ELSE 'active_regimen_no_established_narrowing' END AS reason
FROM g;

CREATE TEMP MACRO coverage_combine(tier,unknown_companion,eligible_target) AS
 CASE WHEN bool_or(tier='T1') THEN 'T1' WHEN bool_or(tier='U' OR unknown_companion) THEN 'U'
 WHEN bool_or(tier='T2') AND count(*) FILTER(WHERE eligible_target)>1 THEN 'COVERED'
 WHEN bool_or(tier='T2') THEN 'T2' WHEN bool_or(tier='COVERED') THEN 'COVERED' ELSE 'T3' END;

CREATE TEMP TABLE coverage_tiers AS
WITH g AS (
 SELECT pid,hid,specimen,phase,report_time,mode,win,drug_source,site_group,tm,hospital_end,ward_end,era_lower,late_emar,
  coverage_combine(grade,has_unknown_label,target_type='eligible') AS grade,coverage_combine(strict_grade,has_unknown_label,target_type='eligible') AS strict_grade,
  coverage_combine(i_uncertain_grade,has_unknown_label,target_type='eligible') AS i_uncertain_grade,
  bool_or(target_type='eligible') AS has_target,
  bool_or(grade='T1' AND relevant=0) AS uncovered,
  bool_or(grade='U' AND reason='medication_evidence_insufficient') AS med_unknown,
  bool_or(grade='U' AND reason='isolate_or_indication_uncertain') AS iso_unknown,
  bool_or(has_unknown_label) AS unknown_label,
  bool_or(target_type='eligible' AND active AND NOT strict_active) AS expected_only,
 CASE WHEN bool_or(pharmacological_state IN ('no_relevant_agent','all_options_discordant')) THEN 'potential_gap'
 WHEN bool_or(pharmacological_state='indeterminate' OR has_unknown_label) THEN 'indeterminate'
 WHEN bool_or(pharmacological_state='active') THEN 'active' ELSE 'low_clinical_relevance' END AS pharmacological_state
 FROM coverage_isolate_tiers GROUP BY ALL
)
SELECT *,has_target AND grade IN ('T2','T3','COVERED') AS covered,
 has_target AND strict_grade IN ('T2','T3','COVERED') AS strict_covered,
 CASE WHEN grade='T1' AND uncovered THEN 'no_documented_relevant_agent' WHEN grade='T1' THEN 'all_regimen_options_discordant'
   WHEN grade='T2' THEN 'narrower_supported_option' WHEN grade='T3' AND has_target THEN 'targeted_narrow_regimen'
   WHEN grade='T3' THEN 'low_likelihood_target' WHEN grade='COVERED' THEN 'active_regimen_no_established_narrowing'
   WHEN iso_unknown OR unknown_label THEN 'isolate_or_indication_uncertain' WHEN med_unknown THEN 'medication_evidence_insufficient'
   ELSE 'activity_route_or_indication_uncertain' END AS reason
FROM g;
