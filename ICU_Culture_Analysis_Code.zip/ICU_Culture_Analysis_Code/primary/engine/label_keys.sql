CREATE TEMP TABLE culture_micro AS
SELECT c.pid,c.hid,c.sid,c.tm,c.icu_in,c.hospital_end,c.ward_end,c.era_lower,c.era_upper,c.age_at_exit,
    try_cast(m.micro_specimen_id AS BIGINT) AS specimen,try_cast(m.charttime AS TIMESTAMP) AS collected,
    try_cast(m.chartdate AS DATE) AS collected_day,try_cast(m.storetime AS TIMESTAMP) AS stored,
    try_cast(m.storedate AS DATE) AS stored_day,upper(trim(m.test_name)) AS test_label,
    upper(trim(m.spec_type_desc)) AS site_name,try_cast(m.org_itemid AS BIGINT) AS org_code,
    nullif(upper(trim(m.org_name)),'') AS organism,try_cast(m.isolate_num AS INTEGER) AS isolate_number,
    nullif(upper(trim(m.ab_name)),'') AS antibiotic,nullif(upper(trim(m.interpretation)),'') AS interpretation,
    upper(regexp_replace(trim(coalesce(m.comments,'')),'[[:space:]]+',' ','g')) AS annotation
FROM src_microbiologyevents m JOIN cohort c ON c.pid=try_cast(m.subject_id AS BIGINT) AND c.hid=try_cast(m.hadm_id AS BIGINT);

CREATE TEMP TABLE culture_culture_scope AS
SELECT *, CASE
 WHEN regexp_matches(coalesce(site_name,''),'SURVEILLANCE|INFECTION CONTROL|MRSA SCREEN|STAPH AUREUS SWAB|CLINICAL SCREEN|ENVIRONMENTAL') THEN 'excluded_screen'
 WHEN test_label IN ('GRAM STAIN','AEROBIC BOTTLE GRAM STAIN','ANAEROBIC BOTTLE GRAM STAIN') THEN 'gram_only'
 WHEN test_label IN ('BLOOD CULTURE, ROUTINE','URINE CULTURE','RESPIRATORY CULTURE','WOUND CULTURE','TISSUE',
      'ANAEROBIC CULTURE','FLUID CULTURE','FLUID CULTURE IN BOTTLES') THEN 'legacy_routine'
 WHEN test_label IN ('BLOOD CULTURE','BLOOD CULTURE ROUTINE','ROUTINE BLOOD CULTURE','CSF CULTURE',
      'CEREBROSPINAL FLUID CULTURE','SPINAL FLUID CULTURE','CULTURE, CSF','CSF CULTURE AND GRAM STAIN',
      'BODY FLUID CULTURE','STERILE BODY FLUID CULTURE','PLEURAL FLUID CULTURE','PERITONEAL FLUID CULTURE',
      'PERICARDIAL FLUID CULTURE','JOINT FLUID CULTURE','SYNOVIAL FLUID CULTURE','TISSUE CULTURE','DEEP TISSUE CULTURE',
      'DEEP WOUND CULTURE','ABSCESS CULTURE','PUS CULTURE','AEROBIC CULTURE','AEROBIC BACTERIAL CULTURE') THEN 'additional_routine'
 WHEN test_label IN ('BLOOD/FUNGAL CULTURE','FUNGAL BLOOD CULTURE') AND regexp_matches(coalesce(site_name,''),'^BLOOD') THEN 'dedicated_blood_fungal'
 ELSE 'other_test' END AS scope
FROM culture_micro;

CREATE TEMP TABLE ua_candidates AS
WITH raw AS (
 SELECT c.pid,c.hid,c.tm,c.icu_in,c.era_lower,c.era_upper,try_cast(m.micro_specimen_id AS BIGINT) AS specimen,
   try_cast(m.hadm_id AS BIGINT) AS row_hid,try_cast(m.charttime AS TIMESTAMP) AS collection_time,
   upper(trim(m.spec_type_desc)) AS source_label,upper(trim(m.test_name)) AS test_label
 FROM src_microbiologyevents m JOIN cohort c ON c.pid=try_cast(m.subject_id AS BIGINT)
 WHERE try_cast(m.micro_specimen_id AS BIGINT) IS NOT NULL AND try_cast(m.charttime AS TIMESTAMP) BETWEEN c.icu_in AND c.tm
)
SELECT DISTINCT r.*,CASE WHEN regexp_matches(source_label,'URINE|URINARY|URETER|NEPHROSTOM') THEN 'urine'
   WHEN regexp_matches(source_label,'^BLOOD([ ,]|$)') THEN 'blood'
   WHEN regexp_matches(source_label,'SPUTUM|RESPIRATORY|BRONCH|TRACHE|MINI.BAL') THEN 'respiratory' END AS site,
   bool_or(row_hid=hid) OVER(PARTITION BY pid,specimen) IS TRUE AS any_matching_hid
FROM raw r WHERE regexp_matches(test_label,'CULTUR|TISSUE|GRAM STAIN') AND NOT regexp_matches(
   coalesce(test_label,'') || ' ' || coalesce(source_label,''),'SCREEN|SURVEILLANCE|INFECTION CONTROL|ENVIRONMENTAL|VIRAL CULTURE')
   AND (collection_time=tm OR EXISTS (SELECT 1 FROM icu_intervals i WHERE i.pid=r.pid AND i.hid=r.hid
                                    AND r.collection_time>=i.began AND r.collection_time<i.ended));

CREATE TEMP TABLE ua_urines AS
SELECT pid,hid,specimen,CASE WHEN min(era_upper)<=2019 THEN 'early' WHEN min(era_lower)>=2020 THEN 'late'
 ELSE 'boundary_or_unknown' END AS era,bool_or(any_matching_hid) AS match_hid,
 string_agg(DISTINCT test_label,' | ' ORDER BY test_label) AS test_profile,
 string_agg(DISTINCT source_label,' | ' ORDER BY source_label) AS site_profile
FROM ua_candidates WHERE site IS NOT NULL
GROUP BY pid,hid,specimen HAVING count(DISTINCT site)=1 AND min(site)='urine';


CREATE TEMP TABLE reflex_keys AS
SELECT u.era,u.pid,u.hid,u.specimen FROM ua_urines u
WHERE u.test_profile='REFLEX URINE CULTURE' AND u.site_profile='URINE' AND u.match_hid
AND NOT EXISTS (SELECT 1 FROM culture_culture_scope sc WHERE sc.pid=u.pid AND sc.hid=u.hid AND sc.specimen=u.specimen
    AND sc.scope IN ('legacy_routine','additional_routine','dedicated_blood_fungal','gram_only'));

UPDATE culture_culture_scope AS sc SET scope='additional_routine' FROM reflex_keys k WHERE sc.pid=k.pid AND sc.hid=k.hid
 AND sc.specimen=k.specimen AND sc.test_label='REFLEX URINE CULTURE' AND sc.site_name='URINE' AND sc.scope='other_test';
