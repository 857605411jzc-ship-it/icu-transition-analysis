# All records returned by this function are private. The caller retains these in memory.
baseline_partition <- function(con) {
  patients <- DBI::dbGetQuery(con, "
    WITH next_icu AS (
      SELECT c.pid,min(l.began) AS returned FROM cohort c JOIN loc l USING(pid,hid)
      WHERE l.unit_category='ICU' AND l.ended>l.began AND l.began>c.tm AND l.began<c.hospital_end GROUP BY c.pid)
    SELECT c.pid,c.age_at_exit AS age,epoch(c.tm-c.icu_in)/86400 AS icu_days,
      CASE WHEN c.outgoing_unit IN ('Coronary Care Unit (CCU)','Cardiac Vascular Intensive Care Unit (CVICU)') THEN 'cardiac'
        WHEN c.outgoing_unit IN ('Medical Intensive Care Unit (MICU)','Medical/Surgical Intensive Care Unit (MICU/SICU)') THEN 'medical_or_mixed'
        ELSE 'surgical_or_neuro' END AS icu_type,c.ward_group AS ward_type,
      CASE WHEN c.era_upper<=2019 THEN 'early' WHEN c.era_lower>=2020 THEN 'late' ELSE 'boundary_or_unknown' END AS era,
      epoch(c.hospital_end-c.tm)/3600 AS hospital_h,epoch(n.returned-c.tm)/3600 AS returned_h,
      c.died_at IS NOT NULL AND c.died_at<=c.discharge_at AS died
      FROM cohort c LEFT JOIN next_icu n USING(pid)")
  pending <- DBI::dbGetQuery(con, "
    SELECT s.pid,s.specimen,k.specimen IS NOT NULL AS reflex,s.site_group,s.outcome_class,
      s.post_handoff_48 AND s.outcome_class='positive' AS positive,
      epoch(s.final_time-s.tm)/3600 AS report_h,t.grade,t.covered
    FROM culture_spec s LEFT JOIN reflex_keys k USING(pid,hid,specimen)
    LEFT JOIN coverage_tiers t ON t.pid=s.pid AND t.hid=s.hid AND t.specimen=s.specimen AND t.report_time=s.final_time
      AND t.mode='transition' AND t.phase='ward'
    WHERE s.pending IS TRUE")
  stopifnot(!anyDuplicated(patients$pid),!anyDuplicated(pending[c("pid","specimen")]),
            all(pending$pid %in% patients$pid),all(pending$site_group[pending$reflex]=="urine"))
  list(patients=patients, pending=pending)
}

wilson_percent <- function(n,N) {
  if (!N) return(rep(NA_real_,3))
  z <- qnorm(.975); p <- n/N; a <- 1+z^2/N
  center <- (p+z^2/(2*N))/a
  width <- z/a*sqrt(p*(1-p)/N+z^2/(4*N^2))
  100*c(p,max(0,center-width),min(1,center+width))
}
group_sites <- function(site) {
  ifelse(site %in% c("blood","csf","pleural","peritoneal","pericardial","synovial","deep_tissue_pus"),"sterile_or_deep",
         ifelse(site %in% c("urine","respiratory"),"urine_or_respiratory","other_site"))
}
# Firth's Jeffreys-prior penalized binomial likelihood. The full-design information
# penalty is retained when profiling the exposure coefficient under a constraint.
firth_profile <- function(X,y,term=2L) {
  stopifnot(all(is.finite(X)),all(y %in% 0:1),qr(X)$rank==ncol(X),length(y)==nrow(X))
  eval <- function(b,gradient=FALSE) {
    eta <- drop(X%*%b)
    # Opposite-tail evaluation keeps nonzero Fisher weights on either side of zero.
    pr <- plogis(eta); w <- pr*plogis(-eta)
    weighted <- X*sqrt(w)
    ch <- tryCatch(chol(crossprod(weighted)),error=function(e) NULL)
    if(is.null(ch)) return(if(gradient) rep(0,ncol(X)) else -1e100)
    if(!gradient) return(sum(y*eta-pmax(eta,0)-log1p(exp(-abs(eta))))+sum(log(diag(ch))))
    lever <- colSums(backsolve(ch,t(weighted),transpose=TRUE)^2)
    drop(crossprod(X,y-pr+(.5-pr)*lever))
  }
  solve <- function(start, fixed=NULL) {
    free <- if(is.null(fixed)) seq_along(start) else setdiff(seq_along(start),term)
    make <- function(a) { b <- start; b[free] <- a; if(!is.null(fixed)) b[term] <- fixed; b }
    opt <- optim(start[free],function(a) -eval(make(a)),function(a) -eval(make(a),TRUE)[free],
          method="BFGS",control=list(maxit=200L,reltol=1e-13))
    b <- make(opt$par)
    if(opt$convergence!=0L || max(abs(eval(b,TRUE)[free]))>1e-3 || !is.finite(opt$value))
      stop("Penalized likelihood did not converge")
    list(b=b,ll=-opt$value)
  }
  fit <- solve(numeric(ncol(X))); best <- fit$b[term]
  threshold <- fit$ll-qchisq(.95,1)/2
  discrepancy <- function(theta) solve(fit$b,theta)$ll-threshold
  root <- function(sign) {
    width <- 1
    while(width<128 && discrepancy(best+sign*width)>0) width <- width*2
    a <- sort(c(best,best+sign*width))
    uniroot(discrepancy, a, tol=1e-7)$root
  }
  setNames(exp(c(best,root(-1),root(1))),c("estimate","lower95","upper95"))
}

landmark_effect <- function(z,endpoint) {
  y <- as.numeric(z[[endpoint]])
  full <- cbind(intercept=rep(1,nrow(z)),discordance=as.numeric(z$group=="discordant"),
    age10=(z$age-65)/10,sterile=as.numeric(z$site=="sterile_or_deep"))
  continuous <- endpoint=="restricted_days28"
  groups <- table(factor(z$group,levels=c("discordant","covered")))
  row <- data.frame(endpoint,estimator=if(continuous) "linear_HC3" else "firth_profile",
    effect_type=if(continuous) "mean_difference_days" else "OR",target_n=as.integer(groups[1]),
    reference_n=as.integer(groups[2]),events=if(continuous) NA_integer_ else sum(y),estimate=NA_real_,
    lower95=NA_real_,upper95=NA_real_,status="estimated")
  if(any(groups<11) || (!continuous && (sum(y)<11 || sum(1-y)<11))) {
    row$status <- "insufficient_support"; return(row)
  }
  if(any(!is.finite(full)) || any(!is.finite(y))) stop("Missing model predictors or endpoint")
  if(qr(full)$rank<ncol(full)) { row$status <- "rank_deficient"; return(row) }
  if(!continuous) {
    vals <- firth_profile(full,y)
  } else {
    fit <- lm.fit(full,y); bread <- chol2inv(chol(crossprod(full)))
    leverage <- rowSums((full%*%bread)*full)
    if(any(1-leverage<1e-10)) { row$status <- "unit_leverage"; return(row) }
    meat <- crossprod(full*(fit$residuals/(1-leverage))); se <- sqrt((bread%*%meat%*%bread)[2,2])
    vals <- fit$coefficients[2]+c(0,-1,1)*qt(.975,fit$df.residual)*se
  }
  if(any(!is.finite(vals))) stop("Nonfinite model estimate")
  row[1,c("estimate","lower95","upper95")] <- as.list(unname(vals))
  row
}

summarize_baseline <- function(parts,out) {
  p <- do.call(rbind,lapply(parts,function(x) x$patients))
  a <- do.call(rbind,lapply(parts,function(x) x$pending))
  stopifnot(!anyDuplicated(p$pid),!anyDuplicated(a[c("pid","specimen")]),
            !anyNA(p[c("pid","age","icu_days","hospital_h","died")]),all(a$pid %in% p$pid))
  # All pending accessions contribute to the denominator.
  rate <- function(n,N,support=n) if(support<11 || N<11) rep(NA_real_,3) else wilson_percent(n,N)
  cut_count <- function(n) ifelse(is.na(n),NA_character_,ifelse(n<11,"<11",as.character(n)))
  quant <- function(x) if(length(x)<11) rep(NA_real_,3) else unname(quantile(x,c(.5,.25,.75)))
  baseline <- groups <- models <- sites <- classes <- flow <- list()
  for(scope in c("expanded","frozen")) {
    u <- if(scope=="expanded") a else a[!a$reflex,,drop=FALSE]
    v <- u[u$positive,,drop=FALSE]
    v$gap <- v$grade %in% "T1"
    p$stratum <- ifelse(p$pid %in% v$pid[v$gap],"positive_gap",ifelse(p$pid %in% v$pid,"positive_no_gap",
                  ifelse(p$pid %in% u$pid,"pending_no_positive","no_pending")))
    v$site <- group_sites(v$site_group)
    # Count distinct patients supporting specimen-level cells throughout.
    low_yield <- u$outcome_class %in% c("no_growth","mixed_flora","likely_contaminant","likely_colonization")
    for(k in c("combined_low_yield","no_growth","mixed_flora","likely_contaminant","likely_colonization","positive","indeterminate")) {
      sel <- if(k=="combined_low_yield") low_yield else u$outcome_class %in% k
      n <- sum(sel); N <- nrow(u); np <- length(unique(u$pid[sel])); ci <- rate(n,N,np)
      classes[[length(classes)+1L]] <- data.frame(scope,outcome_class=k,n=if(np<11) "<11" else cut_count(n),
        N=cut_count(N),support_people=cut_count(np),percent=ci[1],lower95=ci[2],upper95=ci[3])
    }
    for(k in c("sterile_or_deep","urine_or_respiratory","other_site","blood","urine","respiratory")) {
      sub <- v[which(v$site==k | v$site_group==k),,drop=FALSE]
      n <- sum(sub$gap); N <- nrow(sub)
      mp <- length(unique(sub$pid[sub$gap])); pp <- length(unique(sub$pid)); ci <- rate(n,N,mp)
      sites[[length(sites)+1L]] <- data.frame(scope,site=k,positive_specimens=if(pp<11) "<11" else cut_count(N),
        mismatch_specimens=if(mp<11) "<11" else cut_count(n),positive_people=cut_count(pp),mismatch_people=cut_count(mp),
        percent=ci[1],lower95=ci[2],upper95=ci[3])
    }
    for(st in c("all","no_pending","pending_no_positive","positive_no_gap","positive_gap")) {
      z <- if(st=="all") p else p[p$stratum==st,,drop=FALSE]
      N <- nrow(z)
      add <- function(variable,level,n,ci=rep(NA_real_,3),q=rep(NA_real_,3))
        data.frame(scope,stratum=st,variable,level,n=cut_count(n),N=cut_count(N),percent=ci[1],lower95=ci[2],upper95=ci[3],median=q[1],q1=q[2],q3=q[3])
      baseline[[length(baseline)+1L]] <- add("cohort_size","",N)
      baseline[[length(baseline)+1L]] <- add("age_years","",N,q=quant(z$age))
      baseline[[length(baseline)+1L]] <- add("index_icu_days","",N,q=quant(z$icu_days))
      for(var in c("icu_type","ward_type","era")) for(lev in sort(unique(p[[var]]))) {
        n <- sum(z[[var]]==lev)
        baseline[[length(baseline)+1L]] <- add(var,lev,n,rate(n,N))
      }
    }
    # Index the FIRST positive accession before considering treatment or later events.
    v <- v[order(v$pid,v$report_h,v$specimen),,drop=FALSE]
    first <- v[!duplicated(v$pid),,drop=FALSE]
    z <- p[match(first$pid,p$pid),,drop=FALSE]
    z$site <- first$site
    z$group <- ifelse(first$gap,"discordant",ifelse(first$covered %in% TRUE,"covered","unresolved"))
    status <- z$group
    exited <- z$hospital_h<=48
    status[exited] <- ifelse(z$died[exited],"death_by_landmark","live_discharge_by_landmark")
    status[is.finite(z$returned_h) & z$returned_h<=48] <- "ICU_return_by_landmark"
    nr <- table(factor(status,levels=c("discordant","covered","unresolved","death_by_landmark","live_discharge_by_landmark","ICU_return_by_landmark")))
    flow[[length(flow)+1L]] <- data.frame(scope,status=names(nr),n=cut_count(as.integer(nr)),N=cut_count(nrow(z)))
    z <- z[status %in% c("discordant","covered"),,drop=FALSE]
    z$icu_return7 <- as.integer(is.finite(z$returned_h) & z$returned_h<=168)
    z$hospital_death <- as.integer(z$died)
    z$posttransfer_los_days <- z$hospital_h/24
    z$restricted_days28 <- pmin(28,z$posttransfer_los_days)-2
    for(group in c("discordant","covered")) {
      subset <- z[z$group==group,,drop=FALSE]; N <- nrow(subset)
      for(ep in c("icu_return7","remaining_days28","posttransfer_los_days")) {
        cont <- ep %in% c("remaining_days28","posttransfer_los_days")
        x <- subset[[if(ep=="remaining_days28") "restricted_days28" else ep]]
        n <- if(cont) N else sum(x); ci <- if(cont) rep(NA_real_,3) else rate(n,N)
        q <- if(cont) quant(x) else rep(NA_real_,3)
        groups[[length(groups)+1L]] <- data.frame(scope,group,endpoint=ep,n=cut_count(n),N=cut_count(N),percent=ci[1],lower95=ci[2],upper95=ci[3],
           mean=if(cont && N>=11) mean(x) else NA_real_,median=q[1],q1=q[2],q3=q[3])
      }
    }
    for(ep in c("icu_return7","restricted_days28")) {
      row <- landmark_effect(z,ep)
      row[c("target_n","reference_n","events")] <- lapply(row[c("target_n","reference_n","events")],cut_count)
      models[[length(models)+1L]] <- cbind(data.frame(scope),row)
    }
  }
  outputs <- list(baseline=baseline,site_rates=sites,pending_classes=classes,timestamp_landmark_flow=flow,
                  outcome_groups=groups,outcome_models=models)
  for(name in names(outputs)) write.csv(do.call(rbind,outputs[[name]]),file.path(out,paste0(name,".csv")),row.names=FALSE,na="")
  paste0(names(outputs),".csv")
}
