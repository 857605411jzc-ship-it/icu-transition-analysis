admissions_lookup <- function(con,cohort_query,file) {
  before <- file.info(file)[c('size','mtime')]
  source <- if (grepl('[.]parquet$',file,ignore.case=TRUE)) 'read_parquet(%s)' else if(grepl('[.]csv([.]gz)?$',file,ignore.case=TRUE))
    "read_csv(%s,header=true,all_varchar=true,sample_size=2048)" else stop('Expected admissions.csv.gz, admissions.csv or admissions.parquet')
  DBI::dbExecute(con,paste('CREATE TEMP VIEW therapy_all_cohort AS',cohort_query))
  table <- sprintf(source,as.character(DBI::dbQuoteString(con,file)))
  # One file query, restricted to the identity, discharge date, death time and discharge flag.
  query <- paste0("WITH a AS (SELECT try_cast(subject_id AS BIGINT) AS pid,try_cast(hadm_id AS BIGINT) AS hid,\n",
    "try_cast(hospital_expire_flag AS INTEGER) AS expiry_flag,try_cast(dischtime AS TIMESTAMP) AS discharge,try_cast(deathtime AS TIMESTAMP) AS death FROM ",table,
    ") SELECT c.pid,c.hid,a.expiry_flag,a.hid IS NOT NULL AS found, a.discharge IS NOT DISTINCT FROM c.discharge_at AS discharge_agrees,\n",
    "a.death IS NOT DISTINCT FROM c.died_at AS death_time_agrees FROM therapy_all_cohort c LEFT JOIN a USING(pid,hid)")
  v <- DBI::dbGetQuery(con,query)
  n <- DBI::dbGetQuery(con,'SELECT count(*) AS n FROM therapy_all_cohort')$n
  if (!identical(before,file.info(file)[c('size','mtime')]) || nrow(v)!=n || anyDuplicated(v$pid) ||
      anyNA(v) || !all(v$expiry_flag %in% c(0,1)) || !all(v$found & v$discharge_agrees & v$death_time_agrees))
    stop('Admissions identity, uniqueness, flag completeness or cached time check failed')
  v[c("pid","hid","expiry_flag")]
}
