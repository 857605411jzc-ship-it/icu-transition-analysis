mortality_partition <- function(con) {
  q <- function(sql) DBI::dbGetQuery(con,sql)
  people <- q("
    WITH next_icu AS (
      SELECT c.pid,c.hid,min(l.began) AS returned FROM cohort c JOIN loc l USING(pid,hid)
      WHERE l.unit_category='ICU' AND l.ended>l.began AND l.began>c.tm AND l.began<c.hospital_end
      GROUP BY c.pid,c.hid
    )
    SELECT c.pid,c.hid,c.age_at_exit AS age,epoch(c.hospital_end-c.tm)/3600 AS hospital_h,
       epoch(n.returned-c.tm)/3600 AS return_h, a.expiry_flag,
       CASE WHEN c.died_at IS NULL THEN 'missing'
            WHEN c.died_at<=c.discharge_at THEN 'by_discharge'
            ELSE 'after_discharge' END AS death_time
    FROM cohort c LEFT JOIN therapy_admissions a USING(pid,hid) LEFT JOIN next_icu n USING(pid,hid)")
  source_n <- as.integer(q("SELECT count(*) AS n FROM cohort")$n)
  if (nrow(people)!=source_n || anyDuplicated(people$pid) ||
      anyNA(people[c("pid","hid","age","hospital_h","expiry_flag","death_time")]) ||
      any(!people$expiry_flag %in% 0:1))
    stop("Admissions expiry flag missing, invalid, duplicated, or not linked to an index admission.")
  records <- q("
    SELECT s.pid,s.hid,s.specimen,s.site_group,k.specimen IS NOT NULL AS reflex,
      epoch(s.final_time-s.tm)/3600 AS report_h, t.grade,t.covered
    FROM culture_spec s LEFT JOIN reflex_keys k USING(pid,hid,specimen)
    LEFT JOIN coverage_tiers t ON t.pid=s.pid AND t.hid=s.hid AND t.specimen=s.specimen AND t.report_time=s.final_time
      AND t.mode='transition' AND t.phase='ward'
    WHERE s.pending IS TRUE AND s.post_handoff_48 AND s.outcome_class='positive'")
  stopifnot(!anyDuplicated(records[c("pid","hid","specimen")]),
            all(records$report_h>0 & records$report_h<=48),all(records$pid %in% people$pid),
            all(records$site_group[records$reflex]=="urine"))
  list(people=people,records=records)
}

summarize_mortality <- function(parts,out) {
  p <- do.call(rbind,lapply(parts,function(v) v$people))
  r <- do.call(rbind,lapply(parts,function(v) v$records))
  stopifnot(!anyDuplicated(p$pid),!anyDuplicated(r[c("pid","hid","specimen")]),
            all(r$pid %in% p$pid),all(p$expiry_flag %in% 0:1))
  count <- function(n) ifelse(is.na(n),NA_character_,ifelse(n<11,"<11",as.character(n)))
  tables <- list(groups=list(),models=list(),flow=list(),audit=list())
  levels_status <- c("discordant","covered","unresolved","death_by_landmark","live_discharge_by_landmark","ICU_return_by_landmark")
  for(scope in c("expanded","frozen")) {
    v <- if(scope=="expanded") r else r[!r$reflex,,drop=FALSE]
    v <- v[order(v$pid,v$report_h,v$specimen),,drop=FALSE]
    first <- v[!duplicated(v$pid),,drop=FALSE]
    z <- p[match(first$pid,p$pid),,drop=FALSE]
    stopifnot(all(z$hid==first$hid))
    z$site <- group_sites(first$site_group)
    z$group <- ifelse(first$grade %in% "T1","discordant",ifelse(first$covered %in% TRUE,"covered","unresolved"))
    z$time_death <- z$death_time=="by_discharge"; z$flag <- as.logical(z$expiry_flag)
    for(definition in c("timestamp","composite")) {
      z$hospital_death <- as.integer(if(definition=="timestamp") z$time_death else z$time_death | z$flag)
      exited <- z$hospital_h<=48; prev <- is.finite(z$return_h) & z$return_h<=48
      status <- z$group
      status[exited] <- ifelse(z$hospital_death[exited]==1L,"death_by_landmark","live_discharge_by_landmark")
      status[prev] <- "ICU_return_by_landmark"
      flow <- table(factor(status,levels=levels_status))
      d <- z[status %in% c("discordant","covered"),,drop=FALSE]
      tables$flow[[length(tables$flow)+1L]] <- data.frame(scope,definition,status=names(flow),n=count(as.integer(flow)),N=count(nrow(z)))
      for(g in c("discordant","covered")) {
        sub <- d[d$group==g,,drop=FALSE]; N <- nrow(sub); n <- sum(sub$hospital_death)
        ci <- if(min(n,N)<11) rep(NA_real_,3) else wilson_percent(n,N)
        tables$groups[[length(tables$groups)+1L]] <- data.frame(scope,definition,group=g,endpoint="hospital_death",
          n=count(n),N=count(N),percent=ci[1],lower95=ci[2],upper95=ci[3])
        if(definition=="composite") {
          # Mutually exclusive status of each death-positive (time OR discharge flag)
          # index record. Disjoint small cells are masked before leaving the machine.
          types <- c("time_and_flag","time_only","flag_missing_time","flag_after_discharge")
          src <- c(sum(sub$time_death & sub$flag),sum(sub$time_death & !sub$flag),
                   sum(sub$flag & sub$death_time=="missing"),sum(sub$flag & sub$death_time=="after_discharge"))
          stopifnot(sum(src)==n)
          tables$audit[[length(tables$audit)+1L]] <- data.frame(scope,group=g,evidence=types,
              n=count(src),N=count(N))
        }
      }
      m <- landmark_effect(d,"hospital_death")
      m[c("target_n","reference_n","events")] <- lapply(m[c("target_n","reference_n","events")],count)
      tables$models[[length(tables$models)+1L]] <- cbind(data.frame(scope,definition),m)
    }
  }
  labels <- c(groups="death_groups.csv",models="death_models.csv",flow="death_flow.csv",audit="death_sources.csv")
  for(k in names(tables)) write.csv(do.call(rbind,tables[[k]]),file.path(out,labels[[k]]),row.names=FALSE,na="")
  unname(labels)
}
