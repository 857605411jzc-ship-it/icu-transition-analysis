# A positive blood accession with more than one reported organism group remains in the denominator.
blood_partition <- function(con) {
  DBI::dbGetQuery(con, "
    SELECT s.pid, s.hid, s.specimen,
      CASE WHEN count(DISTINCT i.organism_category)=1 THEN min(i.organism_category) END AS organism_group
    FROM culture_spec s LEFT JOIN culture_iso i USING(pid,hid,specimen)
    WHERE s.pending AND s.post_handoff_48 AND s.outcome_class='positive' AND s.site_group='blood'
    GROUP BY s.pid,s.hid,s.specimen")
}

summarize_blood_organisms <- function(parts, out) {
  d <- do.call(rbind, parts)
  stopifnot(!anyDuplicated(d[c("pid","hid","specimen")]))
  freq <- table(d$organism_group)
  groups <- data.frame(exposure=as.character(names(freq)), positive_accessions=as.integer(freq))
  groups <- head(groups[order(-groups$positive_accessions, groups$exposure), , drop=FALSE], 3L)
  n <- groups$positive_accessions
  N <- nrow(d)
  people <- vapply(groups$exposure, function(g) length(unique(d$pid[which(d$organism_group==g)])), integer(1))
  result <- data.frame(site=rep("blood", nrow(groups)), exposure=groups$exposure,
                       positive_accessions=ifelse(people>=11, report_count(n), "<11"),
                       N_positive_site=rep(report_count(N), nrow(groups)))
  ci <- matrix(NA_real_, nrow=nrow(groups), ncol=3L)
  for (i in which(people>=11)) ci[i,] <- wilson_percent(n[i], N)
  result[c("percent","lower95","upper95")] <- as.data.frame(ci)
  utils::write.csv(result[order(result$exposure),], file.path(out, "blood_positive_organism_groups.csv"),
                   row.names=FALSE, na="")
}
