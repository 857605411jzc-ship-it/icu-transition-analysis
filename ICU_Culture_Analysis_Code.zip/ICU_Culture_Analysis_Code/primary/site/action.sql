CREATE TEMP TABLE alert_index_accession AS
SELECT p.pid,p.hid,p.specimen,p.report_time AS alert,e.after_first_ward,e.destination
FROM coverage_pair_acc p JOIN routing_event_locations e USING(pid,hid,specimen)
WHERE p.strict_dynamic AND e.trigger_time=p.report_time
QUALIFY p.report_time=min(p.report_time) OVER(PARTITION BY p.pid);

CREATE TEMP TABLE alert_index AS
SELECT DISTINCT i.pid,i.hid,i.alert,i.after_first_ward,i.destination,c.tm,c.hospital_end,c.died_at,
 (SELECT min(l.began) FROM loc l WHERE l.pid=i.pid AND l.hid=i.hid AND l.unit_category='ICU'
   AND l.began>i.alert AND l.began<c.hospital_end AND l.ended>l.began) AS next_icu
FROM alert_index_accession i JOIN cohort c USING(pid,hid);

CREATE TEMP TABLE alert_targets AS
SELECT DISTINCT i.pid,i.hid,i.specimen,t.isolate_key
FROM alert_index_accession i JOIN coverage_isolate_tiers t USING(pid,hid,specimen)
WHERE t.phase='ward' AND t.mode='transition' AND t.grade='T1' AND t.report_time=i.alert;

CREATE TEMP TABLE alert_active AS
SELECT t.*,a.agent,s.rule
FROM alert_targets t JOIN coverage_drug_activity a USING(pid,hid,specimen,isolate_key)
CROSS JOIN (VALUES ('spectrum'),('direct_or_surrogate')) s(rule)
WHERE (s.rule='spectrum' AND a.is_active) OR (s.rule='direct_or_surrogate' AND a.strict_active);

CREATE TEMP TABLE alert_dose_targets AS
WITH firsts AS (
 SELECT a.pid,a.hid,a.specimen,a.isolate_key,a.rule,
   min(d.at_time) FILTER(WHERE d.at_time<=i.alert) AS pre,
   min(d.at_time) FILTER(WHERE d.at_time<=i.alert AND d.recorded<=i.alert) AS visible_pre,
   min(d.at_time) FILTER(WHERE d.at_time>i.alert) AS post
 FROM alert_active a JOIN alert_index i USING(pid,hid)
 JOIN culture_dose d ON d.pid=i.pid AND d.hid=i.hid AND d.agent=a.agent AND d.route_kind='systemic'
   AND d.at_time BETWEEN i.alert-INTERVAL '24 hours' AND least(i.alert+INTERVAL '48 hours',i.tm+INTERVAL '72 hours')
   AND d.at_time<i.hospital_end GROUP BY ALL
)
SELECT t.*,s.rule,f.pre,f.visible_pre,f.post
FROM alert_targets t CROSS JOIN (VALUES ('spectrum'),('direct_or_surrogate')) s(rule)
LEFT JOIN firsts f ON t.pid=f.pid AND t.hid=f.hid AND t.specimen=f.specimen AND t.isolate_key=f.isolate_key AND s.rule=f.rule;

CREATE TEMP TABLE alert_dose_endpoint AS
SELECT d.pid,d.hid,d.rule,'administration' AS channel,
 bool_and(d.pre IS NOT NULL) AS pre,
 bool_and(d.visible_pre IS NOT NULL) AS pre_visible,
 CASE WHEN bool_and(d.pre IS NOT NULL OR d.post IS NOT NULL) AND NOT bool_and(d.pre IS NOT NULL)
      THEN max(d.post) FILTER(WHERE d.pre IS NULL) END AS post_time
FROM alert_dose_targets d GROUP BY ALL;

CREATE TEMP TABLE alert_order_matches AS
SELECT DISTINCT a.pid,a.hid,a.specimen,a.isolate_key,a.rule,r.entered,
 greatest(r.started,coalesce(r.entered,r.started)) AS began,r.stopped
FROM alert_active a JOIN alert_index i USING(pid,hid) JOIN coverage_rx r ON r.pid=i.pid AND r.hid=i.hid AND r.agent=a.agent
WHERE r.route_kind='systemic' AND r.stopped>greatest(r.started,coalesce(r.entered,r.started))
 AND r.stopped>i.alert AND greatest(r.started,coalesce(r.entered,r.started))<=i.alert+INTERVAL '48 hours'
 AND greatest(r.started,coalesce(r.entered,r.started))<i.hospital_end;

CREATE TEMP TABLE alert_order_endpoint AS
WITH timeline AS (
 SELECT DISTINCT m.pid,m.hid,m.rule,greatest(m.began,i.alert) AS at_time
 FROM alert_order_matches m JOIN alert_index i USING(pid,hid)
), per_target AS (
 SELECT t.pid,t.hid,t.specimen,t.isolate_key,x.rule,x.at_time,
   count(m.began)>0 AS covered,count(m.entered)>0 AS entry_known
 FROM alert_targets t JOIN timeline x USING(pid,hid)
 LEFT JOIN alert_order_matches m ON m.pid=t.pid AND m.hid=t.hid AND m.specimen=t.specimen AND m.isolate_key=t.isolate_key
    AND m.rule=x.rule AND m.began<=x.at_time AND m.stopped>x.at_time
 GROUP BY ALL
), complete AS (
 SELECT pid,hid,rule,at_time,bool_and(covered) AS all_covered,bool_and(entry_known) AS entries_known FROM per_target GROUP BY ALL
)
SELECT i.pid,i.hid,s.rule,'order' AS channel,
 count(*) FILTER(WHERE c.at_time=i.alert AND c.all_covered)>0 AS pre,
 count(*) FILTER(WHERE c.at_time=i.alert AND c.all_covered AND c.entries_known)>0 AS pre_visible,
 CASE WHEN count(*) FILTER(WHERE c.at_time=i.alert AND c.all_covered)=0
      THEN min(c.at_time) FILTER(WHERE c.at_time>i.alert AND c.all_covered) END AS post_time
FROM alert_index i CROSS JOIN (VALUES ('spectrum'),('direct_or_surrogate')) s(rule)
LEFT JOIN complete c ON c.pid=i.pid AND c.hid=i.hid AND c.rule=s.rule GROUP BY ALL;

CREATE TEMP TABLE alert_evidence_span AS
SELECT i.pid,i.hid,i.alert,i.tm,i.hospital_end,i.died_at,i.destination,i.after_first_ward,i.next_icu,h.horizon,
       i.alert+h.horizon*INTERVAL '1 hour' AS deadline,
       coalesce((SELECT count(DISTINCT e.at_time)>=2 AND max(e.at_time)>=i.alert-INTERVAL '12 hours'
         FROM culture_em e WHERE e.pid=i.pid AND e.hid=i.hid AND e.at_time BETWEEN i.alert-INTERVAL '24 hours' AND i.alert
           AND e.recorded<=i.alert),false) AS baseline_emar,
       EXISTS(SELECT 1 FROM coverage_orders0 r WHERE r.pid=i.pid AND r.hid=i.hid
          AND r.started<=i.alert AND coalesce(r.entered,r.started)<=i.alert AND r.stopped>i.alert) AS baseline_orders,
       EXISTS(SELECT 1 FROM culture_em e WHERE e.pid=i.pid AND e.hid=i.hid AND e.at_time>i.alert
          AND e.at_time BETWEEN i.alert+(h.horizon-least(12,h.horizon/2))*INTERVAL '1 hour'
                            AND i.alert+h.horizon*INTERVAL '1 hour' AND e.at_time<i.hospital_end) AS later_emar,
       EXISTS(SELECT 1 FROM coverage_orders0 r WHERE r.pid=i.pid AND r.hid=i.hid
          AND greatest(r.started,coalesce(r.entered,r.started))<=i.alert+h.horizon*INTERVAL '1 hour'
          AND greatest(r.started,coalesce(r.entered,r.started))<i.hospital_end
          AND r.stopped>greatest(r.started,coalesce(r.entered,r.started))
          AND r.stopped>i.alert+(h.horizon-least(12,h.horizon/2))*INTERVAL '1 hour') AS later_orders
FROM alert_index i CROSS JOIN (VALUES (6),(24),(48)) h(horizon);

CREATE TEMP TABLE alert_records AS
WITH channels AS (SELECT * FROM alert_dose_endpoint UNION ALL SELECT * FROM alert_order_endpoint), follow AS (
 SELECT b.*,e.* EXCLUDE(pid,hid),
  CASE WHEN b.channel='administration' THEN e.baseline_emar ELSE e.baseline_orders END AS base_documented,
  CASE WHEN b.channel='administration' THEN e.later_emar ELSE e.later_orders END AS follow_documented,
  CASE WHEN b.channel='administration' THEN e.tm+INTERVAL '72 hours' ELSE 'infinity'::TIMESTAMP END AS cache_end,
  CASE WHEN b.post_time<=e.deadline THEN b.post_time END AS response
 FROM channels b JOIN alert_evidence_span e USING(pid,hid)
)
SELECT f.pid,f.hid,f.channel,f.rule,f.horizon,f.destination,f.after_first_ward,f.pre,f.pre_visible,
 f.base_documented,f.follow_documented,
 (f.hospital_end>=f.deadline AND f.cache_end>=f.deadline) AS time_complete,
 (f.next_icu IS NOT NULL AND f.next_icu<=least(f.deadline,f.hospital_end,f.cache_end)) AS later_icu_entry,
 epoch(f.response-f.alert)/3600 AS hours,
 CASE WHEN f.pre THEN 'at_or_before_index'
      WHEN f.response IS NOT NULL THEN 'first_documented_after_index'
      WHEN f.hospital_end<f.deadline AND f.hospital_end<=f.cache_end AND f.died_at=f.hospital_end THEN 'death_before_horizon'
      WHEN f.hospital_end<f.deadline AND f.hospital_end<=f.cache_end THEN 'hospital_discharge_before_horizon'
      WHEN f.cache_end<f.deadline THEN 'administration_cache_ended'
      WHEN NOT f.base_documented OR NOT f.follow_documented THEN 'insufficient_medication_documentation'
      ELSE 'no_qualifying_record_by_horizon' END AS status,
 CASE WHEN f.response IS NULL THEN 'no_post_index_endpoint'
      WHEN l.n<>1 OR NOT coalesce(l.named_bounded,false) OR l.kind IS NULL THEN 'unknown'
      WHEN l.kind='ICU' THEN 'icu'
      WHEN l.kind IN ('Medical','Surgical','Mixed or specialty') THEN 'ward'
      ELSE 'other_named_unit' END AS response_location
FROM follow f LEFT JOIN LATERAL (SELECT count(*) AS n,min(unit_category) AS kind,
  bool_and(ended IS NOT NULL AND unit IS NOT NULL) AS named_bounded FROM loc
  WHERE pid=f.pid AND hid=f.hid AND began<=f.response AND (ended>f.response OR ended IS NULL)) l ON TRUE;
