# Treatment at first strictly matched report and discordance at the accession level.
site_partition <- function(con) {
  DBI::dbExecute(con, "CREATE TEMP MACRO response_site_group(s) AS CASE
    WHEN s IN ('blood','csf','pleural','peritoneal','pericardial','synovial','deep_tissue_pus') THEN 'sterile_or_deep'
    WHEN s IN ('urine','respiratory') THEN 'urine_or_respiratory' ELSE 'other_site' END")
  response <- DBI::dbGetQuery(con, "
    WITH target_sites AS (
      SELECT a.pid, CASE WHEN count(DISTINCT response_site_group(s.site_group))=1
        THEN min(response_site_group(s.site_group)) ELSE 'multiple_site_groups' END AS site
      FROM alert_index_accession a JOIN culture_spec s USING(pid,hid,specimen) GROUP BY a.pid)
    SELECT r.pid,r.channel,r.horizon,r.pre,r.hours,
           (r.base_documented AND r.follow_documented AND r.time_complete AND NOT r.pre) AS eligible,
           s.site FROM alert_records r JOIN target_sites s USING(pid)
    WHERE r.rule='spectrum'")
  mechanism <- DBI::dbGetQuery(con, "
    WITH direct AS (
      SELECT i.pid,i.hid,i.specimen,i.report_time,
        bool_or(m.route_kind='systemic' AND ((i.fungal AND m.family='antifungal') OR
          (NOT i.fungal AND m.family IN ('broad','antibacterial'))) AND
          d.activity IN ('inactive_direct_R','inactive_direct_I')) AS explicit_ri
      FROM coverage_isolate_tiers i LEFT JOIN coverage_med_regimen m USING(win)
      LEFT JOIN coverage_drug_activity d ON d.pid=i.pid AND d.hid=i.hid AND d.specimen=i.specimen
        AND d.isolate_key=i.isolate_key AND d.agent=m.agent
      WHERE i.mode='transition' AND i.phase='ward' AND i.grade='T1' GROUP BY ALL)
    SELECT s.pid,s.specimen,response_site_group(s.site_group) AS site,
      coalesce(t.grade='T1',false) AS gap,
      CASE WHEN t.grade IS DISTINCT FROM 'T1' THEN 'no_identified_discordance'
        WHEN t.reason='no_documented_relevant_agent' THEN 'no_relevant_agent'
        WHEN t.reason='all_regimen_options_discordant' AND d.explicit_ri IS TRUE
          THEN 'all_relevant_options_inactive_with_direct_RI'
        WHEN t.reason='all_regimen_options_discordant'
          THEN 'all_relevant_options_inactive_inferred'
        ELSE 'unmapped_mechanism' END AS mechanism
    FROM culture_spec s LEFT JOIN coverage_tiers t ON t.pid=s.pid AND t.hid=s.hid AND t.specimen=s.specimen
      AND t.report_time=s.final_time AND t.mode='transition' AND t.phase='ward'
    LEFT JOIN direct d ON d.pid=s.pid AND d.hid=s.hid AND d.specimen=s.specimen AND d.report_time=s.final_time
    WHERE s.pending AND s.post_handoff_48 AND s.outcome_class='positive'")
  stopifnot(!anyDuplicated(response[c('pid','channel','horizon')]),nrow(response) %% 6L==0L,
    !anyDuplicated(mechanism[c('pid','specimen')]),!anyNA(mechanism),!any(mechanism$mechanism=='unmapped_mechanism'))
  list(response=response,mechanism=mechanism)
}

site_proportion <- function(n,N,support=n,den_support=N) {
  stopifnot(length(n)==1, is.finite(n), is.finite(N), n>=0,N>=n,den_support>=support)
  hide_count <- function(x,people) if(people<11L) '<11' else as.character(x)
  rate <- low <- high <- NA_real_
  if(support>=11L && den_support>=11L) {
    z<-qnorm(.975); p<-n/N; a<-1+z*z/N
    half<-z/a*sqrt(p*(1-p)/N+z*z/(4*N*N)); center<-(p+z*z/(2*N))/a
    rate<-100*p;low<-100*max(0,center-half);high<-100*min(1,center+half)
  }
  data.frame(n=hide_count(n,support),N=hide_count(N,den_support),
             percent=round(rate,3),lower95=round(low,3),upper95=round(high,3))
}

summarize_sites <- function(parts,out) {
  r<-do.call(rbind,lapply(parts,'[[','response'))
  m<-do.call(rbind,lapply(parts,'[[','mechanism'))
  first<-r[r$horizon==24L,,drop=FALSE]
  locs<-c('sterile_or_deep','urine_or_respiratory','other_site','multiple_site_groups')
  groups<-c('all',locs)
  stopifnot(!anyDuplicated(r[c('pid','channel','horizon')]),!anyDuplicated(m[c('pid','specimen')]),
    all(r$site %in% locs),all(m$site %in% locs[1:3]),!anyNA(r[c('pid','channel','horizon','pre','eligible','site')]),
    all(!r$eligible | !r$pre),all(is.na(r$hours)|(!r$pre & r$hours>0 & r$hours<=r$horizon)))
  select_site<-function(df,g) if(g=='all') df else df[df$site==g,,drop=FALSE]
  rate_rows<-list();comparison<-list()
  for(ch in c('administration','order')){
    x<-first[first$channel==ch & first$eligible,,drop=FALSE]
    for(g in groups){
      k<-select_site(x,g)
      rate_rows[[length(rate_rows)+1L]]<-cbind(channel=ch,hours=24L,site=g,
                     site_proportion(sum(!is.na(k$hours)),nrow(k)))
    }
    tab<-matrix(0L,2,2)
    for(i in 1:2) {
      k<-select_site(x,locs[i]); tab[i,]<-c(sum(!is.na(k$hours)),sum(is.na(k$hours)))
    }
    estimate<-low<-high<-pval<-NA_real_
    status<-'small_cell'
    if(all(tab>=11)){
      f<-fisher.test(tab)
      estimate<-unname(f$estimate);low<-f$conf.int[1];high<-f$conf.int[2];pval<-f$p.value
      status<-'estimated'
    }
    comparison[[length(comparison)+1L]]<-data.frame(channel=ch,exposure='sterile_or_deep',
        comparator='urine_or_respiratory',metric='conditional_odds_ratio',odds_ratio=estimate,
        lower95=low,upper95=high,two_sided_fisher_p=pval,status=status)
  }
  cnt<-list()
  evidence<-c('no_relevant_agent','all_relevant_options_inactive_with_direct_RI','all_relevant_options_inactive_inferred')
  for(g in c('all',locs[1:3])){
    k<-select_site(m,g)
    for(cat in c('any_potential_discordance',evidence)){
      y<-if(cat=='any_potential_discordance') k$gap else k$mechanism==cat
      cnt[[length(cnt)+1L]]<-cbind(site=g,mechanism=cat,denominator_unit='positive_accessions',
           site_proportion(sum(y),nrow(k),length(unique(k$pid[y])),length(unique(k$pid))))
    }
  }
  output<-list('alert_response_by_site.csv'=rate_rows,
               'alert_response_site_contrast.csv'=comparison,'discordance_mechanism_by_site.csv'=cnt)
  for(name in names(output)) utils::write.csv(do.call(rbind,output[[name]]),file.path(out,name),row.names=FALSE,na='')
  names(output)
}
