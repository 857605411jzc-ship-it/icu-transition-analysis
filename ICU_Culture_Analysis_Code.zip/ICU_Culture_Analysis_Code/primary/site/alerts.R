# First potentially deliverable susceptibility result linked to a transition mismatch.
alert_partition <- function(con, here, shard, n_shards, note=message) {
  execute_sql(con,file.path(here,"action.sql"))
  fetch <- function(s) DBI::dbGetQuery(con,s)
  index <- fetch("SELECT DISTINCT pid,hid,destination,after_first_ward FROM alert_index")
  r <- fetch("SELECT * FROM alert_records")
  # Repeatable membership across patients and specimens in the full routing funnel.
  f <- fetch("SELECT e.pid,e.hid,e.specimen,e.after_first_ward,p.strict_dynamic IS TRUE AS strict,
                i.specimen IS NOT NULL AS at_person_index FROM routing_event_locations e
              LEFT JOIN coverage_pair_acc p USING(pid,hid,specimen)
              LEFT JOIN alert_index_accession i USING(pid,hid,specimen)")
  nt <- fetch("SELECT count(*) AS n FROM alert_index_accession i WHERE NOT EXISTS
      (SELECT 1 FROM alert_targets t WHERE t.pid=i.pid AND t.hid=i.hid AND t.specimen=i.specimen)")$n
  stopifnot(nt==0L, !anyDuplicated(index$pid), !anyDuplicated(f[c("pid","hid","specimen")]),
    !anyNA(f), all(!f$at_person_index|f$strict), setequal(f$pid[f$strict],index$pid),
    nrow(r)==12*nrow(index),!anyDuplicated(r[c("pid","rule","channel","horizon")]),
    !anyNA(r[setdiff(names(r),"hours")]), all(r$hours[!is.na(r$hours)] > 0),
    all(is.na(r$hours) | r$hours<=r$horizon), all(!r$pre_visible|r$pre))
  list(shard=as.integer(shard),n_shards=as.integer(n_shards),funnel=f,records=r,index=index)
}

summarize_alerts <- function(parts,public) {
  n <- length(parts)
  stopifnot(n>0,identical(unname(sort(vapply(parts,function(z) z$shard,integer(1)))),0:(n-1L)),
            all(vapply(parts,function(z) z$n_shards==n,logical(1))))
  stack <- function(k) do.call(rbind,lapply(parts,function(z)z[[k]]))
  r <- stack("records"); f <- stack("funnel"); index <- stack("index")
  stopifnot(!anyDuplicated(index$pid),!anyDuplicated(f[c("pid","hid","specimen")]),
            nrow(r)==12*nrow(index),all(table(r$pid)==12L))
  n_people <- function(x) length(unique(x))
  # Point estimates and Wilson intervals are generated only after pooling all patients locally.
  release <- function(x) ifelse(x<11,"<11",as.character(as.integer(x)))
  interval <- function(k,N) {
    if(k<11 || N<11) return(rep(NA_real_,3))
    z <- qnorm(0.975); p <- k/N; v <- z*z/N
    margin <- z*sqrt((p*(1-p)+v/4)/N)
    round(100*c(p,max(0,(p+v/2-margin)/(1+v)),min(1,(p+v/2+margin)/(1+v))),3)
  }
  countrow <- function(metric,k,N) {
    v <- interval(k,N)
    data.frame(metric=metric,n=release(k),denominator=release(N),percent=v[1],lower95=v[2],upper95=v[3])
  }
  groups <- c("all","initial_receiving_ward_interval","after_initial_ward_interval")
  filtergroup <- function(x,g) {
    if(g=="all") return(x)
    x[x$after_first_ward==(g=="after_initial_ward_interval"),,drop=FALSE]
  }
  funnel <- list(); outcomes <- list(); delays <- list()
  states <- c("at_or_before_index","first_documented_after_index","death_before_horizon",
    "hospital_discharge_before_horizon","administration_cache_ended","insufficient_medication_documentation",
    "no_qualifying_record_by_horizon")
  for (g in groups) {
    d <- filtergroup(f,g)
    values <- list(
      countrow("all_dynamic_accessions",nrow(d),nrow(f)),
      countrow("strict_mismatch_accessions_among_dynamic",sum(d$strict),nrow(d)),
      countrow("patient_index_accessions_among_strict",sum(d$at_person_index),sum(d$strict)),
      countrow("people_with_any_strict_mismatch_alert",n_people(d$pid[d$strict]),n_people(d$pid)),
      countrow("people_at_first_strict_alert",n_people(d$pid[d$at_person_index]),nrow(index)))
    funnel[[length(funnel)+1L]] <- cbind(location_group=g,do.call(rbind,values))
    for (rule in c("spectrum","direct_or_surrogate")) for (ch in c("administration","order")) for (h in c(6,24,48)) {
      x <- filtergroup(r[r$rule==rule & r$channel==ch & r$horizon==h,,drop=FALSE],g)
      N <- nrow(x); post <- !is.na(x$hours)
      eligible <- x$base_documented & x$follow_documented & x$time_complete & !x$pre
      stopifnot(all(x$status %in% states),sum(x$pre)+sum(post)<=N)
      lab <- data.frame(location_group=g,rule=rule,channel=ch,hours_of_followup=h)
      rows <- lapply(states,function(k) countrow(k,sum(x$status==k),N))
      extra <- list(countrow("pre_index_with_timestamp_available_at_index",sum(x$pre_visible),sum(x$pre)),
        countrow("baseline_medication_documentation",sum(x$base_documented),N),
        countrow("full_inpatient_and_source_time",sum(x$time_complete),N),
        countrow("full_followup_and_baseline_documented_without_prior_match",sum(eligible),N),
        countrow("first_post_index_match_in_fully_observed_without_prior_match",sum(post & eligible),sum(eligible)),
        countrow("new_icu_entry_during_observed_window",sum(x$later_icu_entry),N))
      for (unit in c("ward","icu","other_named_unit","unknown"))
        extra[[length(extra)+1L]] <- countrow(paste0("post_index_endpoint_in_",unit),sum(x$response_location==unit),sum(post))
      outcomes[[length(outcomes)+1L]] <- cbind(lab,do.call(rbind,c(rows,extra)))
      for (population in c("observed_post_index_responders","fully_observed_post_index_responders")) {
        time <- x$hours[post & (population=="observed_post_index_responders" | eligible)]
        qs <- if(length(time)>=11L) as.numeric(quantile(time,c(.25,.5,.75),names=FALSE)) else rep(NA_real_,3L)
        delays[[length(delays)+1L]] <- cbind(lab,population=population,people=release(length(time)),
                                              q1_hours=round(qs[1],2),median_hours=round(qs[2],2),q3_hours=round(qs[3],2))
      }
    }
  }
  tables <- list("alert_routing.csv"=funnel,"post_alert_action.csv"=outcomes,"response_time.csv"=delays)
  for (file in names(tables)) utils::write.csv(do.call(rbind,tables[[file]]),file.path(public,file),row.names=FALSE,na="")
  names(tables)
}
