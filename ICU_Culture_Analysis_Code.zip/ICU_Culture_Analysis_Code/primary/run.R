main <- function() {
  args <- commandArgs(trailingOnly=TRUE)
  if (length(args)!=3L) stop("Usage: Rscript primary/run.R PARTITIONS ADMISSIONS OUTPUT",call.=FALSE)
  if (!requireNamespace("DBI",quietly=TRUE) || !requireNamespace("duckdb",quietly=TRUE))
    stop("Install the R packages DBI and duckdb.",call.=FALSE)
  file_arg <- grep("^--file=",commandArgs(),value=TRUE)
  here <- dirname(normalizePath(sub("^--file=","",file_arg),mustWork=TRUE))
  root <- normalizePath(args[1],winslash="/",mustWork=TRUE)
  admissions <- normalizePath(args[2],winslash="/",mustWork=TRUE)
  out <- args[3]
  if (file.exists(out)) stop("Choose a new output directory.",call.=FALSE)
  if (!dir.exists(dirname(out))) dir.create(dirname(out),recursive=TRUE)
  stage <- tempfile("clinical_analysis_",tmpdir=dirname(out))
  if (!dir.create(stage)) stop("Cannot create working directory.")
  on.exit(unlink(stage,recursive=TRUE),add=TRUE)
  exports <- file.path(stage,"aggregates")
  dir.create(exports)
  for (folder in c("engine","clinical","policies","order","site")) {
    for (script in list.files(file.path(here,folder),pattern="[.]R$",full.names=TRUE))
      sys.source(script,envir=environment())
  }
  # Keep a single patient and every linked specimen within one partition.
  query_partition <- function(fn) {
    spill <- tempfile("spill_",tmpdir=stage)
    dir.create(spill)
    driver <- duckdb::duckdb(dbdir=":memory:",bigint="numeric",shared_home=FALSE,
      config=list(threads="1",memory_limit="1500MB",preserve_insertion_order="false",
                  temp_directory=normalizePath(spill,winslash="/")))
    db <- DBI::dbConnect(driver)
    on.exit({DBI::dbDisconnect(db,shutdown=TRUE);unlink(spill,recursive=TRUE)},add=TRUE)
    fn(db)
  }
  lookup <- query_partition(function(db) {
    query <- partition_query(db,partition_table_path(root,"cohort"))
    admissions_lookup(db,query,admissions)
  })
  pieces <- vector("list",32L)
  order_dir <- file.path(here,"order")
  one <- function(db,i) {
    bind_partition(db,root,i,32L)
    policy <- policy_partition(db,file.path(here,"engine"),i,32L,note=function(...) NULL)
    persons <- DBI::dbGetQuery(db,"SELECT pid FROM cohort")
    flags <- lookup[match(persons$pid,lookup$pid),,drop=FALSE]
    stopifnot(!anyNA(flags))
    DBI::dbWriteTable(db,"therapy_admissions",flags,temporary=TRUE)
    baseline <- baseline_partition(db)
    blood <- blood_partition(db)
    death <- mortality_partition(db)
    alert <- alert_partition(db,file.path(here,"site"),i,32L)
    site <- site_partition(db)
    # The cohort partitions do not contain sex. The constant category is dropped from the model.
    DBI::dbExecute(db,"CREATE TEMP VIEW clinical_demographics AS SELECT pid,'unknown' AS sex FROM cohort")
    execute_sql(db,file.path(order_dir,"preparation.sql"))
    dose <- dose_partition(db,order_dir)
    # Both prescribing comparisons reuse the same eligible reports and 48-hour endpoint.
    DBI::dbBegin(db)
    execute_sql(db,file.path(order_dir,"sensitivity.sql"))
    execute_sql(db,file.path(order_dir,"followup.sql"))
    prescribing <- DBI::dbGetQuery(db,"SELECT * FROM therapy_rx_person WHERE stop_obs")
    DBI::dbRollback(db)
    orders <- order_partition(db,order_dir)
    list(policy=policy,baseline=baseline,blood=blood,death=death,alert=alert,site=site,
         prescribing=prescribing,orders=orders,dose=dose)
  }
  for (i in seq_along(pieces)) {
    pieces[[i]] <- query_partition(function(db) one(db,i-1L))
    message("Computed partition ",i," of ",length(pieces))
  }
  take <- function(key) lapply(pieces,"[[",key)
  summarize_policies(take("policy"),exports)
  summarize_baseline(take("baseline"),exports)
  summarize_blood_organisms(take("blood"),exports)
  summarize_mortality(take("death"),exports)
  summarize_alerts(take("alert"),exports)
  summarize_sites(take("site"),exports)
  summarize_prescribing(take("prescribing"),exports)
  summarize_orders(take("orders"),exports,nrow(lookup))
  summarize_doses(take("dose"),exports)
  summarize_missing_doses(take("dose"),exports)
  if (!file.rename(exports,out)) stop("Could not commit aggregate tables.")
}
main()
