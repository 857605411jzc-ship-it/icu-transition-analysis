-- Only chart and laboratory entries that could already be seen at transfer.
CREATE TEMP TABLE temperatures AS
WITH measures AS (
 SELECT c.pid,c.tm,c.icu_in,try_cast(e.charttime AS TIMESTAMP) AS at_time,
   try_cast(e.storetime AS TIMESTAMP) AS stored,
   CASE WHEN e.itemid='223761' THEN (try_cast(e.valuenum AS DOUBLE)-32)*5/9
        ELSE try_cast(e.valuenum AS DOUBLE) END AS temp
 FROM src_chartevents e JOIN cohort c ON c.sid=try_cast(e.stay_id AS BIGINT)
   AND c.pid=try_cast(e.subject_id AS BIGINT) AND c.hid=try_cast(e.hadm_id AS BIGINT)
 WHERE e.itemid IN ('223761','223762')
)
SELECT pid,max(temp)>=38 AS fever FROM measures
 WHERE temp BETWEEN 25 AND 45 AND at_time BETWEEN greatest(icu_in,tm-INTERVAL '24 hour') AND tm
 AND stored BETWEEN at_time AND tm GROUP BY pid;

-- Keep only these four clinical lab tests from the source, once per eligible draw.
CREATE TEMP TABLE risk_labs AS
WITH m AS (
 SELECT c.pid,c.tm,c.icu_in,e.itemid,try_cast(e.charttime AS TIMESTAMP) AS at_time,
   try_cast(e.storetime AS TIMESTAMP) AS stored,try_cast(e.valuenum AS DOUBLE) AS val,
   upper(replace(trim(e.valueuom),' ','')) AS u
 FROM src_labevents e JOIN cohort c ON c.pid=try_cast(e.subject_id AS BIGINT)
 AND c.hid=try_cast(e.hadm_id AS BIGINT)
 WHERE e.itemid IN ('51300','51301','51265','50885','50912')
)
SELECT pid,itemid,at_time,stored,val FROM m WHERE at_time BETWEEN greatest(icu_in,tm-INTERVAL '24 hour') AND tm
 AND stored BETWEEN at_time AND tm AND (
    (itemid IN ('51300','51301','51265') AND u IN ('K/UL','10^3/UL','10^9/L','THOU/UL'))
     OR (itemid IN ('50885','50912') AND u='MG/DL'));

CREATE TEMP TABLE wbc AS
WITH last_clock AS (
 SELECT pid,val AS wbc FROM risk_labs WHERE itemid IN ('51300','51301') AND val BETWEEN 0 AND 1000
 QUALIFY dense_rank() OVER(PARTITION BY pid ORDER BY at_time DESC, stored DESC)=1
)
SELECT pid,CASE WHEN count(DISTINCT (wbc<4 OR wbc>12))=1 THEN bool_or(wbc<4 OR wbc>12) END AS wbc_abnormal
FROM last_clock GROUP BY pid;

-- Observed points from three SOFA domains. Low sums cannot rule out SOFA >= 2.
CREATE TEMP TABLE organ_lower_bound AS
WITH points AS (
 SELECT pid,itemid,CASE itemid
   WHEN '51265' THEN CASE WHEN val<20 THEN 4 WHEN val<50 THEN 3 WHEN val<100 THEN 2 WHEN val<150 THEN 1 ELSE 0 END
   WHEN '50885' THEN CASE WHEN val>=12 THEN 4 WHEN val>=6 THEN 3 WHEN val>=2 THEN 2 WHEN val>=1.2 THEN 1 ELSE 0 END
   WHEN '50912' THEN CASE WHEN val>=5 THEN 4 WHEN val>=3.5 THEN 3 WHEN val>=2 THEN 2 WHEN val>=1.2 THEN 1 ELSE 0 END
 END AS points
 FROM risk_labs WHERE (itemid='51265' AND val BETWEEN 0 AND 5000) OR (itemid='50885' AND val BETWEEN 0 AND 150)
    OR (itemid='50912' AND val>0 AND val<=100)
), worst AS (SELECT pid,itemid,max(points) AS points FROM points GROUP BY pid,itemid)
SELECT pid,count(*) AS observed_lab_domains,sum(points) AS observed_lab_points,
       CASE WHEN sum(points)>=2 THEN TRUE END AS sofa_lab_minimum_ge2
FROM worst GROUP BY pid;

-- Presence of other contemporaneous chart entries makes a recorded absence interpretable:
-- check the same index stay and only entries already posted by handoff.
CREATE TEMP TABLE input_observed AS
SELECT DISTINCT c.pid FROM src_inputevents e JOIN cohort c ON c.pid=try_cast(e.subject_id AS BIGINT)
  AND c.hid=try_cast(e.hadm_id AS BIGINT) AND c.sid=try_cast(e.stay_id AS BIGINT)
WHERE try_cast(e.starttime AS TIMESTAMP)<=c.tm AND try_cast(e.endtime AS TIMESTAMP)>=greatest(c.icu_in,c.tm-INTERVAL '24 hours')
 AND try_cast(e.starttime AS TIMESTAMP)<=try_cast(e.endtime AS TIMESTAMP)
 AND try_cast(e.storetime AS TIMESTAMP) BETWEEN c.icu_in AND c.tm
 AND lower(trim(e.statusdescription)) NOT IN ('rewritten','cancelled','canceled');

CREATE TEMP TABLE procedure_observed AS
SELECT DISTINCT c.pid FROM src_procedureevents e JOIN cohort c ON c.pid=try_cast(e.subject_id AS BIGINT)
  AND c.hid=try_cast(e.hadm_id AS BIGINT) AND c.sid=try_cast(e.stay_id AS BIGINT)
WHERE try_cast(e.starttime AS TIMESTAMP)<=c.tm AND try_cast(e.endtime AS TIMESTAMP)>=greatest(c.icu_in,c.tm-INTERVAL '24 hours')
 AND try_cast(e.starttime AS TIMESTAMP)<=try_cast(e.endtime AS TIMESTAMP)
 AND try_cast(e.storetime AS TIMESTAMP) BETWEEN c.icu_in AND c.tm
 AND lower(trim(e.statusdescription)) NOT IN ('rewritten','cancelled','canceled');

-- A positive-rate index-stay infusion with a documented stop. An adjacent or overlapping
-- running infusion on the same patient precludes calling it a withdrawal of pressor support.
CREATE TEMP TABLE pressors AS
WITH m AS (
 SELECT c.pid,c.tm,c.icu_in,try_cast(e.starttime AS TIMESTAMP) AS began,
 try_cast(e.endtime AS TIMESTAMP) AS ended,try_cast(e.storetime AS TIMESTAMP) AS stored,
 lower(trim(e.statusdescription)) AS status
 FROM src_inputevents e JOIN cohort c ON c.pid=try_cast(e.subject_id AS BIGINT)
 AND c.hid=try_cast(e.hadm_id AS BIGINT) AND c.sid=try_cast(e.stay_id AS BIGINT)
 WHERE e.itemid IN ('221906','221289','221749','222315','221662') AND try_cast(e.rate AS DOUBLE)>0
 AND lower(trim(e.statusdescription)) NOT IN ('rewritten','cancelled','canceled')
), per_patient AS (
 SELECT pid,bool_or(ended>tm) AS pressor_on,
 bool_or(ended<=tm AND stored>=ended AND status IN ('finishedrunning','stopped','flushed','finished running')) AS terminal
 FROM m WHERE began BETWEEN icu_in AND tm AND ended>began AND ended>=tm-INTERVAL '24 hour'
 AND stored IS NOT NULL AND stored<=tm GROUP BY pid
)
SELECT pid,pressor_on,terminal AND NOT pressor_on AS pressor_off FROM per_patient;

-- Extubation, invasive-ventilation end and subsequent reintubation are distinct events.
CREATE TEMP TABLE vent AS
WITH m AS (
 SELECT c.pid,c.tm,c.icu_in,try_cast(e.starttime AS TIMESTAMP) AS began,
 try_cast(e.endtime AS TIMESTAMP) AS ended,try_cast(e.storetime AS TIMESTAMP) AS stored,
 lower(trim(d.label)) AS label,lower(trim(e.statusdescription)) AS status
 FROM src_procedureevents e JOIN src_d_items d ON e.itemid=d.itemid
 JOIN cohort c ON c.pid=try_cast(e.subject_id AS BIGINT) AND c.hid=try_cast(e.hadm_id AS BIGINT)
 AND c.sid=try_cast(e.stay_id AS BIGINT)
 WHERE (lower(trim(d.label)) IN ('extubation','intubation','invasive ventilation')
    OR starts_with(lower(trim(d.label)),'unplanned extubation'))
 AND lower(trim(e.statusdescription)) NOT IN ('rewritten','cancelled','canceled')
), per_patient AS (
 SELECT pid,tm,max(CASE WHEN label='extubation' OR starts_with(label,'unplanned extubation') THEN began
   WHEN label='invasive ventilation' AND ended<=tm AND stored>=ended AND status IN ('finishedrunning','stopped','finished running') THEN ended END) AS ended_support,
 max(began) FILTER(WHERE label IN ('intubation','invasive ventilation')) AS last_start,
 bool_or(label='invasive ventilation' AND ended>tm) AS vent_on
 FROM m WHERE began BETWEEN icu_in AND tm AND stored IS NOT NULL AND stored<=tm
 GROUP BY pid,tm
)
SELECT pid,vent_on,coalesce(ended_support BETWEEN tm-INTERVAL '24 hour' AND tm
 AND (last_start IS NULL OR last_start<ended_support) AND NOT vent_on,false) AS vent_off
FROM per_patient;
