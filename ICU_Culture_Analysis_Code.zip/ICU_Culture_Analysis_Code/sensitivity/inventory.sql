-- Pharmacy orders eligible to have appeared in the chart by transfer, including the full
-- cohort. A downstream prescription without an entry time cannot activate this rule.
CREATE TEMP TABLE t0_orders AS
WITH timed AS (
 SELECT c.pid,c.hid,try_cast(p.pharmacy_id AS BIGINT) AS pharmacy_id,
        culture_name(p.medication) AS name,culture_name(p.route) AS route,
        try_cast(p.entertime AS TIMESTAMP) AS entered,
        try_cast(p.starttime AS TIMESTAMP) AS started,try_cast(p.stoptime AS TIMESTAMP) AS stopped,c.tm
 FROM src_pharmacy p JOIN cohort c ON c.pid=try_cast(p.subject_id AS BIGINT) AND c.hid=try_cast(p.hadm_id AS BIGINT)
 WHERE try_cast(p.entertime AS TIMESTAMP)<=c.tm AND try_cast(p.starttime AS TIMESTAMP)<=c.tm
   AND (try_cast(p.stoptime AS TIMESTAMP)>c.tm OR p.stoptime IS NULL)
), keys AS (
 SELECT DISTINCT pid,hid,pharmacy_id,name,route FROM timed
), ingredients AS (
 SELECT k.pid,k.hid,k.pharmacy_id,r.name,coalesce(nullif(r.route,''),k.route) AS route
 FROM keys k JOIN culture_r0 r USING(pid,hid,pharmacy_id) JOIN cohort c USING(pid,hid)
 WHERE r.started<=c.tm AND (r.stopped>c.tm OR r.stopped IS NULL)
)
SELECT * FROM keys UNION SELECT * FROM ingredients;

CREATE TEMP TABLE t0_order_dict AS
SELECT n.name,p.agent,p.family FROM (SELECT DISTINCT name FROM t0_orders) n
LEFT JOIN culture_drug_patterns p ON regexp_matches(n.name,p.pattern)
QUALIFY row_number() OVER(PARTITION BY n.name ORDER BY p.priority NULLS LAST)=1;

CREATE TEMP TABLE handoff_meds AS
WITH orders AS (
 SELECT k.pid,k.hid,count(DISTINCT k.pharmacy_id) AS active_orders,
  bool_or(d.family IN ('broad','antibacterial') AND culture_route_kind(k.route,d.agent,k.name)='systemic') AS active_abx,
  bool_or(d.family IN ('broad','antibacterial') AND culture_route_kind(k.route,d.agent,k.name)='uncertain') AS uncertain_abx,
  bool_or(d.family='broad' AND culture_route_kind(k.route,d.agent,k.name)='systemic') AS active_broad
 FROM t0_orders k JOIN t0_order_dict d USING(name) GROUP BY k.pid,k.hid
), doses AS (
 SELECT win,bool_or(family IN ('antibacterial','broad') AND route_kind='systemic') AS systemic_abx,
   bool_or(family='broad' AND route_kind='systemic') AS broad_abx,
   bool_or(family IN ('antibacterial','broad') AND route_kind='uncertain') AS uncertain_abx
 FROM culture_wdose GROUP BY win
), ambiguous AS (
 SELECT DISTINCT win FROM culture_wamb WHERE family IN ('antibacterial','broad')
)
SELECT w.pid,w.hid,CASE WHEN d.systemic_abx IS TRUE THEN 'documented_dose'
   WHEN o.active_abx IS TRUE THEN 'active_order'
   WHEN d.uncertain_abx IS TRUE OR o.uncertain_abx IS TRUE OR a.win IS NOT NULL THEN 'unknown'
   WHEN s.near AND s.multiple THEN 'no_timed_antibacterial_emar'
   WHEN o.active_orders>=2 THEN 'no_timed_antibacterial_order_inventory'
   ELSE 'unknown' END AS antibacterial_status,
   (d.broad_abx IS TRUE OR o.active_broad IS TRUE) AS broad_at_t0
FROM culture_windows w JOIN culture_seen s USING(win) LEFT JOIN doses d USING(win) LEFT JOIN ambiguous a USING(win)
LEFT JOIN orders o USING(pid,hid) WHERE w.mode='red';
