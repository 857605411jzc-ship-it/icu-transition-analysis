"""Evaluate transfer-time bedside risk and candidate review rules in the restricted culture cohort."""

import argparse
import csv
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

import duckdb

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from cohort.prepare import SUFFIXES, bind_file, quoted
from followup.indices import ENGINE, bind_partition, execute_file

CLINICAL = {
    "chartevents": ("icu", "subject_id hadm_id stay_id itemid charttime storetime valuenum"),
    "labevents": ("hosp", "subject_id hadm_id itemid charttime storetime valuenum valueuom"),
    "inputevents": (
        "icu",
        "subject_id hadm_id stay_id itemid starttime endtime storetime statusdescription rate",
    ),
    "procedureevents": (
        "icu",
        "subject_id hadm_id stay_id itemid starttime endtime storetime statusdescription",
    ),
    "d_items": ("icu", "itemid label"),
}
CANDIDATES = {
    "gram": "gram",
    "gram_or_off": "gram OR off_abx",
    "gram_or_unstable_sterile": "gram OR (high AND sterile)",
    "gram_or_off_or_unstable_sterile": "gram OR off_abx OR (high AND sterile)",
    "gram_or_off_or_major_sterile": "gram OR off_abx OR (major AND sterile)",
    "gram_or_off_or_unstable_sterile_without_broad": "gram OR off_abx OR (high AND sterile AND NOT broad)",
    "gram_or_off_or_selective_blood": "gram OR off_abx OR (sterile AND ((high AND site!='blood') OR (major AND site='blood')))",
    "no_static_reviews": "false",
}
PERIODS = ["early", "late", "boundary_or_unknown", "all"]
SITE = """CASE WHEN site IN ('blood','csf','pleural','peritoneal','pericardial','synovial','deep_tissue_pus')
            THEN 'sterile_or_deep' WHEN site IN ('urine','respiratory') THEN 'urine_or_respiratory' ELSE 'other_site' END"""


def read_all(con, partitions, table):
    folder = partitions / "inputs" / "index" / table
    files = sorted((folder / "blocks").glob("part=*/*.parquet")) or [folder / "schema.parquet"]
    names = ", ".join(quoted(f) for f in files)
    con.execute(
        f"CREATE TEMP TABLE {table} AS SELECT * FROM read_parquet([{names}], hive_partitioning=false)"
    )


def select_clinical(con, root, table, section, columns):
    files = [root / section / (table + ext) for ext in SUFFIXES]
    files = [path for path in files if path.is_file()]
    if len(files) != 1:
        raise ValueError(f"Expected one {section}/{table} file under {root}, found {len(files)}")
    if table == "d_items":
        bind_file(con, files[0], table, columns.split())
        return
    bind_file(con, files[0], "raw_" + table, columns.split())
    keys = ["c.pid=try_cast(e.subject_id AS BIGINT)", "c.hid=try_cast(e.hadm_id AS BIGINT)"]
    if section == "icu":
        keys.append("c.sid=try_cast(e.stay_id AS BIGINT)")
    if table == "chartevents":
        keys.append("e.itemid IN ('220052','220181','225312','223761','223762')")
    elif table == "labevents":
        keys.append("e.itemid IN ('51300','51301','51265','50885','50912')")
    date = "charttime" if table in ("chartevents", "labevents") else "starttime"
    keys.extend(
        [f"try_cast(e.{date} AS TIMESTAMP)<=c.tm", "try_cast(e.storetime AS TIMESTAMP)<=c.tm"]
    )
    if date == "charttime":
        keys.append("try_cast(e.charttime AS TIMESTAMP)>=c.tm-INTERVAL '24 hours'")
    # Keep the whole preceding index stay for evidence of a later intubation or active infusion.
    con.execute(
        f"CREATE TEMP TABLE src_{table} AS SELECT e.* FROM src_raw_{table} e "
        f"JOIN cohort c ON {' AND '.join(keys)}"
    )


def risk_features(con, root, partitions, sofa, stage):
    for table in ("cohort", "icu_intervals"):
        read_all(con, partitions, table)
    for table, (section, columns) in CLINICAL.items():
        select_clinical(con, root, table, section, columns)
    if sofa:
        bind_file(con, sofa.resolve(), "sofa", ["stay_id", "endtime", "sofa_24hours"])
        con.execute(
            """CREATE TEMP TABLE hourly_sofa AS
            WITH scores AS (
                SELECT c.pid,try_cast(s.endtime AS TIMESTAMP) AS et,try_cast(s.sofa_24hours AS DOUBLE) AS score
                FROM src_sofa s JOIN cohort c ON c.sid=try_cast(s.stay_id AS BIGINT)
                WHERE try_cast(s.endtime AS TIMESTAMP) BETWEEN
                       greatest(c.icu_in+INTERVAL '24 hours',c.tm-INTERVAL '24 hours') AND c.tm
            ), latest AS (
                SELECT * FROM scores WHERE score BETWEEN 0 AND 24 AND score=floor(score)
                QUALIFY dense_rank() OVER(PARTITION BY pid ORDER BY et DESC)=1
            ) SELECT pid,min(score) AS sofa FROM latest GROUP BY pid HAVING count(DISTINCT score)=1"""
        )
    else:
        con.execute("CREATE TEMP TABLE hourly_sofa(pid BIGINT,sofa DOUBLE)")
    execute_file(con, HERE / "risk.sql")
    execute_file(con, HERE / "markers.sql")
    con.execute(f"COPY risk TO {quoted(stage / 'risk.parquet')} (FORMAT parquet)")
    return {p: n for p, n in con.execute("""SELECT CASE WHEN era_upper<=2019 THEN 'early'
                 WHEN era_lower>=2020 THEN 'late' ELSE 'boundary_or_unknown' END AS era,
                 count(*) FROM cohort GROUP BY 1""").fetchall()}


def restricted_specimens(con, partitions, part, stage):
    bind_partition(con, partitions, part)
    execute_file(con, ENGINE / "label_keys.sql")
    # Restore the standard test scope before classifying either primary or competing isolates.
    con.execute("""UPDATE culture_culture_scope sc SET scope='other_test' FROM reflex_keys k
                   WHERE sc.pid=k.pid AND sc.hid=k.hid AND sc.specimen=k.specimen
                   AND sc.test_label='REFLEX URINE CULTURE' AND sc.site_name='URINE'""")
    for name in (
        "culture",
        "medications",
        "windows",
        "result_drugs",
        "live_trigger",
        "meds",
        "spectrum",
        "paired_targets",
        "metrics",
    ):
        execute_file(con, ENGINE / (name + ".sql"))
    execute_file(con, HERE / "inventory.sql")
    con.execute(f"""COPY (
         SELECT e.pid,e.specimen,e.era,e.pending,e.positive,e.mismatch,e.gram,s.site_group AS site,
                s.sterile IS TRUE AND e.pending AS sterile,
                (m.antibacterial_status IN ('no_timed_antibacterial_emar','no_timed_antibacterial_order_inventory')) IS TRUE
                    AND e.pending AS off_abx,
                m.broad_at_t0 IS TRUE AS broad,r.high_risk IS TRUE AS high,
                r.recent_support_stop IS TRUE OR r.low_map IS TRUE AS major,
                CASE WHEN r.high_risk THEN 'high' WHEN NOT r.high_risk THEN 'no_observed_marker'
                     ELSE 'unknown' END AS severity
         FROM reflex_events e JOIN culture_spec s USING(pid,hid,specimen)
         LEFT JOIN handoff_meds m USING(pid,hid)
         LEFT JOIN read_parquet({quoted(stage/'risk.parquet')}) r USING(pid,hid)
         WHERE e.pending OR e.positive OR e.mismatch
    ) TO {quoted(stage / f'events_{part}.parquet')} (FORMAT parquet)""")


def count(value):
    return value if value >= 11 else "<11"


def write(path, fields, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(fields)
        writer.writerows(rows)


def output_aggregates(con, stage, periods, out):
    con.execute(
        f"CREATE TEMP VIEW entries AS SELECT * FROM read_parquet({quoted(stage/'events_*.parquet')})"
    )
    con.execute(
        f"CREATE TEMP VIEW markers AS SELECT * FROM read_parquet({quoted(stage/'risk.parquet')})"
    )
    sites = con.execute(f"""SELECT {SITE} AS site_group,severity,count(*) AS positive,
                            count(*) FILTER(WHERE mismatch) AS discordant,count(DISTINCT pid) AS patients,
                            count(DISTINCT pid) FILTER(WHERE mismatch) AS discordant_patients
                            FROM entries WHERE positive GROUP BY 1,2""").fetchall()
    by_site = {(s, h): (n, m, p, d) for s, h, n, m, p, d in sites}
    rows = []
    z = 1.959963984540054
    for site in ("sterile_or_deep", "urine_or_respiratory", "other_site"):
        for severity in ("high", "no_observed_marker", "unknown"):
            n, m, p, d = by_site.get((site, severity), (0, 0, 0, 0))
            bound = ["", "", ""]
            if d >= 11:
                phat = m / n
                denom = 1 + z * z / n
                center = (phat + z * z / (2 * n)) / denom
                radius = z * (phat * (1 - phat) / n + z * z / (4 * n * n)) ** 0.5 / denom
                bound = [100 * phat, 100 * max(0, center - radius), 100 * min(1, center + radius)]
            nc = "" if p < 11 <= n else count(n)
            mc = "" if d < 11 <= m else count(m)
            rows.append([site, severity, nc, mc, count(p), count(d), *bound])
    write(
        out / "restricted_sites_by_severity.csv",
        [
            "site",
            "severity",
            "positive_specimens",
            "mismatch_specimens",
            "positive_people",
            "mismatch_people",
            "percent",
            "lower95",
            "upper95",
        ],
        rows,
    )
    markers = []
    for name in (
        "high_risk",
        "low_map",
        "fever",
        "wbc_abnormal",
        "recent_support_stop",
        "pressor_on",
        "pressor_off",
        "vent_on",
        "vent_off",
        "sofa",
        "sofa_lab_minimum_ge2",
    ):
        condition = "sofa>=2" if name == "sofa" else name
        observed = "observed_lab_points" if name == "sofa_lab_minimum_ge2" else name
        value = con.execute(
            f"SELECT count({observed}),count(*) FILTER(WHERE {condition}) FROM markers"
        ).fetchone()
        markers.append([name, count(value[0]), count(value[1])])
    write(out / "bedside_marker_availability.csv", ["marker", "observed", "positive"], markers)
    periods["all"] = sum(periods.values())
    scores = []
    for rank, (name, flag) in enumerate(CANDIDATES.items()):
        for period in PERIODS:
            where = "" if period == "all" else " WHERE era=" + quoted(period)
            result = con.execute(f"""SELECT count(*) FILTER(WHERE review),
                   count(DISTINCT pid) FILTER(WHERE review AND mismatch),
                   count(*) FILTER(WHERE review AND mismatch),
                   count(*) FILTER(WHERE review AND positive)
                   FROM (SELECT *,({flag}) AS review FROM entries{where}) scored""").fetchone()
            scores.append((period, name, rank, periods.get(period, 0), *result))
    eligible = [r for r in scores if r[0] == "early" and 100 * r[4] < 15 * r[3]]
    locked = (
        min(eligible, key=lambda r: (-r[5], -r[6], -r[7], r[4], r[2]))[1]
        if eligible
        else "no_static_reviews"
    )
    output = (
        [
            p,
            k,
            k == locked,
            count(N),
            count(reviews),
            count(people),
            count(specimens),
            count(positive),
        ]
        for p, k, rank, N, reviews, people, specimens, positive in scores
    )
    write(
        out / "restricted_development_rules.csv",
        [
            "era",
            "strategy",
            "selected_in_early_period",
            "transfers",
            "reviews",
            "captured_gap_patients",
            "captured_gap_specimens",
            "captured_positive_specimens",
        ],
        output,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--partitions", type=Path, required=True, help="Patient-partitioned MIMIC-IV inputs"
    )
    parser.add_argument(
        "--mimic", type=Path, required=True, help="MIMIC-IV v3.1 root with hosp/ and icu/"
    )
    parser.add_argument(
        "--sofa", type=Path, help="Optional hourly rolling SOFA CSV, CSV.gz or Parquet file"
    )
    parser.add_argument(
        "--out", type=Path, required=True, help="New local aggregate output directory"
    )
    parser.add_argument("--memory-limit", default="2GB")
    args = parser.parse_args()
    out = args.out.resolve()
    if out.exists():
        parser.error("--out must be a new directory")
    out.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=out.parent, prefix="transfer_risk_") as tmp:
        stage = Path(tmp)
        cfg = {
            "temp_directory": str(stage / "spill"),
            "threads": "2",
            "memory_limit": args.memory_limit,
            "preserve_insertion_order": "false",
        }
        with duckdb.connect(config=cfg) as con:
            periods = risk_features(con, args.mimic, args.partitions, args.sofa, stage)
        for part in range(32):
            with duckdb.connect(config=cfg) as con:
                restricted_specimens(con, args.partitions, part, stage)
        results = stage / "aggregates"
        results.mkdir()
        with duckdb.connect(config=cfg) as con:
            output_aggregates(con, stage, periods, results)
        results.rename(out)


if __name__ == "__main__":
    main()
