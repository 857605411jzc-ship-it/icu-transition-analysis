CREATE TEMP TABLE last_pressure AS
WITH distinct_rows AS (
 SELECT DISTINCT c.pid, e.itemid, try_cast(e.charttime AS TIMESTAMP) AS at_time,
        try_cast(e.valuenum AS DOUBLE) AS val
 FROM src_chartevents e JOIN cohort c ON c.sid=try_cast(e.stay_id AS BIGINT)
   AND c.pid=try_cast(e.subject_id AS BIGINT) AND c.hid=try_cast(e.hadm_id AS BIGINT)
 WHERE e.itemid IN ('220052','220181','225312')
   AND try_cast(e.valuenum AS DOUBLE)>0 AND try_cast(e.valuenum AS DOUBLE)<300
   AND try_cast(e.charttime AS TIMESTAMP) BETWEEN c.tm-INTERVAL '24 hours' AND c.tm
   AND try_cast(e.storetime AS TIMESTAMP) BETWEEN try_cast(e.charttime AS TIMESTAMP) AND c.tm
   AND EXISTS(SELECT 1 FROM icu_intervals i WHERE i.pid=c.pid AND try_cast(e.charttime AS TIMESTAMP)>=i.began
              AND (try_cast(e.charttime AS TIMESTAMP)<i.ended OR (try_cast(e.charttime AS TIMESTAMP)=c.tm AND i.ended=c.tm)))
), at_clock AS (
 SELECT pid,at_time,avg(val) AS val FROM distinct_rows GROUP BY pid,at_time
)
SELECT pid,arg_max(val,at_time)<65 AS low_map FROM at_clock GROUP BY pid;

CREATE TEMP TABLE risk AS
WITH obs AS (
 SELECT c.pid,c.hid,m.low_map,t.fever,w.wbc_abnormal,
   CASE WHEN si.pid IS NOT NULL OR o.pressor_on OR o.pressor_off THEN coalesce(o.pressor_off,false) END AS pressor_off,
   CASE WHEN si.pid IS NOT NULL OR o.pressor_on OR o.pressor_off THEN coalesce(o.pressor_on,false) END AS pressor_on,
   CASE WHEN sp.pid IS NOT NULL OR v.vent_on OR v.vent_off THEN coalesce(v.vent_off,false) END AS vent_off,
   CASE WHEN sp.pid IS NOT NULL OR v.vent_on OR v.vent_off THEN coalesce(v.vent_on,false) END AS vent_on,
   b.observed_lab_domains,b.observed_lab_points,b.sofa_lab_minimum_ge2,h.sofa
 FROM cohort c LEFT JOIN last_pressure m USING(pid) LEFT JOIN temperatures t USING(pid)
 LEFT JOIN wbc w USING(pid) LEFT JOIN pressors o USING(pid) LEFT JOIN vent v USING(pid)
 LEFT JOIN input_observed si USING(pid) LEFT JOIN procedure_observed sp USING(pid)
 LEFT JOIN organ_lower_bound b USING(pid) LEFT JOIN hourly_sofa h USING(pid)
)
SELECT *,pressor_off OR vent_off AS recent_support_stop,
  low_map OR fever OR wbc_abnormal OR pressor_off OR pressor_on OR vent_off OR vent_on AS high_risk FROM obs;
