# Antibiotic reassessment and targeted susceptibility alerts for pending cultures after intensive care transfer

Analysis code for the multicenter cohort study and decision-support simulation. The main analysis follows adults from their first eligible ICU-to-ward transfer in MIMIC-IV. It measures antibiotic changes after culture reports, counts the reviews needed to identify a potential gap in treatment, and checks where the patient was when the result became available.

## Restricted data

Each analyst must obtain access to the source datasets in their own name and follow the data use agreement for each release. Run the analyses on a local system approved for that access. Do not upload or paste restricted data into online AI assistants, external model APIs, public repositories or third-party support services. This includes deidentified patient records, clinical notes, record excerpts, linkage keys, patient- or specimen-level extracts and logs that contain record values. Keep source files, intermediate databases, private indices, temporary storage and run outputs outside the code repository. Review aggregate exports for small cells and combinations that could reveal them before sharing.

[PhysioNet guidance on MIMIC data and online services](https://physionet.org/news/post/llm-responsible-use/) · [MIMIC-IV v3.1 data use agreement](https://physionet.org/content/mimiciv/view-dua/3.1/)

## Data sources

| Source release | Use in this study |
| --- | --- |
| [MIMIC-IV 3.1](https://doi.org/10.13026/kpb9-mt58) | ICU transfers, ward locations, microbiology, antibiotic orders and doses, clinical observations and hospital outcomes |
| [MIMIC-IV-Note 2.2](https://doi.org/10.13026/1n74-ne17) | Pending cultures and conditional antibiotic plans recorded in linked discharge summaries |
| [MIMIC-IV-Ext-CLIF 1.1.0](https://doi.org/10.13026/j481-g420) | Organ support and physiology at transfer in the linked clinical subgroups |
| [eICU-CRD 2.0](https://doi.org/10.13026/C2WM1R) | Orders extending beyond ICU discharge and availability of microbiology observations |
| [NWICU 0.1.0](https://doi.org/10.13026/s84w-1829) | Intravenous broad-spectrum orders active 48 hours after ICU exit |
| [INSPIRE 1.4.2](https://doi.org/10.13026/1eay-yc85) | Broad treatment administered during hours 24–48 after postoperative ICU exit |
| [Zigong infection ICU 1.1](https://doi.org/10.13026/xpt9-z726) | Onward specialty transfers within 48 hours and repeat broad prescriptions |

## Software

Use Python 3.10 or later and R with the DBI and duckdb packages. The analysis entry points were exercised with Python 3.12.14, NumPy 2.3.5, DuckDB 2.0.1, R 4.5.0, DBI 1.3.0 and the R duckdb package 2.0.1. Install dependencies before accessing restricted data. Run from the directory containing this README. Keep the originals from each data release in their own directory.

```sh
python -m pip install -r requirements.txt
Rscript -e "install.packages(c('DBI','duckdb'), repos='https://cloud.r-project.org')"
```

## Analysis order

Create the MIMIC partitions once and reuse them. The examples below use paths relative to a separate local data directory and a private working directory, both outside this repository. Replace the example paths with authorized local locations. Run the first two commands from the repository root.

```sh
python cohort/prepare.py --mimic ../data/mimic-iv-3.1 --out ../work/partitions
Rscript primary/run.R ../work/partitions ../data/mimic-iv-3.1/hosp/admissions.csv.gz ../work/primary
```

Keep the MIMIC `hosp/` and `icu/` directories under the release root. Table files can remain individually compressed as `.csv.gz`. Select the main release directory after unpacking an outer distribution archive. Give the R program the actual admissions file path if using uncompressed CSV or Parquet.

### Linked MIMIC analyses

Build the private indices from the same partitions. Run the clinical phenotype analysis before the note and safety analyses. It records each patient's measured physiology in the private working directory. For seven-day antibiotic exposure, the program reads the complete administration records beyond the shorter index window.

```sh
python followup/indices.py --partitions ../work/partitions --private ../work/indices
python followup/phenotype/run.py --private ../work/indices --mimic ../data/mimic-iv-3.1 --clif ../data/mimic-iv-ext-clif-1.1.0 --out ../work/physiology
python followup/harm/run.py --private ../work/indices --mimic ../data/mimic-iv-3.1 --out ../work/safety
python followup/notes/run.py --index ../work/indices/note_index.csv --notes ../data/mimic-iv-note-2.2 --phenotypes ../work/indices/alert_phenotypes.csv --out ../work/documentation
python followup/dot/run.py --private ../work/indices --mimic ../data/mimic-iv-3.1 --out ../work/exposure
```

### Restricted culture sensitivity analysis

For the analysis excluding reflex urine cultures, link the prepared cohort to bedside observations. This program summarizes potential coverage gaps by specimen site and transfer-time physiology and evaluates candidate transfer flags in the earlier calendar period. Use the optional `--sofa` argument only when an hourly rolling SOFA table is available for the corresponding release.

```sh
python sensitivity/clinical_risk.py --partitions ../work/partitions --mimic ../data/mimic-iv-3.1 --out ../work/restricted-risk
```

### External cohorts

Run each benchmark with its own source release and a new output directory. The timing and definition of follow-up differ across datasets. The two Zigong analyses also have different eligible populations.

```sh
python external/run.py --cohort eicu --source ../data/eicu-crd-2.0 --output ../work/eicu
python external/run.py --cohort nwicu --source ../data/nwicu-0.1.0 --output ../work/nwicu
python external/run.py --cohort inspire --source ../data/inspire-1.4.2 --output ../work/inspire
python external/run.py --cohort zigong --source ../data/zigong-infection-icu-1.1 --output ../work/zigong
```

## Finding the analysis for a paper result

| Paper result | Analysis |
| --- | --- |
| Table 1, Tables S1–S2 | `cohort/` selects the first eligible transfer. `primary/engine/` identifies pending cultures and compares implicated isolates with the recorded drugs. `primary/clinical/` summarizes the patient groups. |
| Table 2, Tables S3–S4 and S10 | `primary/order/` compares broad orders active when the report arrived, documented administrations, explicit no-growth results and individual drug classes. |
| Table 2, Table S9 | `followup/dot/` counts administered drug-days starting at the first midnight after reporting. A patient can contribute one observation in each setting. |
| Tables S5–S6 | `primary/clinical/` constructs the 48-hour landmark population, reconciles mortality records and models hospital death, ICU return and remaining length of stay. |
| Table 3, Tables S7 and S11 | `primary/policies/` computes review burden and paired patient capture. `primary/site/` computes location at reporting and subsequent matching orders and doses. |
| Table 4, Table S8 | `external/` computes the four benchmarks separately, including the hospital-level bootstrap for the overall eICU order estimate. |
| Tables S12–S13 | `followup/notes/`, `followup/phenotype/` and `followup/harm/` assess discharge-summary wording, clinical status, follow-up completeness and patient outcomes. |

Additional file 2 accompanies the article separately. It contains the reported aggregate source tables. When comparing a local run with those tables, match the population, culture definition, time window and denominator. For a combined policy, each presentation to clinicians counts toward workload. One patient identified by both components counts once toward patient capture. A drug order and a documented dose are separate outcomes. Cells withheld from an aggregate export are not zero.
