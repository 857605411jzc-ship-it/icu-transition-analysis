"""Post-ICU department movement in Zigong and intravenous orders in NWICU."""

import csv
import datetime as dt
import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from local_tables import read_rows

EPS = 1e-7
NULL = {"", "na", "nan", "null", "n/a", "\\n"}


def num(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def clock(s):
    if not s or ":" not in s:
        return None
    try:
        t = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        for fmt in (
            "%m/%d/%Y %H:%M:%S",
            "%m/%d/%Y %H:%M",
            "%Y/%m/%d %H:%M:%S",
            "%Y-%m-%d %I:%M:%S %p",
        ):
            try:
                t = dt.datetime.strptime(s, fmt)
                break
            except ValueError:
                continue
        else:
            return None
    if t.tzinfo:
        t = t.astimezone(dt.timezone.utc).replace(tzinfo=None)
    return (t - dt.datetime(1900, 1, 1)).total_seconds() / 3600


def projected(table, columns):
    return ({k: row[k] for k in columns if k in row} for row in table)


def unique(table, ids):
    out = {}
    for row in table:
        key = tuple(row[k] for k in ids)
        if any(s.casefold() in NULL for s in key):
            continue
        if key in out and row != out[key]:
            out[key] = None
        elif key not in out:
            out[key] = row
    return out


class Summary:
    def __init__(self, dataset):
        self.dataset = dataset
        self.data = []

    def prop(self, group, metric, h, n, N):
        if not 0 <= n <= N:
            raise ValueError("invalid_nested_counts")
        est = lo = hi = ""
        if n >= 11 and N >= 11:
            z = 1.959963984540054
            p = n / N
            q = 1 + z * z / N
            m = (p + z * z / (2 * N)) / q
            r = z * math.sqrt(p * (1 - p) / N + z * z / (4 * N * N)) / q
            est, lo, hi = [round(100 * x, 4) for x in (p, max(0, m - r), min(1, m + r))]
        self.data.append(
            [
                self.dataset,
                group,
                metric,
                h,
                "percent",
                n if n >= 11 else "<11",
                N if N >= 11 else "<11",
                est,
                lo,
                hi,
            ]
        )

    def write(self, path):
        with path.open("w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(
                [
                    "dataset",
                    "population",
                    "metric",
                    "hours",
                    "unit",
                    "numerator",
                    "denominator",
                    "estimate",
                    "lower95",
                    "upper95",
                ]
            )
            w.writerows(self.data)


ICU_RX = re.compile(
    r"\b(?:[cmsnprte]?icu|intensive care|critical care|critical care medicine|coronary care unit)\b|\u91cd\u75c7\u533b\u5b66|\u91cd\u75c7\u76d1\u62a4|\u5371\u91cd\u75c7\u533b\u5b66",
    re.I,
)
EXCLUDE_RX = re.compile(
    r"outpatient|emergency|operating room|theatre|theater|recovery room|an[ae]esthesia|laboratory|radiology|imaging|step.?down|high dependency|intermediate care|\u95e8\u8bca|\u6025\u8bca|\u624b\u672f\u5ba4|\u9ebb\u9189|\u68c0\u9a8c|\u5f71\u50cf|\u8fc7\u6e21|\u4e9a\u91cd\u75c7",
    re.I,
)
WARD_RX = re.compile(
    r"\b(?:medical ward|surgical ward|general ward|general medicine|internal medicine|general surgery|surgery|surgical|neurosurgery|urology|urologic|orthop[ae]+dic\w*|cardiology|cardiovascular|neurology|neurological|nephrology|gastroenterology|digestive|respiratory|pulmonology|pulmonary|endocrinology|geriatrics|geriatric|oncology|hematology|haematology|hepatobiliary|infectious diseases?|rehabilitation|obstetrics|gynecology|gynaecology|rheumatology|dermatology|otolaryngology)\b|\u5185\u79d1|\u5916\u79d1|\u9aa8\u79d1|\u5eb7\u590d\u533b\u5b66\u79d1|\u80bf\u7624\u79d1|\u611f\u67d3\u79d1|\u8840\u6db2\u79d1|\u5987\u79d1|\u4ea7\u79d1|\u8001\u5e74\u533b\u5b66\u79d1|\u8033\u9f3b\u5589\u79d1",
    re.I,
)


def unit_class(label):
    # Explicit ICU identifiers take precedence over a specialty name. Emergency
    # departments, recovery/step-down and unclassified departments are never wards.
    if re.search(r"outpatient|\u95e8\u8bca", label, re.I):
        return "unknown"
    if ICU_RX.search(label):
        return "icu"
    if EXCLUDE_RX.search(label):
        return "unknown"
    return "specialty" if WARD_RX.search(label) else "unknown"


def zigong(files):
    base_fields = [
        "inp_no",
        "patient_id",
        "age",
        "discharge_date_time",
        "icu_discharge_time",
        "infectionsite",
    ]
    base = unique(
        projected(read_rows(files, "dtbaseline", base_fields[:4]), base_fields),
        ["inp_no"],
    )
    freqs = Counter(
        x["patient_id"]
        for x in base.values()
        if x and x["patient_id"].casefold() not in NULL
    )
    seq = defaultdict(set)
    invalid = set()
    for r in read_rows(
        files, "dttransfer", ["inp_no", "transferdept", "starttime", "stoptime"]
    ):
        hid = r["inp_no"]
        a, b = num(r["starttime"]), num(r["stoptime"])
        if a is None or b is None or b < a:
            invalid.add(hid)
            continue
        name = r["transferdept"].lower().strip()
        if b > a:
            seq[hid].add((a, b, name, unit_class(name)))
    stats = defaultdict(Counter)
    adult = 0
    targets = 0
    for (h,), x in base.items():
        if not x or freqs[x["patient_id"]] != 1 or (num(x["age"]) or 0) < 18:
            continue
        adult += 1
        end = num(x["discharge_date_time"])
        s = sorted(seq[h])
        if (
            h in invalid
            or not end
            or end <= 0
            or any(i[1] > j[0] + EPS for i, j in zip(s, s[1:]))
        ):
            continue
        ix = next(
            (
                j
                for j in range(1, len(s))
                if s[j - 1][3] == "icu"
                and s[j][3] == "specialty"
                and abs(s[j - 1][1] - s[j][0]) <= EPS
                and s[j - 1][0] >= 0
                and 0 <= s[j][0] < end
            ),
            None,
        )
        if ix is None:
            continue
        targets += 1
        t0 = s[ix][0]
        first = s[ix][2]
        for horizon in (24, 48, 72):
            b = stats[horizon]
            cut = t0 + horizon
            if cut >= end - EPS:
                b["hospital_exit"] += 1
                continue
            b["inpatient"] += 1
            pos = t0
            other = False
            here = None
            for a, z, l, k in s[ix:]:
                if a > cut + EPS:
                    break
                if a > pos + EPS or k == "unknown":
                    break
                if l != first:
                    other = True
                pos = max(pos, z)
                if a <= cut + EPS and cut < z - EPS:
                    here = (l, k)
                    break
            if here is None:
                continue
            b["known"] += 1
            b["ever_left"] += other
            l, k = here
            b["same"] += l == first
            b["other_specialty"] += k == "specialty" and l != first
            b["icu"] += k == "icu"

    res = Summary("Zigong infection ICU")
    res.prop("adult_admissions", "first_adjacent_ICU_to_specialty", 0, targets, adult)
    for t, b in stats.items():
        group = "index_transfers"
        res.prop(group, "hospital_exit_by_horizon", t, b["hospital_exit"], targets)
        res.prop(
            "still_in_hospital",
            "continuously_observed_location",
            t,
            b["known"],
            b["inpatient"],
        )
        outside = b["other_specialty"] + b["icu"]
        res.prop(
            "still_in_hospital_continuously_observed",
            "outside_first_specialty",
            t,
            outside,
            b["known"],
        )
        res.prop("outside_first_specialty", "in_ICU", t, b["icu"], outside)
        res.prop(
            "outside_first_specialty",
            "on_other_specialty",
            t,
            b["other_specialty"],
            outside,
        )
        for m in ("ever_left", "same", "other_specialty", "icu"):
            res.prop("still_in_hospital_continuously_observed", m, t, b[m], b["known"])
    return res


@dataclass
class Index:
    t: float
    end: float
    back: float
    rx: list = field(default_factory=list)
    order48: bool = False


def index_nw(files):
    A = ["subject_id", "hadm_id", "admittime", "dischtime"]
    stays = ["subject_id", "hadm_id", "stay_id", "intime", "outtime"]
    admissions = unique(
        projected(
            read_rows(files, "admissions", A), A + ["deathtime", "hospital_expire_flag"]
        ),
        A[:2],
    )
    data = list(projected(read_rows(files, "icustays", stays), stays))
    spells = unique(data, stays[:3])
    sched = defaultdict(list)
    for r in data:
        if r["stay_id"].casefold() in NULL:
            sched[(r["subject_id"], r["hadm_id"])].append((None, None))
    for (p, h, _), r in spells.items():
        sched[p, h].append(
            (clock(r["intime"]), clock(r["outtime"])) if r else (None, None)
        )
    picked = defaultdict(list)
    for key, s in sched.items():
        r = admissions.get(key)
        if not r or any(a is None or z is None or a >= z for a, z in s):
            continue
        s = sorted(s)
        a, e = clock(r["admittime"]), clock(r["dischtime"])
        if (
            a is None
            or e is None
            or s[0][0] < a
            or max(x[1] for x in s) > e
            or any(l[1] > rr[0] for l, rr in zip(s, s[1:]))
        ):
            continue
        t0 = s[0][1]
        death = clock(r.get("deathtime", ""))
        if r.get("deathtime", "").casefold() not in NULL and death is None:
            continue
        if death is not None and (death <= t0 or death > e):
            continue
        end = min(death, e) if death is not None else e
        if end <= t0:
            continue
        back = min((a for a, z in s[1:] if a >= t0), default=end)
        picked[key[0]].append((t0, key, Index(t0, end, back)))
    result = {}
    for vals in picked.values():
        t = min(x[0] for x in vals)
        w = [v for v in vals if v[0] == t]
        if len(w) == 1:
            result[w[0][1]] = w[0][2]
    return result


DRUG = [
    (
        "piperacillin_tazobactam",
        r"zosyn|tazocin|piperacillin.{0,16}tazobactam|pip.?tazo",
    ),
    ("imipenem_cilastatin", r"primaxin|imipenem"),
    ("meropenem", r"merrem|meropenem"),
    ("ertapenem", r"invanz|ertapenem"),
    ("cefepime", r"maxipime|cefepime"),
    ("ceftazidime", r"fortaz|tazicef|ceftazidime"),
    ("vancomycin", r"vancocin|vancoready|vancomycin"),
    ("linezolid", r"zyvox|linezolid"),
]
AGENT_RX = [(name, re.compile(patt, re.I)) for name, patt in DRUG]
EXCLUDED = re.compile(
    r"avibactam|vaborbactam|relebactam|avycaz|vabomere|recarbrio|placeholder|consult|by pharmacy|dose by levels|dosing per pharmacy|per protocol",
    re.I,
)
LOCAL = re.compile(
    r"\b(oral|po|ophth\w*|otic|inhal\w*|nebul\w*|topical|lock|intrathecal|intraperitoneal|irrig\w*|intracameral|intravesical|intravitreal|IM|intraosseous|subcutaneous|g tube|ng tube)\b",
    re.I,
)
IV = re.compile(r"\b(iv|ivpb|ivp|ivpiggyback|intravenous\w*)\b", re.I)


def drug(name):
    if EXCLUDED.search(name):
        return None
    return next((k for k, rx in AGENT_RX if rx.search(name)), None)


def route(field, name):
    # Explicit non-IV routes, including those embedded in IV-stock drug labels, take precedence.
    if LOCAL.search(field) or LOCAL.search(name):
        return "other"
    if IV.search(field) or IV.search(name):
        return "iv"
    return "unknown"


def dim(drugs):
    return (
        ({"mrsa"} if drugs & {"vancomycin", "linezolid"} else set())
        | (
            {"ap"}
            if drugs
            & {
                "piperacillin_tazobactam",
                "imipenem_cilastatin",
                "meropenem",
                "cefepime",
                "ceftazidime",
            }
            else set()
        )
        | (
            {"carb"}
            if drugs & {"imipenem_cilastatin", "meropenem", "ertapenem"}
            else set()
        )
    )


def regimen(v, time):
    agents = set()
    unknown = False
    for ag, start, stop, r in v.rx:
        if r != "other" and start <= time and (stop is None or time < stop):
            if stop is None or r == "unknown":
                unknown = True
            if stop is not None and r == "iv":
                agents.add(ag)
    return agents, unknown


def nw_orders(files, index):
    req = ["subject_id", "hadm_id", "drug", "route", "starttime", "stoptime"]
    for r in read_rows(files, "prescriptions", req):
        z = index.get((r["subject_id"], r["hadm_id"]))
        if z is None:
            continue
        start = clock(r["starttime"])
        if start is None or start >= min(z.end, z.t + 192):
            continue
        stop = clock(r["stoptime"])
        if stop is not None and (stop <= start or stop <= z.t - 24):
            continue
        if stop is not None and start <= z.t + 48 < stop:
            z.order48 = True
        ag = drug(r["drug"])
        if ag:
            rt = route(r["route"], r["drug"])
            z.rx.append((ag, start, stop, rt))
    summary = Summary("NWICU")
    active = full = continued = reduced = stopped = 0
    for z in index.values():
        base, u = regimen(z, z.t)
        if u or not base:
            continue
        active += 1
        post, x = regimen(z, z.t + 48)
        if min(z.back, z.end) <= z.t + 48 or not z.order48 or x:
            continue
        full += 1
        stopped += not post
        diminished = (len(post) < len(base) or dim(post) < dim(base)) and dim(
            post
        ) <= dim(base)
        reduced += diminished
        continued += bool(post)
    summary.prop(
        "first_eligible_ICU_exit",
        "qualifying_IV_regimen_at_exit",
        0,
        active,
        len(index),
    )
    summary.prop(
        "active_IV_regimen_at_exit",
        "still_observable_before_next_ICU_at_48h",
        48,
        full,
        active,
    )
    for k, val in [
        ("any_restricted_order_still_active", continued),
        ("reduced_or_stopped_class_regimen", reduced),
        ("no_restricted_order_still_active", stopped),
    ]:
        summary.prop("qualifying_IV_regimen_evaluable_at_48h", k, 48, val, full)
    return summary
