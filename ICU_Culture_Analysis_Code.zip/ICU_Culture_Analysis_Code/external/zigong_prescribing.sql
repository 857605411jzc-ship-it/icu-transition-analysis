-- Offsets are hours from hospital admission. Restrict drugs to patients mapping to one admission.
create temp table zb as
select inp_no as adm,patient_id as pid,try_cast(age as double) as age,
 try_cast(discharge_date_time as double) as hd
from dtbaseline where inp_no is not null and patient_id is not null
qualify count(*) over(partition by inp_no)=1 and count(*) over(partition by patient_id)=1;
create temp table zsegments as
select distinct inp_no as adm,lower(trim(transferdept)) as dept,try_cast(starttime as double) as st,
 try_cast(stoptime as double) as en,
 regexp_matches(lower(trim(transferdept)),'(^|[^a-z])([a-z]{0,3}icu|intensive care|critical care)([^a-z]|$)|重症|监护') as icu
from dttransfer where nullif(trim(transferdept),'') is not null and try_cast(stoptime as double)>try_cast(starttime as double);
create temp table ze as
select b.adm,b.pid,b.hd,w.st as t0,w.dept
from zb b join zsegments w on w.adm=b.adm and not w.icu
where b.age>=18 and w.st>=0 and b.hd>=w.st
 and not regexp_matches(w.dept,'outpatient|emergency|operating room|recovery room|手术室|急诊|门诊|麻醉恢复')
 and exists(select 1 from zsegments i where i.adm=w.adm and i.icu and abs(i.en-w.st)<=1 and i.st<w.st)
 and not exists(select 1 from zsegments d where d.adm=w.adm and d.dept<>w.dept and d.st<=w.st and d.en>w.st+1)
qualify row_number() over(partition by b.adm order by w.st,w.dept)=1;
create temp table zdrug as select d.patient_id as pid, try_cast(drug_time as double) as at_hr, lower(drugname) as name,
 selected_agent(drugname) as agent from dtdrugs d;
create temp table zfull as
select z.*,
 exists(select 1 from zsegments s where s.adm=z.adm and s.dept=z.dept and s.st<=z.t0+48 and s.en>z.t0+48) as in_first,
 exists(select 1 from zsegments s where s.adm=z.adm and s.dept<>z.dept and s.st<=z.t0+48 and s.en>z.t0+48) as in_other,
 exists(select 1 from zsegments s where s.adm=z.adm and s.icu and s.st<=z.t0+48 and s.en>z.t0+48) as in_icu,
 exists(select 1 from zdrug d join ingredients i using(agent) where d.pid=z.pid and i.broad=1
   and d.at_hr between z.t0-24 and z.t0 and not regexp_matches(name,'oral vancomycin|vancomycin.*oral|口服万古霉素|eye drop|ophth|topical|滴眼|外用')) as prior_broad,
 exists(select 1 from zdrug d where d.pid=z.pid and d.at_hr>z.t0 and d.at_hr<=z.t0+48) as next_any,
 exists(select 1 from zdrug d join ingredients i using(agent) where d.pid=z.pid and i.broad=1 and
   d.at_hr>z.t0 and d.at_hr<=z.t0+48 and not regexp_matches(name,'oral vancomycin|vancomycin.*oral|口服万古霉素|eye drop|ophth|topical|滴眼|外用')) as next_broad
from ze z where z.hd>z.t0+48;
