CREATE TEMP TABLE units AS
SELECT patientunitstayid::BIGINT AS stay_id, patienthealthsystemstayid::BIGINT AS adm_id,
 hospitalid::INTEGER AS hospital, try_cast(hospitaladmitoffset AS INTEGER) AS admit_offset,
 try_cast(unitdischargeoffset AS INTEGER) AS t0, try_cast(hospitaldischargeoffset AS INTEGER) AS end_hosp,
 lower(trim(unitdischargeSTATUS)) AS vital, lower(trim(unitdischargelocation)) AS destination,
 lower(trim(unittype)) AS unit, CASE WHEN starts_with(trim(age),'>') THEN 90 ELSE try_cast(age AS INTEGER) END AS years
FROM src_patient;
CREATE TEMP TABLE cohort AS
SELECT * FROM (
  SELECT u.*, t0-admit_offset AS minutes_to_transfer
  FROM units u
  WHERE years>=18 AND vital='alive' AND t0>0 AND end_hosp>t0 AND admit_offset<=0
    AND (unit LIKE '%icu%' OR unit IN ('ccu','cardiac care unit','coronary care unit'))
    AND NOT regexp_matches(unit,'test|virtual|mobile|step.?down')
    AND destination IN ('floor','acute care/floor')
) a QUALIFY row_number() OVER(PARTITION BY adm_id ORDER BY minutes_to_transfer,stay_id)=1;
CREATE TEMP MACRO order_class(x) AS CASE
 WHEN regexp_matches(x,'consult|placeholder|pharmacist to (dose|manage)|random level|trough level|level only') THEN 'other'
 WHEN regexp_matches(x,'vancomycin|vancocin|vancoready') THEN 'vancomycin'
 WHEN regexp_matches(x,'linezolid|zyvox') THEN 'linezolid'
 WHEN regexp_matches(x,'daptomycin|cubicin') THEN 'daptomycin'
 WHEN regexp_matches(x,'piperacillin.{0,18}tazo|piper.{0,10}tazo|zosyn|tazocin') THEN 'pip_tazo'
 WHEN regexp_matches(x,'cefepime|maxipime') THEN 'cefepime'
 WHEN regexp_matches(x,'ceftazidime|fortaz|tazicef|av(y|i)caz') THEN 'ceftazidime_family'
 WHEN regexp_matches(x,'meropenem|merrem|vabomere') THEN 'meropenem_family'
 WHEN regexp_matches(x,'imipenem|primaxin|recarbrio') THEN 'imipenem_family'
 WHEN regexp_matches(x,'ertapenem|invanz') THEN 'ertapenem'
 WHEN regexp_matches(x,'doripenem|doribax') THEN 'doripenem'
 ELSE 'other' END;
CREATE TEMP TABLE meds AS
SELECT try_cast(patientunitstayid AS BIGINT) AS stay_id, try_cast(drugorderoffset AS INTEGER) AS ordered,
 try_cast(drugstartoffset AS INTEGER) AS began, try_cast(drugstopoffset AS INTEGER) AS ended,
 lower(trim(coalesce(drugname,''))) AS drug, nullif(trim(drughiclseqno),'') AS code,
 lower(trim(coalesce(routeadmin,''))) AS route, lower(trim(coalesce(drugordercancelled,''))) AS cancelled,
 order_class(lower(trim(coalesce(drugname,'')))) AS agent FROM src_medication;
-- HICL bridges unnamed orders only when all nonempty names for that code agree on one category.
CREATE TEMP TABLE code_map AS
SELECT code, min(agent) AS agent FROM meds WHERE code IS NOT NULL AND code NOT IN ('0','-1') AND drug<>''
GROUP BY code HAVING count(DISTINCT agent)=1;
CREATE TEMP TABLE regimens AS
SELECT m.*, CASE WHEN drug<>'' THEN m.agent ELSE cm.agent END AS known_agent,
 regexp_matches(route,'^(iv([^a-z]|$)|ivpb|ivp($|ush)|intrav(en|$)|intramus|im($|[^a-z]))') AS parenteral,
 regexp_matches(route,'^(po($|[^a-z])|oral($|[^a-z])|per os|ngt?$|ogt?$|peg$|per .*tube|ng tube)') AS enteral,
 regexp_matches(drug,'oral solution|oral cap|enema|ophthal|intravitreal|intrathecal|topical|inhal|nebul|lock (sol|flush)|irrig') AS explicit_nonsystemic,
 regexp_matches(drug,'ophthal|intravitreal|intrathecal|topical|inhal|nebul|lock (sol|flush)|irrig') AS explicit_local
FROM meds m LEFT JOIN code_map cm USING(code);
CREATE TEMP TABLE rx AS
WITH src AS (
 SELECT c.stay_id,c.t0,r.ordered,r.began,r.ended,r.cancelled,r.known_agent,r.drug,
 r.cancelled='no' AND r.ordered<=c.t0 AND r.began<c.t0 AND r.ended>greatest(0,c.t0-1440) AND
   r.ended>r.began AS observed_interval,
 r.known_agent IS NOT NULL AND r.known_agent<>'other' AND 
 ((r.parenteral AND NOT r.explicit_nonsystemic) OR (r.enteral AND r.known_agent='linezolid' AND NOT r.explicit_local)) AS broad
 FROM cohort c LEFT JOIN regimens r ON c.stay_id=r.stay_id
)
SELECT stay_id,
 coalesce(bool_or(observed_interval AND known_agent IS NOT NULL),false) AS known_order24,
 coalesce(bool_or(observed_interval AND broad),false) AS broad24,
 coalesce(bool_or(observed_interval AND broad AND ended>t0),false) AS broad_past_exit,
 coalesce(bool_or(observed_interval AND broad AND drug<>''),false) AS broad24_named,
 coalesce(bool_or(observed_interval AND broad AND known_agent IN ('vancomycin','linezolid','daptomycin')),false) AS mrsa24,
 coalesce(bool_or(observed_interval AND broad AND known_agent NOT IN ('vancomycin','linezolid','daptomycin')),false) AS gn24
FROM src GROUP BY stay_id;
CREATE TEMP VIEW final AS
SELECT c.hospital,c.stay_id,c.adm_id,x.* EXCLUDE(stay_id)
FROM cohort c JOIN rx x USING(stay_id);
