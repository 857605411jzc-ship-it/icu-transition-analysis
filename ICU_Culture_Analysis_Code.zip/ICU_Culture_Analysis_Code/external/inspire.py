"""Postoperative ICU exits and broad antibiotic administrations in INSPIRE."""

import csv
import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from functools import lru_cache
from local_tables import rows

OP_COLS = {
    "subject_id",
    "hadm_id",
    "op_id",
    "age",
    "opstart_time",
    "opend_time",
    "icuin_time",
    "icuout_time",
    "admission_time",
    "discharge_time",
    "inhosp_death_time",
}
MED_COLS = {"subject_id", "chart_time", "route"}
ATC_TOKEN = re.compile(r"(?<![A-Z0-9])[A-Z]\d{2}[A-Z]{2}\d{2}(?![A-Z0-9])")
# M = anti-MRSA; P = antipseudomonal; C = carbapenem. Count each combination product once.
SPEC = {
    "vancomycin": ("M", "J01XA01"),
    "linezolid": ("M", "J01XX08"),
    "daptomycin": ("M", "J01XX09"),
    "tedizolid": ("M", "J01XX11"),
    "ceftaroline": ("M", "J01DI02"),
    "telavancin": ("M", "J01XA03"),
    "piperacillin_tazobactam": ("P", "J01CR05"),
    "cefepime": ("P", "J01DE01"),
    "ceftazidime": ("P", "J01DD02"),
    "ceftazidime_avibactam": ("P", "J01DD52"),
    "ceftolozane_tazobactam": ("P", "J01DI54"),
    "cefiderocol": ("P", "J01DI04"),
    "aztreonam": ("P", "J01DF01"),
    "ciprofloxacin": ("P", "J01MA02"),
    "levofloxacin": ("P", "J01MA12"),
    "gentamicin": ("P", "J01GB03"),
    "amikacin": ("P", "J01GB06"),
    "tobramycin": ("P", "J01GB01"),
    "colistin": ("P", "J01XB01"),
    "polymyxin_b": ("P", "J01XB02"),
    "ertapenem": ("C", "J01DH03"),
    "meropenem": ("PC", "J01DH02"),
    "doripenem": ("PC", "J01DH04"),
    "imipenem": ("PC", "J01DH51"),
    "meropenem_vaborbactam": ("PC", "J01DH52"),
    "imipenem_relebactam": ("PC", "J01DH56"),
    # A predeclared regional extension. Kept out of the frozen MIMIC ingredient list.
    "teicoplanin": ("M", "J01XA02"),
}
ATC = {c: a for a, (_, c) in SPEC.items()}
ALIASES = {
    "colistimethate": "colistin",
    "colistimethate sodium": "colistin",
    "polymyxin b": "polymyxin_b",
    "ceftaroline fosamil": "ceftaroline",
    "tedizolid phosphate": "tedizolid",
}
IV = {
    "iv",
    "i v",
    "intravenous",
    "intravenous injection",
    "intravenous infusion",
    "iv injection",
    "iv infusion",
    "im",
    "intramuscular",
    "sc",
    "subcutaneous",
    "parenteral",
}
ORAL = {
    "po",
    "p o",
    "oral",
    "per oral",
    "per os",
    "by mouth",
    "enteral",
    "nasogastric",
    "g tube",
}
ORAL_AGENTS = {"ciprofloxacin", "levofloxacin", "linezolid", "tedizolid"}
LOCAL = {
    "ex",
    "external",
    "topical",
    "inhaled",
    "inhalation",
    "ophthalmic",
    "otic",
    "eye",
    "ear",
    "intravesical",
    "irrigation",
    "intrathecal",
    "intraperitoneal",
    "intraventricular",
    "lock",
    "nebulizer",
}


def norm(x):
    return " ".join(re.sub(r"[^a-z0-9]+", " ", (x or "").strip().lower()).split())


def numeric(x):
    try:
        n = float(x)
        return n if math.isfinite(n) else None
    except (ValueError, TypeError):
        return None


@lru_cache(maxsize=8192)
def ingredients(names, codes):
    text = norm(" ".join(names))
    padded = " " + text + " "
    hits = {
        ATC[token]
        for c in codes
        for token in ATC_TOKEN.findall(c.upper())
        if token in ATC
    }
    # Drug ingredients can occupy any slot; salts are normalized and combined before indexing.
    for drug in SPEC:
        if "_" not in drug and " " + drug + " " in padded:
            hits.add(drug)
    for term, drug in ALIASES.items():
        if " " + term + " " in padded:
            hits.add(drug)
    for a, b, bundle in (
        ("piperacillin", "tazobactam", "piperacillin_tazobactam"),
        ("ceftazidime", "avibactam", "ceftazidime_avibactam"),
        ("ceftolozane", "tazobactam", "ceftolozane_tazobactam"),
        ("imipenem", "relebactam", "imipenem_relebactam"),
        ("meropenem", "vaborbactam", "meropenem_vaborbactam"),
    ):
        if bundle in hits or (" " + a + " " in padded and " " + b + " " in padded):
            hits.discard(a)
            hits.add(bundle)
    return frozenset(hits)


@dataclass
class Exit:
    hadm: str
    t: float
    last: float
    death: bool
    start: float
    medication: dict = field(
        default_factory=lambda: {"before": set(), "early": set(), "after": set()}
    )
    uncertain: dict = field(
        default_factory=lambda: {"before": set(), "early": set(), "after": set()}
    )
    clocks: dict = field(default_factory=lambda: defaultdict(set))
    docs: set = field(default_factory=set)


def cohort(spec):
    hist = defaultdict(list)
    with rows(spec, OP_COLS) as reader:
        for row in reader:
            key = row["subject_id"].strip()
            hadm = row["hadm_id"].strip()
            op = row["op_id"].strip()
            if not key or not hadm or not op:
                continue
            hist[key].append(
                (
                    hadm,
                    op,
                    *(
                        numeric(row[k])
                        for k in [
                            "age",
                            "admission_time",
                            "discharge_time",
                            "inhosp_death_time",
                            "opstart_time",
                            "opend_time",
                            "icuin_time",
                            "icuout_time",
                        ]
                    ),
                )
            )
    indexes = {}
    flow = Counter(all_surgical_people=len(hist))
    for key, h in hist.items():
        candidates = []
        for hadm, op, age, ad, dc, death, start, end, ii, ot in h:
            if None in (age, ad, dc, start, end, ii, ot) or age < 18:
                continue
            # The source only represents ICU stays associated with the perioperative window.
            if not (
                ad <= start <= end <= ot and end <= ii < ot < dc and ii - end <= 1440
            ):
                continue
            if death is not None and death <= ot:
                continue
            candidates.append((ot, abs(ii - end), op, hadm, ii, end))
        if not candidates:
            continue
        ot, _, op, hadm, ii, end = min(candidates)
        adm_times = {
            (a, b)
            for h2, _, _, a, b, *rest in h
            if h2 == hadm and a is not None and b is not None
        }
        if len(adm_times) != 1:
            flow["conflicting_index_admission_times"] += 1
            continue
        ad, dc = adm_times.pop()
        deaths = {v[5] for v in h if v[0] == hadm and v[5] is not None}
        if len(deaths) > 1 or any(x < ad or x > dc for x in deaths):
            flow["conflicting_index_death_times"] += 1
            continue
        death = next(iter(deaths), None)
        last = min(dc, death) if death is not None else dc
        if last <= ot:
            continue
        base = max(ot - 1440, ii, end)
        horizon = min(last, ot + 2880)
        # Subject is the documented medication linkage key. Exclude competing admissions.
        conflict = any(
            h2 != hadm and (a is None or b is None or (a < horizon and b > base))
            for h2, _, _, a, b, *rest in h
        )
        if conflict:
            flow["overlap_or_unknown_other_admission"] += 1
            continue
        indexes[key] = Exit(hadm, ot, last, death is not None, base)
    flow["first_eligible_postoperative_icu_exit"] = len(indexes)
    return indexes, flow


def record(x, t, route, active):
    dt = t - x.t
    if t < x.start or t >= x.last or dt <= -1440 or dt > 2880:
        return
    window = "before" if dt <= 0 else "early" if dt <= 1440 else "after"
    half = (
        0
        if dt <= -720
        else 1
        if dt <= 0
        else 2
        if dt <= 720
        else 3
        if dt <= 1440
        else 4
        if dt <= 2160
        else 5
    )
    x.docs.add(half)
    for drug in active:
        if route in IV or (route in ORAL and drug in ORAL_AGENTS):
            x.medication[window].add(drug)
            if window == "before":
                x.clocks[drug].add(t)
        elif route in LOCAL or (route in ORAL and drug == "vancomycin"):
            continue
        else:
            x.uncertain[window].add(drug)


NULL_VALUES = {"", "na", "n/a", "nan", "none", "null"}


def value(value):
    return (
        "" if value is None or value.strip().lower() in NULL_VALUES else value.strip()
    )


def drug_columns(columns):
    def slots(stem):
        short = stem.replace("_", "")
        return tuple(
            c
            for c in columns
            if re.fullmatch(
                short + r"(?:[1-9][0-9]*)?",
                c.replace("_", "").replace(" ", "").replace(".", ""),
            )
        )

    names = slots("drug_name")
    codes = slots("atc_code")
    if not names and not codes:
        raise ValueError("No medication ingredient or ATC column")
    return names, codes


@lru_cache(maxsize=8192)
def unclear_combination(names, codes, active):
    text = " " + norm(" ".join(names)) + " "
    # Pooled component rows at one clock cannot establish a shared product.
    # Regimens with an unresolved piperacillin-containing formulation remain explicit.
    return {
        bundle
        for stem, bundle in [
            ("piperacillin", "piperacillin_tazobactam"),
            ("ceftolozane", "ceftolozane_tazobactam"),
        ]
        if " " + stem + " " in text and bundle not in active
    }


def read_med(spec, data):
    with rows(spec, MED_COLS) as reader:
        names, codes = drug_columns(reader.fieldnames)
        for r in reader:
            x = data.get(r["subject_id"].strip())
            if x is None:
                continue
            t = numeric(r["chart_time"])
            if (
                t is None
                or t < x.start
                or t <= x.t - 1440
                or t > x.t + 2880
                or t >= x.last
            ):
                continue
            if r.get("hadm_id") and r["hadm_id"].strip() != x.hadm:
                continue
            meds = tuple(value(r[k]) for k in names)
            atcs = tuple(value(r[k]) for k in codes)
            if not any(meds + atcs):
                continue
            active = ingredients(meds, atcs)
            route = norm(r["route"])
            record(x, t, route, active)
            unclear = unclear_combination(meds, atcs, active)
            if unclear and route not in LOCAL and route not in ORAL:
                window = (
                    "before" if t <= x.t else "early" if t <= x.t + 1440 else "after"
                )
                x.uncertain[window].update(unclear)


def classify(before, after):
    if not after:
        return "complete_withdrawal"
    old = set("".join(SPEC[d][0] for d in before))
    new = set("".join(SPEC[d][0] for d in after))
    if new <= old and (new < old or len(after) < len(before)):
        return "partial_reduction"
    if before == after:
        return "same_agents"
    if old == new and len(before) == len(after):
        return "substitution_same_class_count"
    return "expanded_or_other_change"


def measures(data, flow):
    rate_groups = defaultdict(Counter)
    for x in data.values():
        conventional = lambda values: {v for v in values if v != "teicoplanin"}
        if conventional(x.uncertain["before"]) and not conventional(
            x.medication["before"]
        ):
            flow["only_uncertain_listed_baseline_route"] += 1
        for a in ["MIMIC_list", "MIMIC_list_repeated_baseline_dose"]:
            drugs = conventional
            before = drugs(x.medication["before"])
            after = drugs(x.medication["after"])
            if not before:
                continue
            if a == "MIMIC_list":
                flow["documented_broad_baseline"] += 1
            if x.last <= x.t + 2880:
                if a == "MIMIC_list":
                    flow[
                        "death_at_or_before_48h"
                        if x.death
                        else "discharge_alive_at_or_before_48h"
                    ] += 1
                continue
            if not {0, 1, 4, 5}.issubset(x.docs):
                if a == "MIMIC_list":
                    flow["insufficient_medication_clocks"] += 1
                continue
            if (
                drugs(x.uncertain["before"]) - before
                or drugs(x.uncertain["after"]) - after
            ):
                if a == "MIMIC_list":
                    flow["uncertain_restricted_route"] += 1
                continue
            if (
                "repeated_baseline" in a
                and len(set.union(set(), *(x.clocks[k] for k in before))) < 2
            ):
                continue
            group = rate_groups[a]
            group["evaluable"] += 1
            result = classify(before, after)
            group[result] += 1
            if result in {"complete_withdrawal", "partial_reduction"}:
                group["any_reduction"] += 1
            if after:
                group["any_broad_dose_in_hours_24_to_48"] += 1
    for a in ["MIMIC_list", "MIMIC_list_repeated_baseline_dose"]:
        rate_groups[a]["evaluable"] += 0
    return rate_groups


def public(n):
    return str(n) if n >= 11 else "<11"


def interval(n, N):
    if n < 11 or N < 11:
        return ("", "", "")
    z = 1.95996398454005
    p = n / N
    d = 1 + z * z / N
    c = (p + z * z / (2 * N)) / d
    h = z * math.sqrt(p * (1 - p) / N + z * z / (4 * N * N)) / d
    return tuple(f"{100 * v:.5f}" for v in (p, max(0, c - h), min(1, c + h)))


def write_clinical(rundir, rates, flow):
    rowsout = []
    for a, c in rates.items():
        N = c["evaluable"]
        for metric in [
            "any_reduction",
            "complete_withdrawal",
            "partial_reduction",
            "same_agents",
            "substitution_same_class_count",
            "expanded_or_other_change",
            "any_broad_dose_in_hours_24_to_48",
        ]:
            rowsout.append(
                (a, metric, public(c[metric]), public(N), *interval(c[metric], N))
            )
    with (rundir / "INSPIRE_antibiotic_continuation.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as f:
        w = csv.writer(f)
        w.writerow(
            [
                "definition",
                "metric",
                "patients",
                "eligible",
                "percent",
                "lower95",
                "upper95",
            ]
        )
        w.writerows(rowsout)
    with (rundir / "INSPIRE_flow.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["measure", "patients"])
        for name in [
            "all_surgical_people",
            "conflicting_index_admission_times",
            "conflicting_index_death_times",
            "overlap_or_unknown_other_admission",
            "first_eligible_postoperative_icu_exit",
            "only_uncertain_listed_baseline_route",
            "documented_broad_baseline",
            "discharge_alive_at_or_before_48h",
            "death_at_or_before_48h",
            "insufficient_medication_clocks",
            "uncertain_restricted_route",
            "evaluable",
        ]:
            w.writerow(
                [
                    name,
                    public(
                        rates["MIMIC_list"]["evaluable"]
                        if name == "evaluable"
                        else flow[name]
                    ),
                ]
            )
