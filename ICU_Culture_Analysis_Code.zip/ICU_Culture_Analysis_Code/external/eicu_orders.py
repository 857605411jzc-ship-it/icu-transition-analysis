"""Broad antibiotic orders in the final ICU day in eICU-CRD."""

import csv
import subprocess
from pathlib import Path

import duckdb

from culture_orders import rate, sqlquote

HERE = Path(__file__).resolve().parent


def analyze(files, work, out):
    with duckdb.connect(str(work / "orders.duckdb")) as con:
        con.execute("SET threads=2")
        con.execute("SET memory_limit='2GB'")
        con.execute("SET temp_directory=" + sqlquote(work / "order_spill"))
        for name in ("patient", "medication"):
            con.execute(
                f"CREATE VIEW src_{name} AS SELECT * FROM read_csv("
                f"{sqlquote(files[name])}, header=true, all_varchar=true)"
            )
        if con.execute(
            "SELECT count(*) > count(DISTINCT patientunitstayid) FROM src_patient"
        ).fetchone()[0]:
            raise ValueError(
                "Unit stay identifiers must be unique in the patient table"
            )
        con.execute((HERE / "eicu_orders.sql").read_text(encoding="utf-8"))
        totals = con.execute("""
          SELECT count(*) AS transfers, count(*) FILTER (WHERE known_order24) AS identifiable,
                 count(*) FILTER (WHERE broad24) AS broad,
                 count(*) FILTER (WHERE broad_past_exit AND known_order24) AS after_exit,
                 count(*) FILTER (WHERE mrsa24 AND gn24) AS both_classes,
                 count(*) FILTER (WHERE broad24 AND NOT broad24_named) AS hicl_only
          FROM final
        """).fetchone()
        clusters = con.execute("""
          SELECT count(*) FILTER (WHERE broad_past_exit AND known_order24),
                 count(*) FILTER (WHERE known_order24)
          FROM final GROUP BY hospital ORDER BY hospital
        """).fetchall()
    transfers, identifiable, broad, after, both, hicl_only = totals
    if transfers == 0:
        raise ValueError("No qualifying floor transfer")
    if after >= 11 and sum(n > 0 for _, n in clusters) >= 11:
        path = work / "hospital_counts.csv"
        with path.open("w", newline="", encoding="utf-8") as handle:
            csv.writer(handle).writerows(clusters)
        result = subprocess.run(
            ["Rscript", "--vanilla", str(HERE / "hospital_interval.R"), str(path)],
            check=True,
            capture_output=True,
            text=True,
        )
        lower, upper = map(float, result.stdout.strip().split(","))
    else:
        lower = upper = None
    with (out / "eicu_orders.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "measure",
                "numerator",
                "denominator",
                "percent",
                "lower95",
                "upper95",
                "interval",
            ]
        )
        for label, cases, eligible, method in [
            ("First ICU-to-floor transfers", transfers, transfers, "cohort"),
            (
                "Order extending beyond exit among identifiable orders",
                after,
                identifiable,
                "hospital bootstrap",
            ),
            (
                "Order extending beyond exit among prior broad orders",
                after,
                broad,
                "Wilson",
            ),
            ("Both broad drug groups in final ICU day", both, broad, "Wilson"),
            (
                "HICL code required to identify broad treatment",
                hicl_only,
                broad,
                "Wilson",
            ),
        ]:
            percent = lo = hi = ""
            if eligible >= 11 and cases >= 11 and method != "cohort":
                p, l, u = rate(cases, eligible)
                percent = round(100 * p, 3)
                limits = (
                    (lower, upper)
                    if method == "hospital bootstrap"
                    else (100 * l, 100 * u)
                )
                lo, hi = [round(v, 3) if v is not None else "" for v in limits]
            writer.writerow(
                [
                    label,
                    cases if cases >= 11 else "<11",
                    eligible if eligible >= 11 else "<11",
                    percent,
                    lo,
                    hi,
                    method,
                ]
            )
