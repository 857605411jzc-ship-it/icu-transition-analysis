-- Raw eICU table views have VARCHAR columns. All offsets use minutes from this unit stay's admission.
create temp table floor_exits as
select patientunitstayid as stay, patienthealthsystemstayid as admission, hospitalid as hospital,
       try_cast(unitdischargeoffset as integer) as t0
from patient
where try_cast(replace(age,'>','') as double)>=18
  and lower(trim(unitdischargelocation))='floor'
  and lower(trim(unitdischargestatus))='alive'
  and try_cast(unitdischargeoffset as integer)>0
  and try_cast(hospitaldischargeoffset as integer)>=try_cast(unitdischargeoffset as integer)
  and try_cast(hospitaladmitoffset as integer) is not null
  and nullif(trim(patienthealthsystemstayid),'') is not null and hospitalid is not null
qualify row_number() over(partition by patienthealthsystemstayid
  order by try_cast(unitdischargeoffset as integer)-try_cast(hospitaladmitoffset as integer),patientunitstayid)=1;

create temp table lex as
select drugname,selected_agent(drugname) as ingredient from (select distinct drugname from medication where drugname is not null);
-- Recover only a uniquely mapped, actually named ingredient for a positive HICL.
-- If another nonempty concrete drug name maps elsewhere or is unrecognized, omit that HICL.
create temp table hicl as
select drughiclseqno, min(ingredient) as ingredient
from medication join lex using(drugname)
where try_cast(drughiclseqno as integer)>0 and nullif(trim(drugname),'') is not null
 and lower(trim(drugname)) not in ('other','unknown','not specified','drug name not found')
group by drughiclseqno having count(distinct ingredient)=1 and count(ingredient)=count(*);

create temp table ord as
select p.stay,p.t0,coalesce(l.ingredient,h.ingredient) as agent,
 try_cast(m.drugstartoffset as integer) as st,try_cast(m.drugstopoffset as integer) as en,
 lower(coalesce(m.routeadmin,'')) as route, lower(coalesce(m.drugname,'')) as name
from floor_exits p join medication m on p.stay=m.patientunitstayid
left join lex l using(drugname) left join hicl h on h.drughiclseqno=m.drughiclseqno
where lower(trim(coalesce(m.drugordercancelled,''))) not in ('yes','y','true','1')
and try_cast(m.drugorderoffset as int)<=p.t0 and try_cast(m.drugstartoffset as int)<=p.t0;
create temp table rx as select o.*,b.broad from ord o join ingredients b using(agent)
where o.en>=o.st and o.st<=o.t0 and o.en>=greatest(0,o.t0-1440)
and not regexp_matches(route||' '||name,'ophth|otic|topical|inhal|nebul|irrigat|intravit|intrathecal|ointment| cream| otic|ophth| lock')
and (regexp_matches(route,'intraven|^iv|^i\\.v|^po$|oral|intramusc|^im$|enteral|^ng|^og|tube|per os|mouth|^piggyback') or regexp_matches(name,'intraven|ivpb|iv piggyback| injection'))
and not (agent='vancomycin' and regexp_matches(route||' '||name,'oral|enteral|mouth|^po|^ng|^og|tube|capsule'));

create temp table micro as
select p.stay,p.hospital,p.t0, try_cast(m.culturetakenoffset as int) as taken,
 lower(trim(m.organism)) as org, lower(trim(m.culturesite)) as site,
 selected_agent(m.antibiotic) as ast_agent, upper(trim(m.sensitivitylevel)) as sir
from floor_exits p join microlab m on m.patientunitstayid=p.stay
where try_cast(m.culturetakenoffset as int) between greatest(0,p.t0-2880) and p.t0;
create temp table cultures as
select stay,
 count(*) filter(where regexp_matches(org,'^(no growth|negative|no organisms? (isolated|recovered))([ .]|$)')) as ng,
 count(*) filter(where org is null or not regexp_matches(org,'^(no growth|negative|no organisms? (isolated|recovered))([ .]|$)')) as other
from micro group by stay;
create temp table exposures as
select p.stay,p.hospital,
  exists(select 1 from rx x where x.stay=p.stay and x.broad=1) as broad_last_day,
  exists(select 1 from rx x where x.stay=p.stay and x.broad=1 and x.en>x.t0) as broad_crosses,
  exists(select 1 from rx x where x.stay=p.stay and x.st<=x.t0 and x.en>x.t0) as active_any,
  exists(select 1 from micro m where m.stay=p.stay and ast_agent is not null and sir in ('S','SENSITIVE','SUSCEPTIBLE')) as direct_s,
  exists(select 1 from micro m join rx x on x.stay=m.stay and x.agent=m.ast_agent
         where m.stay=p.stay and x.en>x.t0 and m.sir in ('S','SENSITIVE','SUSCEPTIBLE')) as direct_s_order,
  coalesce(c.ng>0 and c.other=0,false) as all_recorded_ng,
  c.stay is not null as micro_recorded
from floor_exits p left join cultures c using(stay);
