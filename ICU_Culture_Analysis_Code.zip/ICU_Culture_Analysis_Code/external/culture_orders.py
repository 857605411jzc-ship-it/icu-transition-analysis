"""Microbiology availability in eICU and medication records in Zigong."""

from pathlib import Path
import math
import random
import re
import duckdb

HERE = Path(__file__).resolve().parent
INGREDIENTS = [
    ("vancomycin", 1, "vancomycin|vancocin|万古霉素"),
    ("linezolid", 1, "linezolid|zyvox|利奈唑胺"),
    (
        "piperacillin_tazobactam",
        1,
        "piperacillin.*tazobactam|tazobactam.*piperacillin|zosyn|哌拉西林.*他唑巴坦",
    ),
    ("cefepime", 1, "cefepime|maxipime|头孢吡肟"),
    ("ceftazidime", 1, "ceftazidime|fortaz|头孢他啶"),
    ("meropenem", 1, "meropenem|merrem|美罗培南"),
    ("imipenem", 1, "imipenem|primaxin|亚胺培南"),
    ("doripenem", 1, "doripenem|doribax|多利培南"),
    ("ertapenem", 1, "ertapenem|invanz|厄他培南"),
    ("daptomycin", 0, "daptomycin|cubicin|达托霉素"),
    ("cefazolin", 0, "cefazolin|ancef|头孢唑林"),
    ("ceftriaxone", 0, "ceftriaxone|rocephin|头孢曲松"),
    ("cefotaxime", 0, "cefotaxime|claforan|头孢噻肟"),
    ("ciprofloxacin", 0, "ciprofloxacin|cipro |环丙沙星"),
    ("levofloxacin", 0, "levofloxacin|levaquin|左氧氟沙星"),
    ("moxifloxacin", 0, "moxifloxacin|avelox|莫西沙星"),
    ("aztreonam", 0, "aztreonam|azactam|氨曲南"),
    ("gentamicin", 0, "gentamicin|garamycin|庆大霉素"),
    ("amikacin", 0, "amikacin|amikin|阿米卡星"),
    ("tobramycin", 0, "tobramycin|nebci?n|妥布霉素"),
    ("ampicillin_sulbactam", 0, "ampicillin.*sulbactam|unasyn|氨苄西林.*舒巴坦"),
    ("ampicillin", 0, "ampicillin|氨苄西林"),
    (
        "amoxicillin_clavulanate",
        0,
        "amoxicillin.*clavulan|augmentin|阿莫西林.*克拉维酸",
    ),
    ("amoxicillin", 0, "amoxicillin|阿莫西林"),
    ("nafcillin", 0, "nafcillin|萘夫西林"),
    ("oxacillin", 0, "oxacillin|苯唑西林"),
    ("clindamycin", 0, "clindamycin|cleocin|克林霉素"),
    ("doxycycline", 0, "doxycycline|多西环素"),
    (
        "trimethoprim_sulfamethoxazole",
        0,
        "trimethoprim.*sulfa|sulfa.*trimethoprim|bactrim|septra|复方磺胺甲噁唑",
    ),
]
PATTERNS = [(drug, re.compile(pattern, re.I)) for drug, _, pattern in INGREDIENTS]


def ingredient(name):
    if not name:
        return None
    # Keep combination products distinct from their constituent monotherapies.
    if re.search(
        r"ceftazidime.*avibactam|ceftolozane|meropenem.*vaborbactam|imipenem.*relebactam|头孢他啶.*阿维|美罗培南.*韦博|亚胺培南.*瑞来",
        name,
        re.I,
    ):
        return None
    return next((drug for drug, pat in PATTERNS if pat.search(name)), None)


def sqlquote(v):
    return "'" + str(v).replace("'", "''") + "'"


def rate(k, n):
    if not n:
        return None
    p = k / n
    z = 1.959963984540054
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    rad = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return p, max(0, c - rad), min(1, c + rad)


def bootstrap(rows):
    rng = random.Random(389104)
    vals = []
    for rep in range(1000):
        sample = rng.choices(rows, k=len(rows))
        n = sum(b for _, b in sample)
        if n:
            vals.append(100 * sum(a for a, _ in sample) / n)
    return (quantile(vals, 0.025), quantile(vals, 0.975))


def quantile(vals, p):
    vals = sorted(vals)
    i = (len(vals) - 1) * p
    return vals[math.floor(i)] * (1 - i % 1) + vals[math.ceil(i)] * (i % 1)


FIELDS = (
    "database",
    "measure",
    "unit",
    "events",
    "eligible",
    "percent",
    "lo95",
    "hi95",
    "interval",
    "contributing_hospitals",
)


def summary(db, label, unit, groups, cluster):
    k = sum(a for a, b in groups)
    n = sum(b for a, b in groups)
    suppressed = n == 0 or n < 11 or (0 < k < 11) or (0 < n - k < 11)
    base = [db, label, unit]
    hospitals = len(groups) if db == "eICU" else 1

    def safe(x):
        return "<11" if 0 < x < 11 else x

    if suppressed:
        # A rare complement cannot be reconstructed by subtracting a public numerator.
        num = "masked" if 0 < n - k < 11 and k >= 11 else safe(k)
        return base + [
            num,
            safe(n),
            "",
            "",
            "",
            "not estimated" if not n else "small cell",
            safe(hospitals),
        ]
    p, lo, hi = rate(k, n)
    method = "Wilson 95%"
    lo, hi = 100 * lo, 100 * hi
    if cluster and hospitals >= 2:
        lo, hi = bootstrap(groups)
        method = "hospital cluster percentile bootstrap; 1000"
    return base + [
        k,
        n,
        round(100 * p, 3),
        round(lo, 3),
        round(hi, 3),
        method,
        safe(hospitals),
    ]


def run_source(db, files, tmp):
    con = duckdb.connect(str(Path(tmp) / (db + ".duckdb")))
    metrics = []
    try:
        con.execute("set threads=2")
        con.execute("set memory_limit='2GB'")
        con.execute("set temp_directory=" + sqlquote(Path(tmp) / "spill"))
        con.create_function(
            "selected_agent",
            ingredient,
            ["VARCHAR"],
            "VARCHAR",
            null_handling="special",
        )
        con.execute("create temp table ingredients(agent varchar,broad integer)")
        con.executemany(
            "insert into ingredients values (?,?)",
            [(drug, broad) for drug, broad, _ in INGREDIENTS],
        )
        for key, file in files.items():
            con.execute(
                f"create view {key} as select * from read_csv({sqlquote(file)}, header=true,all_varchar=true, sample_size=20480, nullstr=['','NA'])"
            )
        con.execute(
            (
                HERE
                / (
                    db + "_microbiology.sql"
                    if db == "eicu"
                    else "zigong_prescribing.sql"
                )
            ).read_text(encoding="utf-8")
        )

        def metric(source, label, den, num, unit):
            key = "hospital" if db == "eicu" else "'Zigong'"
            grouped = con.execute(
                f"select {key},sum(case when {num} then 1 else 0 end),count(*) from {source} where {den} group by 1 order by 1"
            ).fetchall()
            metrics.append(
                summary(
                    "eICU" if db == "eicu" else "Zigong",
                    label,
                    unit,
                    [(x[1], x[2]) for x in grouped],
                    db == "eicu",
                )
            )

        if db == "eicu":
            unit = "first qualifying adult ICU-to-floor transition per admission"
            metric(
                "exposures",
                "culture collection recorded in final 48 ICU hours",
                "true",
                "micro_recorded",
                unit,
            )
            metric(
                "exposures",
                "all recorded cultures in final 48 ICU hours eventually reported no growth",
                "micro_recorded",
                "all_recorded_ng",
                unit,
            )
            metric(
                "exposures",
                "broad order crosses ICU exit among recent broad users with all recorded cultures no growth",
                "all_recorded_ng and broad_last_day",
                "broad_crosses",
                unit,
            )
            metric(
                "exposures",
                "at least one active selected order matches a susceptible tested ingredient at exit",
                "direct_s and active_any",
                "direct_s_order",
                unit,
            )
            metric(
                "exposures",
                "at least one active selected order at exit among transfers with an interpretable susceptible agent",
                "direct_s",
                "active_any",
                unit,
            )
            if "infusiondrug" in files:
                con.execute("""create temp table inflex as select drugname,selected_agent(drugname) as agent from (select distinct drugname from infusiondrug);
                 create temp table inf as select p.stay,p.hospital,p.t0,
                   bool_or(try_cast(i.infusionoffset as integer) between greatest(0,p.t0-1440) and p.t0) as any_chart,
                   bool_or(try_cast(i.infusionoffset as integer) between greatest(0,p.t0-1440) and p.t0
                   and a.broad=1 and (try_cast(i.drugrate as double)>0 or try_cast(i.infusionrate as double)>0)) as broad_rate
                 from floor_exits p join infusiondrug i on i.patientunitstayid=p.stay
                 left join inflex l on l.drugname=i.drugname left join ingredients a on a.agent=l.agent
                 group by p.stay,p.hospital,p.t0""")
                metric(
                    "inf joined_i join exposures e using(stay,hospital)",
                    "positive-rate broad infusion documented in final ICU day among eventual no-growth transfers with any infusion chart",
                    "any_chart and all_recorded_ng",
                    "broad_rate",
                    unit,
                )
        else:
            unit = "first adult ICU-to-specialty transfer, hospital stay extends beyond 48h"
            metric(
                "zfull",
                "48h destination has an unambiguous first-versus-other group",
                "true",
                "in_first <> in_other",
                unit,
            )
            metric(
                "zfull",
                "outside first specialty at 48h among evaluable destinations",
                "in_first <> in_other",
                "in_other",
                unit,
            )
            metric(
                "zfull",
                "in an ICU at 48h among evaluable transfers outside the first specialty",
                "in_other and not in_first",
                "in_icu",
                unit,
            )
            metric(
                "zfull",
                "repeat named broad prescription in next 48h, conditional on any prescription being visible",
                "prior_broad and next_any",
                "next_broad",
                unit,
            )
            metric(
                "zfull",
                "any subsequent prescription visible among pretransfer broad-prescription recipients",
                "prior_broad",
                "next_any",
                unit,
            )
            metric(
                "zfull",
                "repeat named broad prescription, outside first department at 48h",
                "prior_broad and next_any and in_other and not in_first",
                "next_broad",
                unit,
            )
            metric(
                "zfull",
                "repeat named broad prescription, in first department at 48h",
                "prior_broad and next_any and in_first and not in_other",
                "next_broad",
                unit,
            )
        return metrics
    finally:
        con.close()
