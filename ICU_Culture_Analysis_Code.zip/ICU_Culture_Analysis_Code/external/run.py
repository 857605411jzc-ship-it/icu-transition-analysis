"""Calculate cohort-specific antibiotic and location outcomes from one external release."""

import argparse
import csv
import tempfile
from pathlib import Path

import culture_orders
import eicu_orders
import inspire
from local_tables import stage_tables
from movement_orders import index_nw, nw_orders, zigong


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--cohort", choices=["eicu", "nwicu", "inspire", "zigong"], required=True
    )
    parser.add_argument(
        "--source", type=Path, required=True, help="One local release folder or archive"
    )
    parser.add_argument(
        "--output", type=Path, required=True, help="New directory for aggregate results"
    )
    args = parser.parse_args()
    source, out = args.source.resolve(), args.output.resolve()
    if source.is_dir() and (out == source or source in out.parents):
        raise ValueError("Specify an output directory outside the source release")
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        raise FileExistsError(f"Output directory already exists: {out}")
    with tempfile.TemporaryDirectory(prefix="icu_cohort_", dir=out.parent) as temporary:
        work = Path(temporary)
        files = stage_tables(source, args.cohort, work / "tables")
        results = work / "results"
        results.mkdir()
        if args.cohort == "nwicu":
            cohort = index_nw(files)
            if not cohort:
                raise ValueError("No eligible NWICU exit")
            nw_orders(files, cohort).write(results / "nwicu_orders.csv")
        if args.cohort == "inspire":
            cohort, flow = inspire.cohort(files["operations"])
            if not cohort:
                raise ValueError("No eligible postoperative ICU exit")
            inspire.read_med(files["medications"], cohort)
            inspire.write_clinical(results, inspire.measures(cohort, flow), flow)
        if args.cohort == "zigong":
            zigong(files).write(results / "zigong_movement.csv")
        if args.cohort == "eicu":
            eicu_orders.analyze(files, work, results)
        if args.cohort in ("eicu", "zigong"):
            measures = culture_orders.run_source(args.cohort, files, work)
            filename = (
                "eicu_recent_cultures"
                if args.cohort == "eicu"
                else "zigong_prescribing"
            )
            with (results / (filename + ".csv")).open(
                "w", encoding="utf-8", newline=""
            ) as handle:
                writer = csv.writer(handle)
                writer.writerow(culture_orders.FIELDS)
                writer.writerows(measures)
        results.rename(out)


if __name__ == "__main__":
    main()
