"""Read the selected external data release in a local working directory."""

import codecs
from contextlib import contextmanager
import csv
import gzip
import io
import re
import shutil
import tarfile
import zipfile

TABLES = {
    "eicu": {"patient", "medication", "microlab", "infusiondrug"},
    "nwicu": {"admissions", "icustays", "prescriptions"},
    "inspire": {"operations", "medications"},
    "zigong": {"dtbaseline", "dttransfer", "dtdrugs"},
}
ARCHIVES = (".zip", ".tar", ".tgz", ".tar.gz", ".tar.bz2", ".tar.xz")


def table_name(name, cohort):
    leaf = re.split(r"[/\\]", name)[-1].lower()
    match = re.fullmatch(r"(.+)\.(csv|tsv|txt)(?:\.gz)?", leaf)
    if not match or leaf.startswith("._"):
        return None
    stem = match.group(1)
    if cohort == "nwicu":
        stem = re.sub(
            r"^(?:(?:nwicu|nw|northwestern_icu|northwestern)[_])?(?:(?:icu|hosp)[_])?",
            "",
            stem,
        )
    return stem if stem in TABLES[cohort] else None


def archive_members(path):
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            for item in z.infolist():
                if not item.is_dir():
                    yield item.filename, lambda: z.open(item)
    elif tarfile.is_tarfile(path):
        with tarfile.open(path) as t:
            for item in t:
                if item.isfile():
                    yield item.name, lambda: t.extractfile(item)
    else:
        raise ValueError(f"Extract this archive locally before use: {path.name}")


def stage_tables(source, cohort, work):
    work.mkdir()
    files = {}
    counter = 0

    def collect(name, opener=None, loose=None, depth=0):
        nonlocal counter
        if "__macosx" in name.lower() or any(
            p.startswith("._") for p in re.split(r"[/\\]", name)
        ):
            return
        key = table_name(name, cohort)
        is_archive = name.lower().endswith(ARCHIVES)
        if key is None and not is_archive:
            return
        if depth > 8:
            raise ValueError("Select an inner release archive")
        path = loose
        if path is None:
            counter += 1
            suffix = (
                ".csv.gz"
                if key and name.lower().endswith(".gz")
                else (".csv" if key else ".archive")
            )
            path = work / (str(counter) + suffix)
            with opener() as src, path.open("wb") as target:
                shutil.copyfileobj(src, target, length=1024 * 1024)
        if key:
            if key in files:
                raise ValueError(
                    f"Multiple {key} tables found. Select one release directory or archive."
                )
            files[key] = path
        else:
            for member, opened in archive_members(path):
                collect(member, opened, depth=depth + 1)

    if source.is_dir():
        for path in sorted(source.rglob("*")):
            if path.is_file():
                collect(path.relative_to(source).as_posix(), loose=path)
    elif source.is_file():
        collect(source.name, loose=source)
    else:
        raise FileNotFoundError(source)
    missing = TABLES[cohort] - files.keys() - {"infusiondrug"}
    if missing:
        raise ValueError(
            "Missing table(s) in this release: " + ", ".join(sorted(missing))
        )
    if cohort == "zigong":
        for key, path in list(files.items()):
            files[key] = transcode(path, work / f"{key}.csv")
    return files


def binary_stream(path):
    with path.open("rb") as handle:
        gz = handle.read(2) == b"\x1f\x8b"
    return gzip.open(path, "rb") if gz else path.open("rb")


def transcode(path, dest):
    with binary_stream(path) as handle:
        header = handle.read(4)
    encodings = (
        ("utf-16",)
        if header[:2] in (b"\xff\xfe", b"\xfe\xff")
        else ("utf-8-sig", "gb18030")
    )
    for encoding in encodings:
        try:
            with binary_stream(path) as handle, dest.open("wb") as out:
                decode = codecs.getincrementaldecoder(encoding)()
                for block in iter(lambda: handle.read(1024 * 1024), b""):
                    out.write(decode.decode(block).encode())
                out.write(decode.decode(b"", final=True).encode())
            return dest
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Cannot decode {path.name}")


@contextmanager
def rows(path, required):
    csv.field_size_limit(32 * 1024 * 1024)
    with (
        binary_stream(path) as handle,
        io.TextIOWrapper(handle, encoding="utf-8-sig", newline="") as source,
    ):
        line = source.readline()
        delimiter = "\t" if line.count("\t") > line.count(",") else ","
        names = [
            re.sub(r"[^\w]+", "_", field.strip().casefold()).strip("_")
            for field in next(csv.reader([line], delimiter=delimiter))
        ]
        missing = set(required) - set(names)
        if missing or len(set(names)) != len(names):
            raise ValueError(
                f"Missing or duplicated columns in {path.name}: {', '.join(sorted(missing))}"
            )
        yield csv.DictReader(source, fieldnames=names, delimiter=delimiter)


def read_rows(files, table, required):
    with rows(files[table], required) as reader:
        for row in reader:
            yield {
                key: (value or "").strip()
                for key, value in row.items()
                if key is not None
            }
