# External cohort analyses

Run the following commands from the project root. Supply one authorized local release per command. The output directory must be new and outside the source directory.

```sh
python external/run.py --cohort eicu --source DATA/eicu --output RESULTS/eicu
python external/run.py --cohort nwicu --source DATA/nwicu --output RESULTS/nwicu
python external/run.py --cohort inspire --source DATA/inspire --output RESULTS/inspire
python external/run.py --cohort zigong --source DATA/zigong --output RESULTS/zigong
```

| Release | Tables | Output and denominator |
| --- | --- | --- |
| eICU-CRD 2.0 | patient, medication, microLab, optional infusionDrug | `eicu_orders.csv` reports broad orders with a stop time after ICU exit among patients with identifiable orders in the final ICU day and among prior broad users. `eicu_recent_cultures.csv` uses a separate first-floor-exit cohort with a documented hospital-admission offset to assess culture collection and eventual findings. |
| NWICU 0.1.0 | admissions, icustays, prescriptions | `nwicu_orders.csv` compares active IV orders at exit and at 48 hours among patients with evaluable order records who remain hospitalized outside a subsequent ICU episode. |
| INSPIRE 1.4.2 | operations, medications | `INSPIRE_flow.csv` and `INSPIRE_antibiotic_continuation.csv` give the postoperative cohort and administered broad drugs in hours 24–48, including the repeated-baseline-dose analysis. |
| Zigong infection ICU 1.1 | dtBaseline, dtTransfer, dtDrugs | `zigong_movement.csv` counts any departure from the first specialty during continuous follow-up, including a departure followed by a return. `zigong_prescribing.csv` separately examines location at hour 48 and repeat broad prescriptions in patients with a unique admission link. |

CSV and CSV.GZ tables can be supplied in a single-release folder, ZIP or TAR archive, including nested ZIPs. Extract 7z or RAR files locally first. The reader also accepts tab-delimited text and converts Zigong UTF-16 or GB18030 files locally. Intermediate tables are kept in a temporary directory beside the requested output.

The overall eICU order estimate uses 1,000 hospital bootstrap samples in base R. Its conditional treated-subgroup estimate and the NWICU, INSPIRE and Zigong rates use Wilson intervals. The supplementary eICU microbiology analysis separately resamples hospitals in Python. It sorts hospitals before drawing the samples so runs with different database thread schedules give the same interval. Earlier unordered bootstrap calculations can differ slightly at the interval endpoints. Cohort definitions and event counts do not depend on the resampling order.
