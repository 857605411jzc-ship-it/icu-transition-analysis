# Percentile interval from sampling eICU hospitals with replacement.
args <- commandArgs(trailingOnly = TRUE)
counts <- utils::read.csv(args[[1L]], header = FALSE, col.names = c("events", "eligible"))
n <- nrow(counts)
set.seed(41367L)
weights <- stats::rmultinom(1000L, n, rep(1, n))
p <- as.numeric(crossprod(counts$events, weights)) / as.numeric(crossprod(counts$eligible, weights))
ci <- 100 * stats::quantile(p[is.finite(p)], c(0.025, 0.975), names = FALSE)
cat(paste(sprintf("%.12f", ci), collapse = ","))
