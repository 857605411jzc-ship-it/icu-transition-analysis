CREATE TEMP TABLE loc AS
SELECT subject_id::BIGINT AS pid, hadm_id::BIGINT AS hid, transfer_id::BIGINT AS tid,
       nullif(trim(careunit),'') AS unit, intime::TIMESTAMP AS began, outtime::TIMESTAMP AS ended,
       CASE WHEN trim(careunit) IN ('Medical Intensive Care Unit (MICU)','Surgical Intensive Care Unit (SICU)',
              'Medical/Surgical Intensive Care Unit (MICU/SICU)','Cardiac Vascular Intensive Care Unit (CVICU)',
              'Trauma SICU (TSICU)','Coronary Care Unit (CCU)','Neuro Surgical Intensive Care Unit (Neuro SICU)') THEN 'ICU'
            WHEN trim(careunit) IN ('Medicine','Neurology','Medicine/Cardiology','Hematology/Oncology','Cardiology') THEN 'Medical'
            WHEN trim(careunit) IN ('Cardiac Surgery','Vascular','Surgery/Trauma','Surgery','Orthopedics',
              'Neurosurgery','General Surgery') THEN 'Surgical'
            WHEN trim(careunit) IN ('Med/Surg','Transplant','Med/Surg/Trauma','Med/Surg/GYN') THEN 'Mixed or specialty'
            ELSE 'Other' END AS unit_category
FROM src_transfers;

CREATE TEMP TABLE pat AS
SELECT subject_id::BIGINT AS pid, anchor_age::INTEGER AS age, anchor_year::INTEGER AS yr,
       try_cast(regexp_extract(anchor_year_group,'([0-9]{4})[^0-9]+([0-9]{4})',1) AS INTEGER) AS anchor_lo,
       try_cast(regexp_extract(anchor_year_group,'([0-9]{4})[^0-9]+([0-9]{4})',2) AS INTEGER) AS anchor_hi
FROM src_patients;

CREATE TEMP TABLE stays AS
SELECT s.subject_id::BIGINT AS pid,s.hadm_id::BIGINT AS hid,s.stay_id::BIGINT AS sid,
       s.intime::TIMESTAMP AS icu_in,s.outtime::TIMESTAMP AS tm,
       a.dischtime::TIMESTAMP AS discharge_at,a.deathtime::TIMESTAMP AS died_at,
       p.age + year(s.outtime::TIMESTAMP) - p.yr AS age_at_exit,
       p.anchor_lo + year(s.outtime::TIMESTAMP) - p.yr AS era_lower,
       p.anchor_hi + year(s.outtime::TIMESTAMP) - p.yr AS era_upper
FROM src_icustays s JOIN pat p ON p.pid=s.subject_id::BIGINT
JOIN src_admissions a ON p.pid=a.subject_id::BIGINT AND a.hadm_id::BIGINT=s.hadm_id::BIGINT;

CREATE TEMP TABLE adult_stays AS
SELECT * FROM stays WHERE age_at_exit>=18 AND tm>icu_in;

CREATE TEMP TABLE endpoints AS
SELECT s.*, t.outgoing_n,t.icu_exit_n,t.outgoing_unit,r.incoming_n,r.ward_n,r.receiving_unit,r.ward_end,
       r.ward_group, EXISTS (SELECT 1 FROM loc l WHERE l.pid=s.pid AND l.hid=s.hid AND l.began<s.tm AND l.ended>s.tm) AS crossing_location
FROM adult_stays s
LEFT JOIN (
  SELECT pid,hid,ended,count(*) AS outgoing_n,count(*) FILTER (WHERE unit_category='ICU') AS icu_exit_n,min(unit) AS outgoing_unit
  FROM loc WHERE ended>began GROUP BY pid,hid,ended
) t ON t.pid=s.pid AND t.hid=s.hid AND t.ended=s.tm
LEFT JOIN (
  SELECT pid,hid,began,count(*) AS incoming_n,count(*) FILTER(WHERE unit_category IN ('Medical','Surgical','Mixed or specialty')) AS ward_n,
         min(unit) AS receiving_unit,min(ended) AS ward_end,min(unit_category) AS ward_group
  FROM loc WHERE ended>began GROUP BY pid,hid,began
) r ON r.pid=s.pid AND r.hid=s.hid AND r.began=s.tm;

CREATE TEMP TABLE transfers_direct AS
SELECT *,least(discharge_at,coalesce(died_at,discharge_at)) AS hospital_end
FROM endpoints WHERE outgoing_n=1 AND icu_exit_n=1 AND incoming_n=1 AND ward_n=1 AND NOT crossing_location
  AND discharge_at>tm AND (died_at IS NULL OR died_at>tm);

CREATE TEMP TABLE cohort AS
SELECT * FROM transfers_direct
QUALIFY row_number() OVER (PARTITION BY pid ORDER BY tm,hid,sid)=1;

CREATE TEMP TABLE icu_intervals AS
SELECT DISTINCT c.pid,c.hid,greatest(c.icu_in,l.began) AS began,least(c.tm,l.ended) AS ended
FROM cohort c JOIN loc l ON l.pid=c.pid AND l.hid=c.hid AND l.unit_category='ICU'
WHERE l.began<c.tm AND l.ended>c.icu_in AND l.ended>l.began;

