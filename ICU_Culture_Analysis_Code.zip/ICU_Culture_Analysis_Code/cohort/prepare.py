"""Prepare patient-partitioned MIMIC-IV inputs for ICU-to-ward culture analysis."""

import argparse
import csv
import gzip
from pathlib import Path
from tempfile import TemporaryDirectory

import duckdb

TABLE_COLUMNS = {
    "patients": "subject_id anchor_age anchor_year anchor_year_group",
    "admissions": "subject_id hadm_id dischtime deathtime",
    "icustays": "subject_id hadm_id stay_id intime outtime",
    "transfers": "subject_id hadm_id transfer_id careunit intime outtime",
    "microbiologyevents": (
        "subject_id hadm_id micro_specimen_id charttime chartdate storetime "
        "storedate test_name spec_type_desc org_itemid org_name isolate_num "
        "ab_name interpretation comments"
    ),
    "emar": "subject_id hadm_id emar_id pharmacy_id medication event_txt charttime storetime",
    "prescriptions": "subject_id hadm_id pharmacy_id drug route starttime stoptime drug_type",
    "pharmacy": "subject_id hadm_id pharmacy_id medication route starttime stoptime entertime",
    "emar_detail": "subject_id emar_id route complete_dose_not_given dose_given product_amount_given",
}
PARTITIONS = 32
SUFFIXES = (".csv.gz", ".csv", ".parquet")


def quoted(value):
    return "'" + str(value).replace("'", "''") + "'"


def locate(root, table):
    section = "icu" if table == "icustays" else "hosp"
    candidates = [root / section / (table + ext) for ext in SUFFIXES]
    matches = [p for p in candidates if p.is_file()]
    if len(matches) != 1:
        raise FileNotFoundError(
            f"Expected one {section}/{table} table (.csv.gz, .csv or .parquet) under {root}, found {len(matches)}"
        )
    return matches[0]


def bind_file(con, path, table, columns):
    if path.suffix.lower() == ".parquet":
        relation = f"read_parquet({quoted(path)})"
    else:
        opener = gzip.open if path.suffix.lower() == ".gz" else open
        with opener(path, "rt", encoding="utf-8-sig", newline="") as stream:
            fields = next(csv.reader(stream))
        if len(set(fields)) != len(fields):
            raise ValueError(f"Duplicate columns in {table}")
        schema = ", ".join(f"{quoted(c)}: 'VARCHAR'" for c in fields)
        relation = (
            f"read_csv({quoted(path)}, columns={{{schema}}}, header=true, "
            "auto_detect=false, delim=',', quote='\"', escape='\"', parallel=false)"
        )
    available = {
        row[0].lower() for row in con.execute(f"DESCRIBE SELECT * FROM {relation}").fetchall()
    }
    absent = set(columns) - available
    if absent:
        raise ValueError(f"{table} lacks required columns: {', '.join(sorted(absent))}")
    projection = ", ".join(f'CAST("{c}" AS VARCHAR) AS "{c}"' for c in columns)
    con.execute(f"CREATE TEMP VIEW src_{table} AS SELECT {projection} FROM {relation}")


SELECTION = {
    "microbiologyevents": """
        SELECT r.* FROM src_microbiologyevents r JOIN cohort c
          ON c.pid=try_cast(r.subject_id AS BIGINT)
        WHERE c.hid=try_cast(r.hadm_id AS BIGINT)
           OR try_cast(r.charttime AS TIMESTAMP) BETWEEN c.icu_in AND c.tm""",
    "emar": """
        SELECT r.* FROM src_emar r JOIN cohort c
          ON c.pid=try_cast(r.subject_id AS BIGINT) AND c.hid=try_cast(r.hadm_id AS BIGINT)
        WHERE try_cast(r.charttime AS TIMESTAMP) BETWEEN
              greatest(c.icu_in-INTERVAL '1 DAY', c.tm-INTERVAL '72 hours') AND
              least(c.hospital_end, c.tm+INTERVAL '72 hours')""",
    "prescriptions": """
        SELECT r.* FROM src_prescriptions r JOIN cohort c
          ON c.pid=try_cast(r.subject_id AS BIGINT) AND c.hid=try_cast(r.hadm_id AS BIGINT)
        WHERE upper(trim(coalesce(r.drug_type,'')))<>'BASE'
          AND try_cast(r.starttime AS TIMESTAMP)<c.hospital_end""",
    "pharmacy": """
        SELECT r.* FROM src_pharmacy r SEMI JOIN cohort c
          ON c.pid=try_cast(r.subject_id AS BIGINT) AND c.hid=try_cast(r.hadm_id AS BIGINT)""",
    "emar_detail": """
        SELECT r.* FROM src_emar_detail r JOIN selected_emar_range e
          ON e.pid=try_cast(r.subject_id AS BIGINT)
        WHERE (e.unparsed AND dose_number(r.emar_id) IS NULL)
           OR dose_number(r.emar_id) BETWEEN e.low_id AND e.high_id""",
}


def write_partitions(con, directory, sql, key):
    directory.mkdir(parents=True)
    con.execute(
        f"COPY (SELECT * FROM ({sql}) p LIMIT 0) TO {quoted(directory / 'schema.parquet')} (FORMAT parquet)"
    )
    con.execute(f"""
        COPY (SELECT *, CAST(hash({key}) % {PARTITIONS} AS INTEGER) AS part FROM ({sql}) p)
        TO {quoted(directory / 'blocks')}
        (FORMAT parquet, COMPRESSION snappy, PARTITION_BY(part), ROW_GROUP_SIZE 8192)
    """)


def prepare(root, output, threads, memory_limit):
    if output.exists():
        raise FileExistsError(f"The output directory already exists: {output}")
    if root == output or root in output.parents:
        raise ValueError("Keep derived files outside the source dataset.")
    output.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=output.parent, prefix="culture_partitions_") as temporary:
        work = Path(temporary)
        data = work / "result" / "inputs"
        config = {
            "threads": str(threads),
            "memory_limit": memory_limit,
            "temp_directory": str(work / "spill"),
        }
        with duckdb.connect(config=config) as con:
            con.execute("SET preserve_insertion_order=false")
            con.execute("SET partitioned_write_flush_threshold=8192")
            con.execute("SET partitioned_write_max_open_files=16")
            for table in TABLE_COLUMNS:
                bind_file(con, locate(root, table), table, TABLE_COLUMNS[table].split())
            sql = Path(__file__).with_name("cohort.sql").read_text(encoding="utf-8")
            con.execute(sql)
            if not con.execute("SELECT count(*) FROM cohort").fetchone()[0]:
                raise ValueError("No eligible adult ICU-to-ward transfer in the source files.")
            for table in ("cohort", "icu_intervals", "loc"):
                query = f"SELECT * FROM {table}"
                if table == "loc":
                    query = "SELECT l.* FROM loc l SEMI JOIN cohort c USING (pid,hid)"
                write_partitions(con, data / "index" / table, query, "pid")
            for table in (
                "icu_intervals",
                "transfers_direct",
                "endpoints",
                "adult_stays",
                "stays",
                "pat",
                "loc",
            ):
                con.execute(f"DROP TABLE {table}")
            for table, query in SELECTION.items():
                if table == "emar_detail":
                    directory = data / "emar" / "emar"
                    # Detail records use exact administration identifiers in the downstream joins.
                    # The numeric envelope reduces intermediate size without losing non-numeric IDs.
                    con.execute("""CREATE TEMP MACRO dose_number(x) AS
                                try_cast(regexp_extract(x,'([0-9]+)$',1) AS BIGINT)""")
                    files = list(sorted((directory / "blocks").glob("part=*/*.parquet")))
                    files = files or [directory / "schema.parquet"]
                    con.execute(
                        """
                        CREATE TEMP TABLE selected_emar_range AS
                        SELECT try_cast(subject_id AS BIGINT) AS pid,
                               min(dose_number(emar_id)) AS low_id,
                               max(dose_number(emar_id)) AS high_id,
                               bool_or(dose_number(emar_id) IS NULL AND emar_id IS NOT NULL) AS unparsed
                        FROM read_parquet(?, hive_partitioning=false) GROUP BY 1
                    """,
                        [[str(f) for f in files]],
                    )
                write_partitions(con, data / table / table, query, "try_cast(subject_id AS BIGINT)")
        (work / "result").rename(output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--mimic",
        required=True,
        type=Path,
        help="MIMIC-IV v3.1 release directory with hosp/ and icu/",
    )
    parser.add_argument(
        "--out", required=True, type=Path, help="New local directory for patient-level partitions"
    )
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--memory-limit", default="2GB", help="DuckDB memory limit")
    args = parser.parse_args()
    if args.threads < 1:
        parser.error("--threads must be positive")
    prepare(args.mimic.resolve(), args.out.resolve(), args.threads, args.memory_limit)


if __name__ == "__main__":
    main()
