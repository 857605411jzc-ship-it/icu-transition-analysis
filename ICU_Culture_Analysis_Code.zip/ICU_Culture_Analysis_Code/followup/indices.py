"""Link each transfer to its first treatment gap, alert and culture review opportunities."""

import argparse
import os
import re
import shutil
from pathlib import Path
from tempfile import TemporaryDirectory

import duckdb

HERE = Path(__file__).resolve().parent
PRIMARY = HERE.parent / "primary"
QUERIES = HERE / "queries"
ENGINE = PRIMARY / "engine"
INDEX = ("cohort", "icu_intervals", "loc")
CLINICAL = ("microbiologyevents", "emar", "prescriptions", "pharmacy", "emar_detail")
EXPORTS = {
    "p_transfer": ("SELECT * FROM followup_transfer", "pid"),
    "p_gaps": ("first_gap.sql", "pid"),
    "p_alert": ("alert.sql", "(pid,channel)"),
    "harm_index": ("harm_index.sql", "(pid,analysis)"),
    "note_index": ("note_index.sql", "pid"),
    "dot_index": ("dot_index.sql", "(scope,analysis,pid,location)"),
}


def sql_path(path):
    return "'" + path.resolve().as_posix().replace("'", "''") + "'"


def execute_file(con, path):
    con.execute(path.read_text(encoding="utf-8-sig"))


def bind_partition(con, partitions, part):
    for name in INDEX + CLINICAL:
        path = partitions / "inputs" / ("index" if name in INDEX else name) / name
        files = sorted((path / "blocks" / f"part={part}").glob("*.parquet"))
        if not files:
            files = [path / "schema.parquet"]
        names = ",".join(sql_path(f) for f in files)
        view = name if name in INDEX else "src_" + name
        con.execute(
            f"CREATE TEMP VIEW {view} AS SELECT * FROM read_parquet([{names}],hive_partitioning=false)"
        )


def materialize(con):
    execute_file(con, ENGINE / "label_keys.sql")
    statements = con.extract_statements(
        (ENGINE / "culture.sql").read_text(encoding="utf-8-sig")
    )
    for stmt in statements:
        con.execute(stmt)
        if re.search(
            r"\bCREATE\s+TEMP\s+TABLE\s+culture_culture_rows\s+AS\b", stmt.query, re.I
        ):
            execute_file(con, ENGINE / "performance.sql")
    for item in (
        "medications",
        "windows",
        "result_drugs",
        "live_trigger",
        "meds",
        "spectrum",
        "paired_targets",
        "metrics",
    ):
        execute_file(con, ENGINE / (item + ".sql"))
    execute_file(con, PRIMARY / "site" / "action.sql")
    execute_file(con, QUERIES / "transfer.sql")
    con.execute(
        "CREATE TEMP VIEW clinical_demographics AS SELECT pid, 'unknown' AS sex FROM cohort"
    )
    for item in ("preparation", "selection"):
        execute_file(con, PRIMARY / "order" / (item + ".sql"))
    execute_file(con, QUERIES / "harm_candidates.sql")
    for item in ("followup", "dot_index"):
        execute_file(con, PRIMARY / "order" / (item + ".sql"))


def build(partitions, destination):
    if any(destination.glob("*")):
        raise ValueError("Select a new directory for the patient-level indices")
    destination.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix="indices_", dir=destination.parent) as tmp:
        stage = Path(tmp)
        for part in range(32):
            with duckdb.connect(
                config={
                    "threads": "1",
                    "memory_limit": "1500MB",
                    "preserve_insertion_order": "false",
                    "temp_directory": str(stage / "spill"),
                }
            ) as con:
                bind_partition(con, partitions, part)
                if (
                    part
                    and not con.execute(
                        "SELECT EXISTS(SELECT 1 FROM cohort)"
                    ).fetchone()[0]
                ):
                    continue
                materialize(con)
                for name, (definition, key) in EXPORTS.items():
                    query = (
                        (QUERIES / definition).read_text(encoding="utf-8-sig")
                        if definition.endswith(".sql")
                        else definition
                    )
                    con.execute(
                        "CREATE TEMP VIEW export_rows AS " + query.rstrip().rstrip(";")
                    )
                    duplicates = con.execute(
                        f"SELECT count(*) - count(DISTINCT {key}) FROM export_rows"
                    ).fetchone()[0]
                    if duplicates:
                        raise ValueError(
                            f"Nonunique keys in {name} for partition {part}"
                        )
                    target = stage / f"{name}-{part:02d}.csv"
                    con.execute(
                        f"COPY export_rows TO {sql_path(target)} (FORMAT CSV, HEADER {'TRUE' if part==0 else 'FALSE'}, NULL '')"
                    )
                    con.execute("DROP VIEW export_rows")
            print(f"Linked partition {part+1} of 32", flush=True)
        for name in EXPORTS:
            with (stage / f"{name}.csv").open("wb") as out:
                for chunk in sorted(stage.glob(f"{name}-*.csv")):
                    with chunk.open("rb") as src:
                        shutil.copyfileobj(src, out)
        for name in EXPORTS:
            os.replace(stage / f"{name}.csv", destination / f"{name}.csv")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--private", type=Path, required=True)
    args = parser.parse_args()
    build(args.partitions.resolve(), args.private.resolve())
