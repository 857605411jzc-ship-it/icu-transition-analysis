-- Released CLIF converted deidentified MIMIC timestamps from US/Eastern to UTC.
-- Require both admission and discharge clocks; verify the index move independently for a fixed offset.
CREATE TEMP MACRO raw_clock(d, mode_name) AS CASE mode_name
 WHEN 'utc' THEN CAST(d AS TIMESTAMP)
 WHEN 'eastern' THEN timezone('America/New_York',d::TIMESTAMPTZ)
 WHEN 'fixed_est' THEN CAST(d AS TIMESTAMP)-INTERVAL '5 hours' END;

CREATE TEMP MACRO clock_agrees(d, target, mode_name) AS
 abs(epoch(raw_clock(d,mode_name) - target))<=60;

CREATE TEMP TABLE original_links AS
SELECT t.pid,t.hid,t.tm,t.icu_in,t.hospital_end,t.first_return,
  a.admit,a.discharge,a.death,a.expired,p.dod,p.age0+year(a.admit)-p.ayear AS age,
  x.hospitalization_id IS NOT NULL AS linked,
  x.admission_dttm AS clif_admit,x.discharge_dttm AS clif_discharge
FROM p_transfer t JOIN admissions0 a USING(pid,hid) JOIN patients0 p USING(pid)
LEFT JOIN clif_hospitalization x ON try_cast(x.hospitalization_id AS BIGINT)=t.hid AND try_cast(x.patient_id AS BIGINT)=t.pid;

CREATE TEMP TABLE boundary_clock AS
WITH events AS (
 SELECT b.pid,b.tm, CASE WHEN lower(trim(a.location_category))='icu' THEN a.out_dttm ELSE a.in_dttm END AS event
 FROM original_links b JOIN clif_adt a ON try_cast(a.patient_id AS BIGINT)=b.pid
 AND try_cast(a.hospitalization_id AS BIGINT)=b.hid
 WHERE lower(trim(a.location_category)) IN ('icu','ward')
)
SELECT pid,
 bool_or(clock_agrees(event,tm,'utc')) AS utc_boundary,
 bool_or(clock_agrees(event,tm,'eastern')) AS eastern_boundary,
 bool_or(clock_agrees(event,tm,'fixed_est')) AS fixed_boundary
FROM events GROUP BY pid;

CREATE TEMP TABLE paired_clocks AS
SELECT b.*,u.utc_boundary,u.eastern_boundary,u.fixed_boundary,
 clock_agrees(clif_admit,admit,'utc') AND clock_agrees(clif_discharge,discharge,'utc') AS utc_ok,
 clock_agrees(clif_admit,admit,'eastern') AND clock_agrees(clif_discharge,discharge,'eastern') AS eastern_ok,
 year(admit)>=2038 AND clock_agrees(clif_admit,admit,'fixed_est') AND clock_agrees(clif_discharge,discharge,'fixed_est') AS fixed_ok
FROM original_links b LEFT JOIN boundary_clock u USING(pid);

CREATE TEMP VIEW clocked AS
SELECT *,CASE WHEN utc_ok AND NOT eastern_ok AND NOT fixed_ok THEN 'utc'
 WHEN eastern_ok AND NOT fixed_ok THEN 'eastern'
 WHEN fixed_ok AND NOT eastern_ok AND fixed_boundary THEN 'fixed_est'
 WHEN eastern_ok AND fixed_ok AND eastern_boundary AND NOT coalesce(fixed_boundary,false) THEN 'eastern'
 WHEN eastern_ok AND fixed_ok AND fixed_boundary AND NOT coalesce(eastern_boundary,false) THEN 'fixed_est'
 WHEN eastern_ok AND fixed_ok THEN 'winter_agreement' END AS clock
FROM paired_clocks;

CREATE TEMP MACRO to_wall(d, clock_mode) AS CASE WHEN clock_mode='winter_agreement' THEN
 CASE WHEN raw_clock(d,'fixed_est')=raw_clock(d,'eastern') THEN raw_clock(d,'fixed_est') END
 ELSE raw_clock(d,clock_mode) END;

-- CLIF 2.1. For each signal use only records known by transfer.
CREATE TEMP TABLE vit_summary AS
WITH e AS (
 SELECT b.hid,b.tm,to_wall(v.recorded_dttm,b.clock) AS at_t,try_cast(v.vital_value AS DOUBLE) AS val
 FROM clocked b JOIN clif_vitals v ON try_cast(v.hospitalization_id AS BIGINT)=b.hid
 WHERE lower(v.vital_category)='map' AND try_cast(v.vital_value AS DOUBLE) BETWEEN 10 AND 250
), per_time AS (
 SELECT hid,tm,at_t,min(val) AS val FROM e
 WHERE at_t BETWEEN tm - INTERVAL '6 hours' AND tm GROUP BY ALL
)
SELECT hid,arg_max(val,at_t) AS map_last,
 arg_max(val,at_t) FILTER (WHERE at_t<=last_t-INTERVAL '1 hour') AS prior_map,
 count(DISTINCT date_trunc('hour',at_t)) AS map_hours,
 max(at_t) AS map_t FROM (SELECT *,max(at_t) OVER (PARTITION BY hid) AS last_t FROM per_time) z GROUP BY hid;

-- Both published specimen fields are NULL by construction in v1.1.0. Its exact named
-- Lactate category contains only blood assays 50813 and 53154. Keep explicit nonblood specimens out.
CREATE TEMP TABLE lactate_source AS
SELECT b.hid,b.tm,to_wall(l.lab_collect_dttm,b.clock) AS collected,
 to_wall(l.lab_result_dttm,b.clock) AS resulted,try_cast(l.lab_value_numeric AS DOUBLE) AS val,
 (lower(trim(coalesce(l.lab_specimen_category,''))) IN ('blood/plasma/serum','blood','whole blood','plasma','serum')
 OR regexp_matches(lower(coalesce(l.lab_specimen_name,'')),'(^|[^a-z])(blood|serum|plasma|arterial|venous)([^a-z]|$)')) AS explicit_blood,
 (lower(trim(l.lab_name))='lactate' AND lower(trim(l.lab_category))='lactate'
 AND nullif(trim(l.lab_specimen_category),'') IS NULL AND nullif(trim(l.lab_specimen_name),'') IS NULL) AS release_blood,
 lower(replace(trim(l.reference_unit),' ','')) IN ('mmol/l','meq/l') AS compatible_unit
FROM clocked b JOIN clif_labs l ON try_cast(l.hospitalization_id AS BIGINT)=b.hid
WHERE lower(trim(l.lab_category)) IN ('lactate','lactate_arterial','lactate_venous');

CREATE TEMP TABLE lab_summary AS
WITH per_time AS (
 SELECT hid,tm,collected,max(val) AS val FROM lactate_source
 WHERE collected BETWEEN tm-INTERVAL '12 hours' AND tm AND resulted BETWEEN collected AND tm
 AND (explicit_blood OR release_blood) AND compatible_unit AND val>0 AND val<=50 GROUP BY ALL
)
SELECT hid,arg_max(val,collected) AS lactate FROM per_time GROUP BY hid;

CREATE TEMP TABLE vent_summary AS
WITH e AS (
 SELECT b.hid,b.tm,to_wall(r.recorded_dttm,b.clock) AS at_t,
 lower(trim(r.device_category)) AS device
 FROM clocked b JOIN clif_respiratory_support r ON try_cast(r.hospitalization_id AS BIGINT)=b.hid
 WHERE lower(trim(r.device_category)) IN ('imv','nippv','cpap','high flow nc','nasal cannula','room air','face mask','trach collar')
), per_time AS (
 SELECT hid,tm,at_t,max(CASE WHEN device='imv' THEN 2
   WHEN device IN ('nippv','cpap','high flow nc') THEN 1 ELSE 0 END) AS level
 FROM e WHERE at_t BETWEEN tm-INTERVAL '6 hours' AND tm GROUP BY ALL
)
SELECT hid,arg_max(level,at_t) AS resp_level FROM per_time GROUP BY hid;

CREATE TEMP TABLE pressor_summary AS
WITH e AS (
 SELECT b.hid,b.tm,b.icu_in,to_wall(m.admin_dttm,b.clock) AS at_t,
 coalesce(CAST(m.med_order_id AS VARCHAR),'unknown') AS order_id,lower(m.med_category) AS drug,
 try_cast(m.med_dose AS DOUBLE) AS dose
 FROM clocked b JOIN clif_medication_admin_continuous m ON try_cast(m.hospitalization_id AS BIGINT)=b.hid
), monitored AS (
 SELECT hid,count(*) FILTER(WHERE at_t BETWEEN tm-INTERVAL '24 hours' AND tm AND dose IS NOT NULL) AS infusion_obs
 FROM e GROUP BY hid
), timestamps AS (
 SELECT hid,tm,order_id,drug,at_t,max(dose) AS dose, count(dose)<count(*) AS missing_rate
 FROM e WHERE drug IN ('norepinephrine','epinephrine','phenylephrine','vasopressin','dopamine','angiotensin','angiotensin_ii','angiotensin_2')
 AND at_t<=tm AND at_t>=icu_in GROUP BY ALL
), last_event AS (
 SELECT * FROM timestamps QUALIFY row_number() OVER(PARTITION BY hid,order_id,drug ORDER BY at_t DESC)=1
), state AS (
 SELECT hid,bool_or(dose>0 AND NOT missing_rate AND at_t>=tm-INTERVAL '6 hours') AS on_pressor,
 bool_or(dose>0 OR dose IS NULL OR missing_rate) AS unresolved FROM last_event GROUP BY hid
)
SELECT m.hid, m.infusion_obs, CASE WHEN s.on_pressor THEN true
 WHEN s.unresolved THEN NULL WHEN m.infusion_obs>0 THEN false END AS pressor
FROM monitored m LEFT JOIN state s USING(hid);

CREATE TEMP TABLE transfer_status AS
WITH signals AS (
 SELECT c.pid,c.hid,c.tm,c.age,c.first_return,c.hospital_end,c.admit,c.discharge,c.death,c.expired,c.dod,c.linked,c.clock,
 v.map_last,v.prior_map,v.map_hours,v.map_t,l.lactate,r.resp_level,p.pressor,s.sofa_now,s.sofa_prev,
 (v.map_hours>=2 AND v.map_t>=c.tm-INTERVAL '2 hours' AND v.map_last>=65 AND v.prior_map>=65) AS serial_map_ok,
 (v.map_hours>=2 AND v.map_t>=c.tm-INTERVAL '2 hours' AND v.map_last<65 AND v.prior_map<65) AS serial_map_low
 FROM clocked c LEFT JOIN vit_summary v USING(hid) LEFT JOIN lab_summary l USING(hid)
 LEFT JOIN vent_summary r USING(hid) LEFT JOIN pressor_summary p USING(hid) LEFT JOIN sofa_summary s USING(hid)
), assessed AS (
 SELECT *, CASE WHEN sofa_now>=2 THEN true WHEN clock IS NULL THEN NULL
 WHEN pressor OR resp_level=2 OR lactate>=2 OR serial_map_low THEN true
 WHEN pressor=false AND resp_level=0 AND serial_map_ok THEN false END AS high,
 CASE WHEN sofa_now IS NOT NULL AND sofa_prev IS NOT NULL THEN sofa_now<sofa_prev END AS falling_sofa
 FROM signals
)
SELECT *,NOT high AS stable,CASE WHEN high=false OR falling_sofa THEN true WHEN clock IS NULL THEN NULL
 WHEN high=true AND (sofa_now IS NULL OR falling_sofa=false) THEN false END AS recovering FROM assessed;
