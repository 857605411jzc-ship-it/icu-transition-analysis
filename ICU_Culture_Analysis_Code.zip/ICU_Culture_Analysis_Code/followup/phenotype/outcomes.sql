CREATE TEMP VIEW all_gaps AS
SELECT g.*,CASE WHEN g.sterile THEN 'high_sterile_or_deep' WHEN s.high THEN 'high_physiology'
 WHEN g.nonsterile AND s.stable THEN 'stable_urine_or_airway' ELSE 'other_or_unknown' END AS phenotype
FROM p_gaps g JOIN transfer_status s USING(pid,hid,tm);

CREATE TEMP TABLE alert_followup AS
WITH classified AS (
 SELECT a.pid,a.hid,a.tm,a.alert,a.sterile,a.nonsterile,a.channel,a.pre,a.time_complete,a.follow_documented,a.base_documented,a.hours,
 s.first_return,s.hospital_end,s.death,s.expired,s.dod,s.age,s.lactate,s.sofa_now,
 CASE WHEN a.sterile THEN 'high_sterile_or_deep' WHEN s.high THEN 'high_physiology'
 WHEN a.nonsterile AND s.stable THEN 'stable_urine_or_airway' ELSE 'other_or_unknown' END AS phenotype,
 a.alert + INTERVAL '24 hours' AS landmark,
 CASE WHEN s.expired=1 THEN CASE WHEN s.death BETWEEN s.admit AND s.discharge+INTERVAL '1 day' THEN s.death ELSE s.discharge END
 WHEN s.death BETWEEN s.admit AND s.discharge+INTERVAL '1 day' AND s.dod=CAST(s.death AS DATE) THEN s.death END AS inpatient_death,
 ((s.expired IS DISTINCT FROM 1 AND s.death IS NOT NULL AND s.dod IS DISTINCT FROM CAST(s.death AS DATE)) OR
  (s.expired=1 AND s.death IS NOT NULL AND s.death NOT BETWEEN s.admit AND s.discharge+INTERVAL '1 day') OR
  (s.expired=0 AND s.death IS NULL AND s.dod IS NOT NULL AND s.dod<CAST(s.discharge AS DATE))) AS unresolved_death_flag
 FROM p_alert a JOIN transfer_status s USING(pid,hid,tm)
), eligible AS (
 SELECT *, (base_documented AND follow_documented AND time_complete AND NOT pre) AS documented,
 (first_return<=landmark) IS TRUE AS early_icu,
 (inpatient_death<=landmark OR (inpatient_death IS NULL AND dod<CAST(landmark AS DATE))) IS TRUE AS early_death,
 (inpatient_death IS NULL AND dod=CAST(landmark AS DATE)) IS TRUE AS date_ambiguous,
 (hospital_end<=landmark) IS TRUE AS early_discharge
 FROM classified
), measured AS (
 SELECT *, documented AND NOT early_death AND NOT early_discharge AND NOT early_icu AND NOT date_ambiguous AS landmark_eligible,
 hours IS NOT NULL AND hours>0 AND hours<=24 AS active_24,
 (unresolved_death_flag OR (dod IS NOT NULL AND inpatient_death IS NOT NULL AND abs(date_diff('day',dod,CAST(inpatient_death AS DATE)))>1)) IS TRUE AS death_conflict
 FROM eligible
)
SELECT *,
 (first_return>landmark AND first_return<=tm+INTERVAL '7 days' AND first_return<hospital_end) IS TRUE AS return7_transfer,
 (first_return>landmark AND first_return<=alert+INTERVAL '7 days' AND first_return<hospital_end) IS TRUE AS return7_alert,
 CASE WHEN death_conflict THEN NULL WHEN inpatient_death IS NOT NULL THEN CAST(inpatient_death AS DATE)<=CAST(alert AS DATE)+28
      WHEN dod IS NOT NULL THEN dod<=CAST(alert AS DATE)+28 ELSE false END AS death28,
 GREATEST(0,epoch(hospital_end-landmark)/86400.0) AS los_after_landmark
FROM measured;
