"""Transfer physiology and subsequent course at the first strictly matched susceptibility report."""

import argparse
import csv
import math
import os
import random
import shutil
import statistics
import tempfile
import zipfile
from collections import defaultdict
from pathlib import Path

import duckdb

HERE = Path(__file__).resolve().parent
CLIF = (
    "adt",
    "hospitalization",
    "vitals",
    "labs",
    "respiratory_support",
    "medication_admin_continuous",
)
PRIVATE_BRIDGE = {
    "p_transfer": (
        "pid:BIGINT hid:BIGINT tm:TIMESTAMP icu_in:TIMESTAMP hospital_end:TIMESTAMP first_return:TIMESTAMP"
    ),
    "p_gaps": "pid:BIGINT hid:BIGINT tm:TIMESTAMP report_time:TIMESTAMP sterile:BOOLEAN nonsterile:BOOLEAN",
    "p_alert": "pid:BIGINT hid:BIGINT tm:TIMESTAMP alert:TIMESTAMP sterile:BOOLEAN nonsterile:BOOLEAN channel:VARCHAR pre:BOOLEAN base_documented:BOOLEAN follow_documented:BOOLEAN time_complete:BOOLEAN hours:DOUBLE",
}


def sqlstr(x):
    return "'" + str(x).replace("'", "''") + "'"


def unique_file(base, names, work, group=None, optional=False):
    """Find the selected release's one table. Extract only its member if packaged."""
    base = Path(base).resolve()
    if not base.exists():
        raise FileNotFoundError(base)
    allowed = {f"{n}{e}" for n in names for e in (".parquet", ".csv.gz", ".csv")}

    def good(s):
        return (
            Path(s).name.lower() in allowed
            and "__MACOSX" not in str(s)
            and not Path(s).name.startswith("._")
        )

    if base.is_file() and good(base.name):
        return base
    files = (
        [f for f in base.rglob("*") if f.is_file() and good(f.name)]
        if base.is_dir()
        else []
    )
    if len(files) > 1 and group:
        narrower = [f for f in files if group in {p.lower() for p in f.parts}]
        if narrower:
            files = narrower
    if len(files) == 1:
        return files[0]
    if len(files) > 1:
        raise ValueError(
            f"Multiple copies of {names[0]} found; choose one release directory."
        )
    archives = sorted(base.rglob("*.zip")) if base.is_dir() else [base]
    hits = []
    for archive in archives:
        if not zipfile.is_zipfile(archive):
            continue
        with zipfile.ZipFile(archive) as zf:
            matches = [k for k in zf.namelist() if good(k)]
            if len(matches) > 1 and group:
                matches = [
                    k for k in matches if group in {p.lower() for p in Path(k).parts}
                ]
            hits.extend((archive, k) for k in matches)
    if not hits and optional:
        return None
    if len(hits) != 1:
        raise ValueError(
            f"Expected one {names[0]} table under selected release; found {len(hits)} archived copies."
        )
    archive, k = hits[0]
    path = work / Path(k).name
    with zipfile.ZipFile(archive) as zf, zf.open(k) as src, path.open("wb") as dst:
        shutil.copyfileobj(src, dst)
    return path


def scan(path):
    if path.suffix.lower() == ".parquet":
        return "read_parquet(" + sqlstr(path) + ")"
    return "read_csv(" + sqlstr(path) + ",all_varchar=true,header=true)"


def attach_bridge(db, private, name):
    file = unique_file(private, [name], private)
    columns = [c.split(":") for c in PRIVATE_BRIDGE[name].split()]
    db.execute(
        "CREATE TEMP TABLE "
        + name
        + " AS SELECT "
        + ",".join(f"CAST({c} AS {t}) AS {c}" for c, t in columns)
        + " FROM "
        + scan(file)
    )
    keys = ["pid", "hid", "tm"] + (["channel"] if name == "p_alert" else [])
    dup = db.execute(
        "SELECT COUNT(*) FROM (SELECT "
        + ",".join(keys)
        + " FROM "
        + name
        + " GROUP BY ALL HAVING COUNT(*)<>1)"
    ).fetchone()[0]
    if dup:
        raise ValueError("Duplicates in " + name)


def register_inputs(db, args, work):
    for n in CLIF:
        f = unique_file(args.clif, ["clif_" + n], work, optional=(n == "adt"))
        if n == "adt":
            db.execute("CREATE TEMP TABLE adt_audit(supplied BOOLEAN)")
            db.execute("INSERT INTO adt_audit VALUES (?)", [f is not None])
        if f is None:
            # The fixed-offset conversion requires independent confirmation at ICU exit.
            db.execute(
                "CREATE TEMP TABLE clif_adt(patient_id VARCHAR,hospitalization_id VARCHAR,location_category VARCHAR,in_dttm TIMESTAMPTZ,out_dttm TIMESTAMPTZ)"
            )
        else:
            db.execute(f"CREATE TEMP VIEW clif_{n} AS SELECT * FROM " + scan(f))
    adm = unique_file(args.mimic, ["admissions"], work, "hosp")
    pats = unique_file(args.mimic, ["patients"], work, "hosp")
    db.execute(
        "CREATE TEMP TABLE admissions0 AS SELECT CAST(subject_id AS BIGINT) pid,CAST(hadm_id AS BIGINT) hid,"
        "CAST(admittime AS TIMESTAMP) admit,CAST(dischtime AS TIMESTAMP) discharge,CAST(deathtime AS TIMESTAMP) death,"
        "CAST(hospital_expire_flag AS INT) expired FROM " + scan(adm)
    )
    db.execute(
        "CREATE TEMP TABLE patients0 AS SELECT CAST(subject_id AS BIGINT) pid,CAST(dod AS DATE) dod,"
        "CAST(anchor_age AS INT) age0,CAST(anchor_year AS INT) ayear FROM " + scan(pats)
    )
    db.execute(
        "CREATE TEMP TABLE sofa_summary(hid BIGINT,sofa_now DOUBLE,sofa_prev DOUBLE)"
    )
    if args.sofa:
        stays = unique_file(args.mimic, ["icustays"], work, "icu")
        s = scan(Path(args.sofa))
        db.execute("CREATE TEMP VIEW stay_source AS SELECT * FROM " + scan(stays))
        db.execute("CREATE TEMP VIEW sofa_source AS SELECT * FROM " + s)
        cols = {c[0].lower() for c in db.execute("DESCRIBE sofa_source").fetchall()}
        if not {"stay_id", "endtime", "sofa_24hours"} <= cols:
            raise ValueError(
                "Optional rolling SOFA requires MIMIC Code's stay_id,endtime,sofa_24hours."
            )
        db.execute("""INSERT INTO sofa_summary
            WITH e AS (SELECT t.hid,t.tm,CAST(s.endtime AS TIMESTAMP) et,try_cast(s.sofa_24hours AS INT) score
            FROM p_transfer t JOIN stay_source i ON try_cast(i.hadm_id AS BIGINT)=t.hid AND try_cast(i.subject_id AS BIGINT)=t.pid
            JOIN sofa_source s ON try_cast(s.stay_id AS BIGINT)=try_cast(i.stay_id AS BIGINT)
            WHERE cast(i.intime AS TIMESTAMP)<t.tm AND cast(i.outtime AS TIMESTAMP)>=t.icu_in
            AND cast(s.endtime AS TIMESTAMP) BETWEEN greatest(t.icu_in,t.tm-INTERVAL '36 hours') AND t.tm
            AND try_cast(s.sofa_24hours AS INT) BETWEEN 0 AND 24)
            SELECT hid,arg_max(score,et) FILTER (WHERE et>tm-INTERVAL '6 hours'),
            arg_max(score,et) FILTER (WHERE et BETWEEN tm-INTERVAL '30 hours' AND tm-INTERVAL '24 hours')
            FROM e GROUP BY hid""")
    for col in ["lab_collect_dttm", "lab_result_dttm"]:
        assert col in {
            c[0].lower() for c in db.execute("DESCRIBE clif_labs").fetchall()
        }


def count_cell(n):
    return n if n >= 11 else "<11"


def wilson(n, N):
    z = 1.95996398454
    p = n / N
    m = (p + z * z / (2 * N)) / (1 + z * z / N)
    r = z * math.sqrt(p * (1 - p) / N + z * z / (4 * N * N)) / (1 + z * z / N)
    return max(0, 100 * (m - r)), min(100, 100 * (m + r))


def safe_measure(values, binary=True):
    data = [v for v in values if v is not None]
    N = len(data)
    if binary:
        n = sum(bool(x) for x in data)
        if n < 11 or N - n < 11:
            return [
                count_cell(N),
                count_cell(n) if N - n >= 11 else "",
                None,
                None,
                None,
                "small_cell",
            ]
        lb, ub = wilson(n, N)
        return [N, n, 100 * n / N, lb, ub, "measured"]
    if N < 11:
        return [count_cell(N), "", None, None, None, "small_cell"]
    return [N, "", statistics.mean(data), None, None, "mean_days"]


def write_rows(path, header, rows):
    tmp = path.with_suffix(".building")
    with tmp.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        for r in rows:
            w.writerow([round(x, 4) if isinstance(x, float) else x for x in r])
    os.replace(tmp, path)


def atomic_copy(db, query, target, options):
    tmp = target.with_suffix(".part")
    db.execute("COPY (" + query + ") TO " + sqlstr(tmp) + " (" + options + ")")
    os.replace(tmp, target)


def records(db, query):
    out = db.execute(query)
    names = [d[0] for d in out.description]
    return [dict(zip(names, row)) for row in out.fetchall()]


def contrast(rows, outcome):
    """Overlap-standardized differences; resample patients in each supported treatment-by-stratum cell."""
    strata = defaultdict(lambda: {False: [], True: []})
    for r in rows:
        if r[outcome] is not None and r["age"] is not None:
            k = (
                r["age"] >= 65,
                r["sterile"],
                r["physiology_high"],
                r["alert_delay_hours"] >= 24,
            )
            strata[k][r["active_24"]].append(float(r[outcome]))
    supported = [g for g in strata.values() if g[False] and g[True]]
    n = sum(len(ys) for g in supported for ys in g.values())
    if not supported:
        return [count_cell(n), None, None, None, "no_overlap"]
    for arm in (True, False):
        observations = [v for g in supported for v in g[arm]]
        if len(observations) < 11 or (
            outcome != "los_after_landmark"
            and min(sum(observations), len(observations) - sum(observations)) < 11
        ):
            return [count_cell(n), None, None, None, "small_cell"]
    weights = [
        len(g[True]) * len(g[False]) / (len(g[True]) + len(g[False])) for g in supported
    ]

    def diff(resample=False):
        value = 0
        for g, w in zip(supported, weights):
            a, b = g[True], g[False]
            if resample:
                a = rng.choices(a, k=len(a))
                b = rng.choices(b, k=len(b))
            value += w * (statistics.mean(a) - statistics.mean(b))
        return value / sum(weights) * (1 if outcome == "los_after_landmark" else 100)

    rng = random.Random(422114)
    estimate = diff()
    draws = sorted(diff(True) for _ in range(1000))
    return [
        n,
        estimate,
        draws[24],
        draws[974],
        "overlap_standardized_fixed_strata_bootstrap",
    ]


def aggregate(db, out, private):
    groups = [
        "high_sterile_or_deep",
        "high_physiology",
        "stable_urine_or_airway",
        "other_or_unknown",
    ]
    flow = []
    for source in ["all_gaps", "alert_followup"]:
        for g in groups:
            q = "SELECT count(DISTINCT pid) FROM " + source + " WHERE phenotype=?"
            flow.append([source, g, count_cell(db.execute(q, [g]).fetchone()[0])])
    write_rows(
        out / "phenotype_site_flow.csv", ["population", "phenotype", "patients"], flow
    )
    indicators = (
        "pre",
        "documented",
        "early_icu",
        "early_death",
        "early_discharge",
        "date_ambiguous",
        "landmark_eligible",
        "death_conflict",
    )
    outcomes = ("return7_transfer", "return7_alert", "death28", "los_after_landmark")
    rows = records(
        db,
        """SELECT a.*,s.high AS physiology_high,epoch(a.alert-a.tm)/3600.0 AS alert_delay_hours
                     FROM alert_followup a JOIN transfer_status s USING(pid,hid,tm)""",
    )
    measured = []
    adjusted = []
    eligibility = []
    for ch in ("administration", "order"):
        for name in ("high_risk", "stable_urine_or_airway", "other_or_unknown"):
            selected = [
                r
                for r in rows
                if r["channel"] == ch
                and (
                    r["phenotype"].startswith("high_")
                    if name == "high_risk"
                    else r["phenotype"] == name
                )
            ]
            for key in indicators:
                eligibility.append(
                    [
                        ch,
                        name,
                        key,
                        count_cell(sum(bool(r[key]) for r in selected)),
                        count_cell(len(selected)),
                    ]
                )
            # Discharge-summary observation at admission level is handled by the notes module.
            ds = [r for r in selected if r["documented"]]
            measured.append(
                [
                    ch,
                    name,
                    "all_documented",
                    "matched_by_24h",
                    *safe_measure([r["active_24"] for r in ds]),
                ]
            )
            cohort = [r for r in selected if r["landmark_eligible"]]
            for arm in (True, False):
                arm_rows = [r for r in cohort if r["active_24"] == arm]
                for endpoint in outcomes:
                    measured.append(
                        [
                            ch,
                            name,
                            "matched" if arm else "no_match",
                            endpoint,
                            *safe_measure(
                                [r[endpoint] for r in arm_rows],
                                endpoint != "los_after_landmark",
                            ),
                        ]
                    )
                if name == "stable_urine_or_airway" and not arm:
                    vals = [
                        (
                            (not r["return7_transfer"] and not r["death28"])
                            if r["death28"] is not None
                            else None
                        )
                        for r in arm_rows
                    ]
                    measured.append(
                        [
                            ch,
                            name,
                            "no_match",
                            "no_observed_return7_and_no_recorded_death28",
                            *safe_measure(vals),
                        ]
                    )
            if name == "high_risk":
                for endpoint in outcomes:
                    adjusted.append([ch, name, endpoint, *contrast(cohort, endpoint)])
    write_rows(
        out / "phenotype_landmark_flow.csv",
        [
            "channel",
            "phenotype",
            "criterion_nonexclusive",
            "patients",
            "source_patients",
        ],
        eligibility,
    )
    write_rows(
        out / "phenotype_treatment_outcomes.csv",
        [
            "channel",
            "phenotype",
            "treatment_24h",
            "endpoint",
            "denominator",
            "events",
            "percent_or_mean_days",
            "wilson_low_pct",
            "wilson_high_pct",
            "status",
        ],
        measured,
    )
    write_rows(
        out / "phenotype_adjusted_contrasts.csv",
        [
            "channel",
            "phenotype",
            "endpoint",
            "overlap_patients",
            "matched_minus_no_match_pp_or_days",
            "ci_low",
            "ci_high",
            "status",
        ],
        adjusted,
    )
    atomic_copy(
        db,
        """SELECT pid,hid, CASE WHEN phenotype='other_or_unknown' THEN NULL ELSE phenotype='stable_urine_or_airway' END AS low_risk,
                 documented AS eligible_admin24,CASE WHEN documented THEN active_24 END AS active_admin24
                 FROM alert_followup WHERE channel='administration'""",
        private / "alert_phenotypes.csv",
        "FORMAT CSV,HEADER TRUE",
    )


def source_audit(db, private, out, has_sofa):
    """Summarize release-specific source coverage in the treatment decision populations."""
    db.execute(
        "CREATE TEMP TABLE audit_group AS SELECT 'transfers' AS cohort,pid FROM p_transfer"
    )
    for group, table in (
        ("discordant_at_transfer", "p_gaps"),
        ("first_matched_alert", "p_alert"),
    ):
        db.execute(
            "INSERT INTO audit_group SELECT ?,pid FROM " + table + " GROUP BY pid",
            [group],
        )
    harm = private / "harm_index.csv"
    if harm.is_file():
        db.execute(
            "INSERT INTO audit_group SELECT 'ward_harm_'||analysis,cast(pid AS BIGINT) FROM "
            + scan(harm)
            + " WHERE analysis IN ('strict_negative','low_yield') GROUP BY ALL"
        )
    conditions = {
        "transfers": "true",
        "CLIF_id_match": "linked",
        "both_anchors_raw_UTC": "utc_ok",
        "both_anchors_dynamic_eastern": "eastern_ok",
        "both_anchors_fixed_est": "fixed_ok",
        "fixed_est_only_and_confirmed_at_index_move": "fixed_ok AND NOT eastern_ok AND NOT utc_ok AND fixed_boundary",
        "fixed_est_only_without_index_confirmation": "fixed_ok AND NOT eastern_ok AND NOT utc_ok AND NOT coalesce(fixed_boundary,false)",
        "usable_clock": "clock IS NOT NULL",
        "any_candidate_lactate_collected_12h": "coalesce(collected_window,false)",
        "eligible_specimen_and_units_12h": "coalesce(usable_specimen,false)",
        "eligible_result_known_by_transfer": "lactate IS NOT NULL",
        "using_release_mapping_with_blank_specimen_eligible": "coalesce(timely_inferred_blood,false)",
        "any_optional_rolling_SOFA": "sofa_now IS NOT NULL",
        "serial_MAP": "serial_map_ok OR serial_map_low",
        "respiratory_class_observed": "resp_level IS NOT NULL",
        "pressor_status_observed": "pressor IS NOT NULL",
        "elevated_risk": "high",
        "stable": "stable",
        "recovery": "recovering",
        "physiological_status_unknown": "high IS NULL",
    }
    db.execute("""CREATE TEMP VIEW audit_facts AS WITH samples AS (
      SELECT hid,bool_or(collected BETWEEN tm-INTERVAL '12 hours' AND tm) collected_window,
      bool_or(collected BETWEEN tm-INTERVAL '12 hours' AND tm AND (release_blood OR explicit_blood)
              AND compatible_unit AND val>0 AND val<=50) usable_specimen,
      bool_or(collected BETWEEN tm-INTERVAL '12 hours' AND tm AND resulted BETWEEN collected AND tm
              AND release_blood AND compatible_unit AND val>0 AND val<=50) timely_inferred_blood
      FROM lactate_source GROUP BY hid)
      SELECT g.cohort,s.*,b.utc_ok,b.eastern_ok,b.fixed_ok,b.fixed_boundary,l.collected_window,l.usable_specimen,l.timely_inferred_blood
      FROM audit_group g JOIN transfer_status s USING(pid) JOIN paired_clocks b USING(pid)
      LEFT JOIN samples l ON l.hid=s.hid""")
    rows = []
    for name, cond in conditions.items():
        for group, n, den in db.execute(
            "SELECT cohort,count(*) FILTER(WHERE "
            + cond
            + "),count(*) FROM audit_facts GROUP BY cohort ORDER BY cohort"
        ).fetchall():
            rows.append((group, name, count_cell(n), count_cell(den)))
    adt_supplied = db.execute("SELECT supplied FROM adt_audit").fetchone()[0]
    rows.append(
        ("all", "CLIF_ADT_source_supplied", "yes" if adt_supplied else "no", "")
    )
    rows.append(
        ("all", "optional_rolling_SOFA_file_supplied", "yes" if has_sofa else "no", "")
    )
    write_rows(
        out / "phenotype_source_audit.csv",
        ["population", "measure", "patients_or_status", "denominator_patients"],
        rows,
    )


def run(args):
    private, out = Path(args.private).resolve(), Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(
        prefix="phenotype_", dir=private
    ) as temp, duckdb.connect() as db:
        work = Path(temp)
        db.execute("SET TimeZone='UTC'")
        db.execute("SET threads=2")
        db.execute("SET memory_limit='1500MB'")
        db.execute("SET temp_directory=" + sqlstr(work / "spill"))
        attach_bridge(db, private, "p_transfer")
        register_inputs(db, args, work)
        db.execute((HERE / "status.sql").read_text(encoding="utf-8"))
        n_base = db.execute("SELECT count(*) FROM p_transfer").fetchone()[0]
        n, nu, n_clock = db.execute(
            "SELECT count(*),count(DISTINCT pid),count(clock) FROM transfer_status"
        ).fetchone()
        if n != n_base or nu != n_base:
            raise ValueError(
                "Raw admissions/patients linkage is incomplete or duplicates a transfer."
            )
        metrics = {
            m: int(
                db.execute(
                    f"SELECT count(*) FROM transfer_status WHERE {condition}"
                ).fetchone()[0]
            )
            for m, condition in {
                "index": "true",
                "id_matched": "linked",
                "two_timestamps_utc": "clock='utc'",
                "two_timestamps_eastern": "clock='eastern'",
                "fixed_est_with_boundary": "clock='fixed_est'",
                "winter_event_clock_agreement": "clock='winter_agreement'",
                "unmatched_clocks": "clock IS NULL",
                "elevated_risk": "high",
                "stable": "stable",
                "unclassified": "high IS NULL",
                "lactate_measured": "lactate IS NOT NULL",
                "rolling_sofa_measured": "sofa_now IS NOT NULL",
                "pressor_known": "pressor IS NOT NULL",
                "respiratory_device_known": "resp_level IS NOT NULL",
                "serial_map_available": "serial_map_ok OR serial_map_low",
                "falling_sofa": "falling_sofa",
                "recovering": "recovering",
                "discharge_death_flag_without_time": "expired=1 AND death IS NULL",
                "time_without_discharge_death_flag": "expired=0 AND death IS NOT NULL",
            }.items()
        }
        write_rows(
            out / "phenotype_clif_linkage.csv",
            ["measure", "patients"],
            [(k, count_cell(v)) for k, v in metrics.items()],
        )
        if not n_clock:
            raise ValueError(
                "No matched CLIF encounter validates both wall-clock anchors. Inspect the CLIF release and date conversions."
            )
        atomic_copy(
            db,
            "SELECT * FROM transfer_status",
            private / "transfer_status.parquet",
            "FORMAT PARQUET,COMPRESSION ZSTD",
        )
        if args.status_only:
            return
        for name in ["p_gaps", "p_alert"]:
            attach_bridge(db, private, name)
        source_audit(db, private, out, bool(args.sofa))
        db.execute((HERE / "outcomes.sql").read_text(encoding="utf-8"))
        expected = db.execute("SELECT count(*) FROM p_gaps").fetchone()[0]
        actual = db.execute("SELECT count(*) FROM all_gaps").fetchone()[0]
        if (
            expected != actual
            or db.execute("SELECT count(*) FROM p_alert").fetchone()[0]
            != db.execute("SELECT count(*) FROM alert_followup").fetchone()[0]
        ):
            raise ValueError("Patient counts changed while joining transfer status.")
        aggregate(db, out, private)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ["private", "out", "mimic", "clif"]:
        parser.add_argument("--" + arg, required=True)
    parser.add_argument(
        "--sofa",
        help="Optional existing MIT-LCP hourly SOFA parquet/csv[.gz] with stay_id,endtime,sofa_24hours.",
    )
    parser.add_argument("--status-only", action="store_true")
    run(parser.parse_args())
