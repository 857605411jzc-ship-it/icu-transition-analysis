"""Audit discharge-document language for an existing first-transfer cohort (standard library)."""

import argparse
import contextlib
import csv
import datetime as dt
import gzip
import io
import math
import re
import tarfile
import zipfile
from pathlib import Path

CULT = r"\b(?:cultures?|b(?:l)?cx|ucx|scx|(?:blood|urine|sputum|respiratory) cx|susceptibilit(?:y|ies)|sensitivities)\b"
PEND = r"\b(?:pending|in process|in progress|not yet (?:final|available|resulted)|await(?:ing)?|to follow|preliminary|no growth to date|ngtd)\b"
ACTION = r"\b(?:stop|discontinue|d/c|narrow|de[- ]?escalate|switch|change|adjust|broaden|start|initiate|restart|continue|hold|tailor|modify|withhold)(?:s|ed|ing)?\b"
ABX = r"\b(?:antibiotics?|antimicrobials?|abx|coverage|vancomycin|vanco|linezolid|cefepime|ceftriaxone|ceftazidime|cefazolin|meropenem|ertapenem|imipenem|zosyn|piperacillin[ /-]tazobactam|ampicillin|amoxicillin|ciprofloxacin|levofloxacin|daptomycin)\b"
COND = r"\b(?:if|when|once|based on|depending on|according to|pending|until|upon|per (?:final )?(?:susceptibilit(?:y|ies)|sensitivities))\b"
COL = (
    r"\b(?:coloni[sz](?:ation|ed)|asymptomatic bacteriuria|contaminant|contamination)\b"
)
REJECT = r"\b(?:no (?:further )?(?:antibiotics?|antimicrobials?|abx|treatment)(?: (?:was |is )?(?:needed|required|indicated))?|(?:antibiotics?|antimicrobials?|abx|treatment) (?:were |was |are |is )?(?:withheld|not (?:needed|indicated|given|required))|(?:will |did )?not (?:treat|start antibiotics)|(?:monitor|observe) off antibiotics)\b"


def has(pattern, text):
    return re.search(pattern, text, re.I) is not None


def near(a, b, text, n=100):
    return has(f"(?:{a}).{{0,{n}}}?(?:{b})|(?:{b}).{{0,{n}}}?(?:{a})", text)


def classify(text):
    flags = set()
    # Join wrapped lines, keeping paragraphs and sentence boundaries; a short header
    # and its first content line stay together. Strip negated pending/plan pairs.
    clauses = re.split(r"(?<=[.!?])\s+|\n\s*\n|[;|]", text.lower().replace("\r", ""))
    for raw in clauses:
        s = " ".join(raw.split())
        if not s or not has(CULT + "|" + COL, s):
            continue
        # Split independently scoped clauses so 'urine negative but blood pending'
        # retains the blood observation. Limit negative scope to the same clause.
        for c in re.split(r"\b(?:but|however|whereas)\b", s):
            if has(CULT, c):
                flags.add("culture_or_susceptibility_mentioned")
            neg_pending = (
                has(
                    r"\b(?:no|without|denies|not any)\s+(?:remaining |further |other |known |longer |outstanding |final |pending |blood |urine |sputum |follow[- ]up )*(?:cultures?|sensitivities|susceptibilit(?:y|ies))\b",
                    c,
                )
                or has(
                    r"\b(?:no longer|not|none)\s+pending\b|\bpending(?: tests?| cultures?| results?)?\s*:\s*(?:none|nil|n/?a)\b",
                    c,
                )
                or has(
                    r"\b(?:cannot|could not|unclear (?:whether|if))\b.{0,40}\bpending\b",
                    c,
                )
            )
            if near(CULT, PEND, c) and not neg_pending:
                flags.add("pending_culture_marker")
            # A conditional culture-linked medication decision, stricter than generic follow-up.
            if (
                near(ACTION, ABX, c, 65)
                and near(CULT, COND, c, 115)
                and near(CULT, ACTION, c, 160)
                and not has(r"\b(?:no (?:documented )?plan|never planned|no need)\b", c)
            ):
                flags.add("antibiotic_contingency_marker")
            if near(COL, REJECT, c, 150) and not has(
                r"\b(?:not|no evidence of|rule out|exclude|cannot exclude|unlikely|concern for)\b.{0,15}"
                + COL,
                c,
            ):
                flags.add("colonization_no_treatment_marker")
    if {"pending_culture_marker", "antibiotic_contingency_marker"} <= flags:
        flags.add("both_markers_in_same_document")
    return flags


METRICS = (
    "culture_or_susceptibility_mentioned",
    "pending_culture_marker",
    "antibiotic_contingency_marker",
    "both_markers_in_same_document",
    "colonization_no_treatment_marker",
)
INDEX_FIELDS = {"pid", "hid", "tm", "discordant"}
NOTE_FIELDS = {
    "subject_id",
    "hadm_id",
    "note_id",
    "note_type",
    "charttime",
    "storetime",
    "text",
}


def verify_fields(reader, wanted):
    missing = wanted - set(reader.fieldnames or [])
    if missing:
        raise ValueError("Missing column(s): " + ", ".join(sorted(missing)))


def truth(s):
    value = str(s).strip().lower()
    if value not in {"0", "1", "true", "false", "t", "f"}:
        raise ValueError("Expected a complete boolean column")
    return value in {"1", "true", "t"}


def instant(s):
    if not s or s.strip().lower() in {"na", "null"}:
        return None
    return dt.datetime.fromisoformat(s.strip().replace("Z", "+00:00")).replace(
        tzinfo=None
    )


def opencsv(path):
    return (gzip.open if str(path).lower().endswith(".gz") else open)(
        path, "rt", newline="", encoding="utf-8-sig"
    )


def index_from(path):
    state = {}
    with opencsv(path) as src:
        reader = csv.DictReader(src)
        verify_fields(reader, INDEX_FIELDS)
        for row in reader:
            key = row["pid"], row["hid"]
            if key in state or not all(key):
                raise ValueError(
                    "Index must have complete unique patient/admission keys"
                )
            transfer = instant(row["tm"])
            if transfer is None:
                raise ValueError("Missing transfer time")
            state[key] = {
                "discordant": truth(row["discordant"]),
                "tm": transfer,
                "usable": False,
                "linked": False,
                "known_store": False,
                "by_t0": False,
                "flags": set(),
            }
    if not state or len({k[0] for k in state}) != len(state):
        raise ValueError(
            "Expected a non-empty first-transfer index with one row per patient"
        )
    return state


def is_member(name):
    return name.replace("\\", "/").rsplit("/", 1)[-1].lower() in {
        "discharge.csv",
        "discharge.csv.gz",
    }


def packed(name):
    return name.lower().endswith((".zip", ".tar", ".tar.gz", ".tgz"))


def locate(path):
    path = Path(path)
    if path.is_file():
        return path
    if not path.is_dir():
        raise FileNotFoundError("Note release path does not exist")
    # Prefer an extracted table to its containing archive. Ignore unrelated release archives.
    direct = sorted(
        i for i in path.rglob("discharge.csv*") if i.is_file() and is_member(i.name)
    )
    archives = (
        []
        if direct
        else sorted(
            i
            for i in path.rglob("*")
            if i.is_file()
            and packed(i.name)
            and ("mimic-iv-note" in str(i).lower() or "mimic_iv_note" in str(i).lower())
        )
    )
    hits = direct or archives
    if len(hits) != 1:
        raise ValueError(
            "Select the exact v2.2 discharge table or the single note archive"
        )
    return hits[0]


@contextlib.contextmanager
def open_notes(path):
    p = locate(path)
    with contextlib.ExitStack() as stack:
        if is_member(p.name):
            yield stack.enter_context(opencsv(p))
            return
        if p.name.lower().endswith(".zip"):
            a = stack.enter_context(zipfile.ZipFile(p))
            names = [n for n in a.namelist() if is_member(n)]
            if len(names) != 1:
                raise ValueError("Note zip must contain one discharge table")
            name = names[0]
            stream = stack.enter_context(a.open(name))
        elif packed(p.name):
            a = stack.enter_context(tarfile.open(p, "r:*"))
            names = [m for m in a.getmembers() if m.isfile() and is_member(m.name)]
            if len(names) != 1:
                raise ValueError("Note tar must contain one discharge table")
            name = names[0].name
            stream = stack.enter_context(a.extractfile(names[0]))
        else:
            raise ValueError("Expected discharge.csv[.gz] or a release zip/tar")
        if name.lower().endswith(".gz"):
            stream = stack.enter_context(gzip.GzipFile(fileobj=stream))
        yield stack.enter_context(
            io.TextIOWrapper(stream, encoding="utf-8-sig", newline="")
        )


def collect(state, note_path):
    seen = set()
    csv.field_size_limit(128 * 1024 * 1024)
    with open_notes(note_path) as src:
        reader = csv.DictReader(src)
        verify_fields(reader, NOTE_FIELDS)
        for row in reader:
            key = row["subject_id"], row["hadm_id"]
            if key not in state or row["note_type"].strip().upper() not in {"DS", "AD"}:
                continue
            nid = row["note_id"]
            if not nid or nid in seen:
                raise ValueError("Blank or duplicate linked discharge note identifier")
            seen.add(nid)
            s = state[key]
            s["linked"] = True
            prose = row["text"].strip()
            if not prose:
                continue
            s["usable"] = True
            stored = instant(row["storetime"])
            if stored is not None:
                s["known_store"] = True
                if stored <= s["tm"]:
                    s["by_t0"] = True
            s["flags"].update(classify(prose))


def release(group, metric, n, n_total):
    small = lambda x: str(x) if x >= 11 else "<11"
    if n < 11 or n_total < 11:
        return [group, metric, small(n), small(n_total), "", "", ""]
    p = n / n_total
    z = 1.959963984540054
    denom = 1 + z * z / n_total
    center = (p + z * z / (2 * n_total)) / denom
    delta = z / denom * math.sqrt(p * (1 - p) / n_total + z * z / (4 * n_total**2))
    return [
        group,
        metric,
        n,
        n_total,
        round(100 * p, 3),
        round(100 * max(0, center - delta), 3),
        round(100 * min(1, center + delta), 3),
    ]


def export(state, out, private=None):
    if private and (
        private.resolve() == out.resolve() or out.resolve() in private.resolve().parents
    ):
        raise ValueError("Keep private data outside the aggregate return directory")
    out.mkdir(exist_ok=True, parents=True)
    header = [
        "population",
        "metric",
        "n_transfers",
        "denominator_transfers",
        "percent",
        "wilson_lower95",
        "wilson_upper95",
    ]
    with open(out / "discharge_language.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        for label, rows in [
            ("all_pending", list(state.values())),
            ("discordant_pending", [s for s in state.values() if s["discordant"]]),
        ]:
            docs = [s for s in rows if s["usable"]]
            writer.writerow(
                release(
                    label,
                    "linked_discharge_note",
                    sum(s["linked"] for s in rows),
                    len(rows),
                )
            )
            writer.writerow(
                release(label, "nonempty_linked_discharge_text", len(docs), len(rows))
            )
            writer.writerow(
                release(
                    label,
                    "any_known_storetime_in_linked_text",
                    sum(s["known_store"] for s in docs),
                    len(docs),
                )
            )
            writer.writerow(
                release(
                    label,
                    "any_discharge_text_stored_by_ICU_transfer",
                    sum(s["by_t0"] for s in docs),
                    sum(s["known_store"] for s in docs),
                )
            )
            for m in METRICS:
                writer.writerow(
                    release(label, m, sum(m in s["flags"] for s in docs), len(docs))
                )
            for m in ("pending_culture_marker", "antibiotic_contingency_marker"):
                writer.writerow(
                    release(
                        label,
                        "no_" + m + "_in_linked_discharge_text",
                        sum(m not in s["flags"] for s in docs),
                        len(docs),
                    )
                )
    if private:
        private.mkdir(exist_ok=True, parents=True)
        with open(private / "note_labels.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["pid", "hid", "usable_note", *METRICS])
            for (pid, hid), s in state.items():
                w.writerow(
                    [
                        pid,
                        hid,
                        int(s["usable"]),
                        *[int(m in s["flags"]) if s["usable"] else "" for m in METRICS],
                    ]
                )


def low_risk_table(state, source, out):
    """Encounter-level retrospective language among low-risk first alerts."""
    seen = set()
    groups = {"low_risk_first_alert": [], "low_risk_no_matching_dose_by_24h": []}
    with opencsv(source) as f:
        reader = csv.DictReader(f)
        verify_fields(
            reader, {"pid", "hid", "low_risk", "eligible_admin24", "active_admin24"}
        )
        for row in reader:
            k = (row["pid"], row["hid"])
            if k in seen or k not in state or not state[k]["discordant"]:
                raise ValueError(
                    "Phenotype file must have unique keys from the discordant pending group"
                )
            seen.add(k)
            if row["low_risk"].strip().lower() in {
                "",
                "null",
                "na",
                "nan",
            } or not truth(row["low_risk"]):
                continue
            groups["low_risk_first_alert"].append(state[k])
            if row["eligible_admin24"].strip().lower() in {"1", "true", "t"}:
                if row["active_admin24"].strip().lower() in {"0", "false", "f"}:
                    groups["low_risk_no_matching_dose_by_24h"].append(state[k])
    with open(
        out / "low_risk_documentation.csv", "w", newline="", encoding="utf-8"
    ) as f:
        w = csv.writer(f)
        w.writerow(
            [
                "population",
                "metric",
                "n_transfers",
                "denominator_transfers",
                "percent",
                "wilson_lower95",
                "wilson_upper95",
            ]
        )
        for group, rows in groups.items():
            docs = [s for s in rows if s["usable"]]
            w.writerow(
                release(group, "nonempty_linked_discharge_text", len(docs), len(rows))
            )
            w.writerow(
                release(
                    group,
                    "colonization_no_treatment_marker",
                    sum("colonization_no_treatment_marker" in s["flags"] for s in docs),
                    len(docs),
                )
            )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--index", required=True)
    parser.add_argument("--notes", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--private", type=Path)
    parser.add_argument("--phenotypes")
    args = parser.parse_args()
    state = index_from(args.index)
    collect(state, args.notes)
    export(state, args.out, args.private)
    if args.phenotypes:
        low_risk_table(state, args.phenotypes, args.out)


if __name__ == "__main__":
    main()
