-- Local index only. One first eligible transfer per pending admission.
SELECT DISTINCT c.pid,c.hid,c.tm,
  EXISTS(SELECT 1 FROM coverage_pair_acc a WHERE a.pid=c.pid AND a.hid=c.hid) AS discordant
FROM cohort c
WHERE EXISTS(SELECT 1 FROM culture_red_flags f WHERE f.pid=c.pid AND f.hid=c.hid)
