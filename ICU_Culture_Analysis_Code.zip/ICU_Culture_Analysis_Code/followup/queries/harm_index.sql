SELECT p.pid,p.hid,c.tm,p.t AS idx,i.broad_at_transfer,
       CASE WHEN p.stop_obs THEN p.reduced ELSE NULL END AS reduced,
       p.age,p.baseline_agents,p.site,p.result,c.icu_in,c.hospital_end,
       c.first_return AS next_icu,c.died_at,p.analysis,
       (p.result='no_growth' AND s.explicit_no_growth) AS negative_at_report,
       s.explicit_no_growth,p.stop_obs,p.mrsa,p.ap,p.carb
FROM therapy_rx_person p JOIN followup_candidates i
  USING(scope,analysis,pid,hid,specimen,t,location,channel)
JOIN followup_transfer c USING(pid,hid)
JOIN culture_spec s USING(pid,hid,specimen)
