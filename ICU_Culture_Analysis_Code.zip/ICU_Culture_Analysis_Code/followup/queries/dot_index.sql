-- Both settings use administered broad-spectrum therapy before reporting in the report-time cohort.
WITH enrolled AS (
 SELECT r.*,b.baseline_agents,b.mrsa,b.ap,b.carb,c.age_at_exit AS age,
 CASE WHEN c.era_upper<=2019 THEN 'early' WHEN c.era_lower>=2020 THEN 'late' ELSE 'crossing' END AS era,
 greatest(0,epoch(r.t-c.icu_in)/86400.0) AS days_since_icu_entry,
 epoch(r.t-r.collected)/3600 AS specimen_age_hours
 FROM review_dot_reports r JOIN cohort c USING(pid,hid)
 JOIN review_dot_clock report ON report.pid=r.pid AND report.hid=r.hid AND report.t=r.t
 JOIN response_dot_dose_reg b ON b.clock_id=report.clock_id
 QUALIFY row_number() OVER(PARTITION BY r.scope,r.pid,r.hid,r.location
 ORDER BY r.t,CASE r.result WHEN 'direct_narrow_S' THEN 1 WHEN 'normal_flora' THEN 2 ELSE 3 END,r.specimen)=1
)
SELECT * FROM response_dot_index
UNION ALL BY NAME
SELECT pid,hid,scope,'report_active_only' AS analysis,location,t,hospital_end,specimen,age,
 'unknown' AS sex,era,site_group AS site,result,days_since_icu_entry,specimen_age_hours,
 baseline_agents,mrsa,ap,carb,other_positive,
 hospital_end>=(cast(t AS DATE)+8)::TIMESTAMP AS seven_complete_dates
FROM enrolled
