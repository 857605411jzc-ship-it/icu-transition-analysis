-- Choose the first ward report meeting each definition, before looking at 48 h observation.
-- Require a broad agent in the order regimen at both the transfer and the report.
-- Include all orders in the original broad-spectrum dictionary. Do not use future positives.
CREATE TEMP TABLE followup_candidates AS
WITH designs AS (SELECT * FROM (VALUES ('strict_negative'),('low_yield')) a(analysis))
SELECT r.*,d.analysis
FROM review_dot_eligible r CROSS JOIN designs d
JOIN culture_spec s ON s.pid=r.pid AND s.hid=r.hid AND s.specimen=r.specimen
WHERE r.scope='plus_exact_reflex' AND r.location='ward' AND r.channel='order'
  AND r.broad_at_transfer AND r.t>r.tm AND r.t<=r.tm+INTERVAL '48 hours'
  AND r.result IN ('no_growth','normal_flora')
  AND (d.analysis='low_yield' OR (r.result='no_growth' AND s.explicit_no_growth))
  AND NOT EXISTS (
    SELECT 1 FROM culture_spec x WHERE x.pid=r.pid AND x.hid=r.hid AND x.specimen<>r.specimen
    AND x.outcome_class='positive' AND x.final_time BETWEEN r.t-INTERVAL '48 hours' AND r.t
  )
QUALIFY row_number() OVER (PARTITION BY r.pid,r.hid,d.analysis
                           ORDER BY r.t,CASE r.result WHEN 'no_growth' THEN 0 ELSE 1 END,r.specimen)=1;

INSERT INTO review_dot_index BY NAME SELECT * FROM followup_candidates;
