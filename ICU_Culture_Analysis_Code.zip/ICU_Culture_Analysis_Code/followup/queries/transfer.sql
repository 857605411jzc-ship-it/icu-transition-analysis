CREATE TEMP TABLE followup_transfer AS
SELECT c.pid,c.hid,c.tm,c.icu_in,c.hospital_end,c.died_at,c.age_at_exit AS age,
       c.era_lower,c.era_upper,
       (SELECT min(l.began) FROM loc l
        WHERE l.pid=c.pid AND l.hid=c.hid AND l.unit_category='ICU'
        AND l.began>c.tm AND l.began<c.hospital_end AND l.ended>l.began) AS first_return
FROM cohort c;
