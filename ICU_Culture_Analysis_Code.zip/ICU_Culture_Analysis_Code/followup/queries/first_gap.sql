WITH first_gap AS (
 SELECT p.pid,p.hid,p.report_time,s.site_group
 FROM coverage_pair_acc p JOIN culture_spec s USING(pid,hid,specimen)
 QUALIFY p.report_time=min(p.report_time) OVER (PARTITION BY p.pid,p.hid)
)
SELECT f.pid,f.hid,t.tm,f.report_time,
       bool_or(f.site_group IN ('blood','csf','pleural','peritoneal','pericardial','synovial','deep_tissue_pus')) AS sterile,
       bool_and(coalesce(f.site_group IN ('urine','respiratory'),false)) AS nonsterile
FROM first_gap f JOIN followup_transfer t USING(pid,hid)
GROUP BY f.pid,f.hid,t.tm,f.report_time
