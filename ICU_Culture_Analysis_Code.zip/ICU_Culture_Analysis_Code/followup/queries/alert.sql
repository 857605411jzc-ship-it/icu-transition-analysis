WITH sites AS (
 SELECT i.pid,i.hid,i.alert,
        bool_or(s.site_group IN ('blood','csf','pleural','peritoneal','pericardial','synovial','deep_tissue_pus')) AS sterile,
        bool_and(coalesce(s.site_group IN ('urine','respiratory'),false)) AS nonsterile
 FROM alert_index_accession i JOIN culture_spec s USING(pid,hid,specimen)
 GROUP BY i.pid,i.hid,i.alert
)
SELECT i.pid,i.hid,i.tm,i.alert,s.sterile,s.nonsterile,r.channel,r.pre,r.base_documented,
       r.follow_documented,r.time_complete,r.hours,i.after_first_ward,r.pre_visible,r.status
FROM alert_index i JOIN sites s USING(pid,hid,alert)
JOIN alert_records r USING(pid,hid)
WHERE r.rule='spectrum' AND r.horizon=24
