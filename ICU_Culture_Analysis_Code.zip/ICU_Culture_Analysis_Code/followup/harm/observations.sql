-- Raw inputs are ordinary MIMIC tables. Link before reducing to the time windows.
CREATE TEMP TABLE h_index AS
SELECT row_number() OVER(ORDER BY b.pid,b.analysis) AS k,b.*,b.idx+INTERVAL '48 hours' AS lm,
       s.stable,s.recovering,s.high,s.lactate,s.sofa_now,p.gender AS sex,try_cast(p.dod AS DATE) AS dod,
       try_cast(a.admittime AS TIMESTAMP) AS admit,
       coalesce(try_cast(a.deathtime AS TIMESTAMP),
         CASE WHEN try_cast(a.hospital_expire_flag AS INTEGER)=1 THEN try_cast(a.dischtime AS TIMESTAMP) END) AS death,
       least(b.hospital_end,try_cast(a.deathtime AS TIMESTAMP)) AS inpatient_end
FROM h_bridge b LEFT JOIN h_status s USING(pid,hid,tm)
LEFT JOIN m_patients p ON b.pid=try_cast(p.subject_id AS BIGINT)
LEFT JOIN m_admissions a ON b.hid=try_cast(a.hadm_id AS BIGINT) AND b.pid=try_cast(a.subject_id AS BIGINT);
CREATE TEMP TABLE h_subject AS
SELECT pid,min(idx-INTERVAL '100 days') AS tmin,max(idx+INTERVAL '14 days') AS tmax FROM h_index GROUP BY pid;
CREATE TEMP TABLE h_lab_ids AS
SELECT try_cast(itemid AS INTEGER) AS id,
 CASE WHEN upper(trim(label))='CREATININE' AND upper(trim(fluid))='BLOOD' THEN 'creatinine' ELSE 'cdi' END AS kind
FROM m_d_labitems
WHERE (upper(trim(label))='CREATININE' AND upper(trim(fluid))='BLOOD')
 OR (regexp_matches(upper(label),'DIFF(ICILE)?') AND regexp_matches(upper(label),'TOXIN|TOXIGENIC|PCR|NUCLEIC|NAAT') AND upper(trim(fluid))='STOOL');
CREATE TEMP TABLE h_lab AS
SELECT s.pid,try_cast(l.hadm_id AS BIGINT) AS hid,try_cast(l.charttime AS TIMESTAMP) AS t,
       i.kind,try_cast(l.valuenum AS DOUBLE) AS v,upper(trim(l.valueuom)) AS u,upper(trim(l.value)) AS label
FROM m_labevents l JOIN h_lab_ids i ON try_cast(l.itemid AS INTEGER)=i.id
JOIN h_subject s ON try_cast(l.subject_id AS BIGINT)=s.pid AND try_cast(l.charttime AS TIMESTAMP) BETWEEN s.tmin AND s.tmax;
CREATE TEMP TABLE h_cr AS
SELECT i.k,l.t,max(l.v) AS v FROM h_index i JOIN h_lab l ON l.pid=i.pid AND (l.hid=i.hid OR l.hid IS NULL)
 AND l.t BETWEEN greatest(i.admit,i.idx-INTERVAL '14 days') AND least(i.inpatient_end,i.idx+INTERVAL '7 days')
WHERE l.kind='creatinine' AND upper(replace(l.u,' ',''))='MG/DL' AND l.v>0 AND l.v<100
GROUP BY i.k,l.t HAVING min(l.v)=max(l.v);
CREATE TEMP TABLE h_cr_event AS
WITH base AS (
 SELECT *,min(v) OVER(PARTITION BY k ORDER BY t RANGE BETWEEN INTERVAL '48 hours' PRECEDING AND INTERVAL '1 microsecond' PRECEDING) AS base48,
          min(v) OVER(PARTITION BY k ORDER BY t RANGE BETWEEN INTERVAL '7 days' PRECEDING AND INTERVAL '1 microsecond' PRECEDING) AS base7
 FROM h_cr
)
SELECT *,v>=base48+0.3-0.000001 OR v>=1.5*base7 AS aki FROM base;
CREATE TEMP TABLE h_micro AS
SELECT s.pid,try_cast(m.hadm_id AS BIGINT) AS hid,try_cast(m.charttime AS TIMESTAMP) AS t,
       m.micro_specimen_id AS accession,upper(trim(coalesce(m.spec_type_desc,''))) AS site,
       upper(trim(coalesce(m.test_name,''))) AS test,upper(trim(coalesce(m.org_name,''))) AS org,
       m.isolate_num,upper(trim(coalesce(m.ab_name,''))) AS ab,upper(trim(coalesce(m.interpretation,''))) AS ast,
       CASE WHEN regexp_matches(upper(coalesce(m.test_name,'')),'DIFF')
            THEN upper(trim(coalesce(m.comments,''))) ELSE '' END AS result_text
FROM m_microbiologyevents m JOIN h_subject s ON try_cast(m.subject_id AS BIGINT)=s.pid
AND try_cast(m.charttime AS TIMESTAMP) BETWEEN s.tmin AND s.tmax;
CREATE TEMP MACRO h_pos(x) AS
  regexp_full_match(x,'(POS|POSITIVE|DETECTED|POSITIVE FOR (TOXIGENIC )?C[.]? DIFFICILE( TOXIN(S)?( A (AND|&) B)?)?|C[.]? DIFFICILE (TOXIN(S)?( A (AND|&) B)? )?DETECTED)[ .]*');
CREATE TEMP MACRO h_neg(x) AS
  regexp_matches(x,'(^|[^A-Z])(NEG(ATIVE)?|NO(T)? DETECTED|NO TOXIN DETECTED)([^A-Z]|$)');
CREATE TEMP TABLE h_cd AS
WITH labs AS (
 SELECT pid,hid,t,h_pos(label) AS pos,h_neg(label) AS neg FROM h_lab WHERE kind='cdi'
), micro AS (
 SELECT pid,hid,t,
   (h_pos(org) OR h_pos(result_text) OR regexp_full_match(org,'(TOXIGENIC )?(CLOSTRIDIUM|CLOSTRIDIOIDES|C[.]) DIFFICILE( TOXIN(S)?( A (AND|&) B)?)?')) AS pos,
   h_neg(org) OR h_neg(result_text) AS neg
 FROM h_micro WHERE regexp_matches(site,'STOOL|FECES|FAECES')
 AND regexp_matches(test,'DIFF') AND regexp_matches(test,'TOXIN|TOXIGENIC|PCR|NUCLEIC|NAAT')
), combined AS (SELECT * FROM labs UNION ALL SELECT * FROM micro)
SELECT pid,hid,t,bool_or(pos) AND NOT bool_or(neg) AS pos,bool_or(neg) AND NOT bool_or(pos) AS neg
FROM combined GROUP BY pid,hid,t;
-- Sentinel resistance phenotypes: retain direct tested resistance and positive organism labels.
CREATE TEMP TABLE h_md AS
WITH organisms AS (
 SELECT *,
 CASE WHEN regexp_matches(org,'STAPH(YLOCOCCUS|[.])? AUREUS|(^|[^A-Z])MRSA([^A-Z]|$)') THEN 'MRSA'
      WHEN regexp_matches(org,'ENTEROCOCC(US|I)|(^|[^A-Z])VRE([^A-Z]|$)') THEN 'VRE'
      WHEN regexp_matches(org,'ESCHERICHIA COLI|KLEBSIELLA (PNEUMONIAE|OXYTOCA|AEROGENES)|ENTEROBACTER (CLOACAE|AEROGENES)') THEN 'CRE_selected' END AS phenotype,
 regexp_matches(test||' '||site,'SCREEN|SURVEILLANCE|MRSA SWAB|ANORECTAL|RECTAL SWAB|NASAL SWAB|NARES') AS screen
 FROM h_micro WHERE org<>'' AND accession IS NOT NULL
), matching AS (
 SELECT *,CASE WHEN phenotype='MRSA' THEN ab IN ('OXACILLIN','CEFOXITIN')
      WHEN phenotype='VRE' THEN ab='VANCOMYCIN'
      WHEN phenotype='CRE_selected' THEN ab IN ('ERTAPENEM','IMIPENEM','MEROPENEM','DORIPENEM') ELSE false END AS target_test,
 (phenotype='MRSA' AND regexp_matches(org,'METHICILLIN[- ]RESISTANT|OXACILLIN[- ]RESISTANT|(^|[^A-Z])MRSA([^A-Z]|$)'))
 OR (phenotype='VRE' AND regexp_matches(org,'VANCOMYCIN[- ]RESISTANT|(^|[^A-Z])VRE([^A-Z]|$)')) AS named
 FROM organisms WHERE phenotype IS NOT NULL
)
SELECT pid,hid,t,accession,phenotype,org,isolate_num,bool_or(screen) AS screen,
       bool_or(named OR (target_test AND ast='R')) AS resistant,
       bool_or(target_test AND ast IN ('R','I','S')) AS tested
FROM matching GROUP BY pid,hid,t,accession,phenotype,org,isolate_num;
CREATE TEMP TABLE h_cr_flags AS
SELECT i.k,min(c.v) FILTER(WHERE c.t BETWEEN i.idx-INTERVAL '7 days' AND i.idx) AS baseline_cr,
 count(*) FILTER(WHERE c.t>i.lm AND c.v IS NOT NULL) AS post_cr_count,
 count(*) FILTER(WHERE c.t BETWEEN i.lm-INTERVAL '7 days' AND i.lm AND c.aki)>0 AS prior_aki,
 count(*) FILTER(WHERE c.t>i.idx AND c.t<=i.lm AND c.aki)>0 AS grace_aki,
 min(c.t) FILTER(WHERE c.t>i.lm AND c.aki) AS aki_t
FROM h_index i LEFT JOIN h_cr_event c USING(k) GROUP BY i.k;
CREATE TEMP TABLE h_cd_flags AS
SELECT i.k,count(*) FILTER(WHERE c.pos AND c.t BETWEEN i.lm-INTERVAL '56 days' AND i.lm)>0 AS prior_cdi,
 count(*) FILTER(WHERE c.pos AND c.t>i.idx AND c.t<=least(i.lm,i.inpatient_end) AND (c.hid=i.hid OR c.hid IS NULL)
 AND date_diff('day',cast(i.admit AS DATE),cast(c.t AS DATE))>=3)>0 AS grace_cdi,
 count(*) FILTER(WHERE c.t>i.lm AND (c.hid=i.hid OR c.hid IS NULL) AND c.t<=least(i.idx+INTERVAL '7 days',i.inpatient_end)) AS post_cdi_tests,
 count(*) FILTER(WHERE c.t>i.lm AND (c.hid=i.hid OR c.hid IS NULL) AND c.t<=least(i.idx+INTERVAL '7 days',i.inpatient_end) AND (c.pos OR c.neg)) AS parsed_cdi_tests,
 min(c.t) FILTER(WHERE c.t>i.lm AND (c.hid=i.hid OR c.hid IS NULL) AND c.t<=least(i.idx+INTERVAL '7 days',i.inpatient_end)
 AND date_diff('day',cast(i.admit AS DATE),cast(c.t AS DATE))>=3 AND c.pos) AS cdi_t
FROM h_index i LEFT JOIN h_cd c ON c.pid=i.pid GROUP BY i.k;
CREATE TEMP TABLE h_md_flags AS
WITH pre AS (
 SELECT DISTINCT i.k,m.phenotype FROM h_index i JOIN h_md m ON m.pid=i.pid
 AND m.t BETWEEN i.lm-INTERVAL '90 days' AND i.lm WHERE m.resistant
), post AS (
 SELECT i.k,m.t,m.phenotype,m.tested,m.resistant,p.k IS NULL AS new
 FROM h_index i JOIN h_md m ON m.pid=i.pid AND (m.hid=i.hid OR m.hid IS NULL) AND m.t>i.lm
 AND m.t<=least(i.idx+INTERVAL '14 days',i.inpatient_end) AND NOT m.screen
 LEFT JOIN pre p ON p.k=i.k AND p.phenotype=m.phenotype
), tested AS (
 SELECT k,bool_or(tested) AS post_md_ast,min(t) FILTER(WHERE resistant AND new) AS md_t FROM post GROUP BY k
)
SELECT i.k,coalesce(t.post_md_ast,false) AS post_md_ast,t.md_t,
 EXISTS(SELECT 1 FROM pre p WHERE p.k=i.k) AS prior_any_md FROM h_index i LEFT JOIN tested t USING(k);
CREATE TEMP TABLE h_ready AS
SELECT i.*,a.* EXCLUDE(k),c.* EXCLUDE(k),m.* EXCLUDE(k),
  coalesce(r.prior_kidney_failure,false) AS prior_kidney_failure
FROM h_index i JOIN h_cr_flags a USING(k) JOIN h_cd_flags c USING(k) JOIN h_md_flags m USING(k) LEFT JOIN h_kidney r USING(pid,hid);
