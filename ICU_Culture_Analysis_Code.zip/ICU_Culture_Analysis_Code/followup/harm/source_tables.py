"""Resolve six MIMIC-IV 3.1 hospital tables across split local release copies."""

from __future__ import annotations

from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import re
import shutil
import tarfile
import tempfile
import zipfile

TABLES = (
    "admissions",
    "patients",
    "d_labitems",
    "labevents",
    "microbiologyevents",
    "diagnoses_icd",
)
EXT = (".csv.gz", ".parquet", ".csv")
ARCHIVES = (".zip", ".tar", ".tar.gz", ".tgz")
V31 = re.compile(
    r"mimic(?:[. _/-]*iv)?[. _/()-]*(?:v(?:ersion)?[. _/-]*)?3[._-]1(?![.\d]|[a-z])",
    re.I,
)
BAD = re.compile(
    r"(?:mimic[ ._-]*(?:iii|ii)(?:[ ./_-]|$)|(?:^|[ /_.-])(?:demo|clif|cxr|ecg|note|mimiciv_ed|mimiciv_note|derived|analysis_outputs)(?:[ /_.-]|$)|(?:^|[ /_.-])(?:v)?(?:1\.[0-9]+|2\.[0-9]+|3\.0)(?:[ /_.-]|$))",
    re.I,
)


def clean(path):
    return str(path).replace("\\", "/").lower()


def valid_path(path):
    return not BAD.search(clean(path))


def named_v31(path):
    s = clean(path)
    for ext in ARCHIVES:
        if s.endswith(ext):
            s = s[: -len(ext)]
            break
    return bool(V31.search(s)) and valid_path(s)


def table_name(path):
    name = PurePosixPath(clean(path)).name
    for ext in EXT:
        if name.endswith(ext):
            stem = name[: -len(ext)]
            if stem in TABLES:
                return stem, ext
    return None, None


def directories(primary, database):
    # Only the caller-designated primary is allowed without a version in its name.
    primary = Path(primary)
    roots = []
    for path in [primary]:
        if path.exists() and valid_path(path):
            roots.append(path)
        elif path == primary and path.exists() and not valid_path(path):
            raise ValueError(
                f"The selected MIMIC path appears to contain another release: {path}"
            )
    if database.is_dir():
        if named_v31(database):
            roots.append(database)
        else:
            pending = [database]
            for depth in range(3):
                children = []
                for parent in pending:
                    for p in sorted(parent.iterdir()):
                        if (
                            valid_path(p)
                            and named_v31(p)
                            and (p.is_dir() or clean(p).endswith(ARCHIVES))
                        ):
                            roots.append(p)
                        elif (
                            p.is_dir()
                            and valid_path(p)
                            and re.search(
                                r"mimic|physionet|download|archive|physiodata|database",
                                p.name,
                                re.I,
                            )
                        ):
                            children.append(p)
                pending = children
    distinct = []
    for root in roots:
        absolute = root.resolve()
        if absolute not in distinct:
            distinct.append(absolute)
    return distinct


def inventory(root):
    if root.is_file():
        return [], [root]
    found = []
    archives = []
    for directory, children, files in os.walk(root):
        children[:] = sorted(
            d
            for d in children
            if valid_path(Path(directory) / d)
            and not d.startswith(".")
            and d.casefold() not in ("__macosx", "private", "derived", "recycle.bin")
        )
        for fname in sorted(files):
            p = Path(directory) / fname
            if not valid_path(p.relative_to(root)):
                continue
            if table_name(p)[0]:
                found.append(p)
            elif clean(p).endswith(ARCHIVES):
                archives.append(p)
    return found, archives


def best_files(candidates):
    def rank(p):
        _, ext = table_name(p)
        return (p.parent.name.casefold() != "hosp", EXT.index(ext))

    best = min(map(rank, candidates))
    matches = [p for p in candidates if rank(p) == best]
    if len(matches) > 1:
        raise ValueError(
            "Multiple copies of the same source table in one release root: "
            + ", ".join(map(str, matches))
            + ". Use --mimic to select one release copy."
        )
    return matches[0]


def target_for(cache, archive, member, stem, ext):
    key = f"{archive.resolve()}|{archive.stat().st_size}|{archive.stat().st_mtime_ns}|{member}"
    folder = cache / hashlib.sha256(key.encode()).hexdigest()[:24]
    folder.mkdir(parents=True, exist_ok=True)
    return folder / (stem + ext)


def copy_member(opener, target, length):
    if target.exists() and target.stat().st_size == length:
        return
    if shutil.disk_usage(target.parent).free < length + 128 * 1024**2:
        raise OSError(f"Insufficient space for {target.name} in the private cache.")
    with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as tmp:
        tmp_path = Path(tmp.name)
        try:
            with opener() as src:
                shutil.copyfileobj(src, tmp, 1024 * 1024)
        except Exception:
            tmp.close()
            tmp_path.unlink(missing_ok=True)
            raise
    if tmp_path.stat().st_size != length:
        tmp_path.unlink(missing_ok=True)
        raise OSError("Truncated archive member.")
    tmp_path.replace(target)


def matching_members(archive, members, needs, cache, open_member, name, size):
    choices = {}
    for info in members:
        member = name(info)
        stem, ext = table_name(member)
        if (
            stem in needs
            and valid_path(member)
            and "__macosx" not in clean(member)
            and not PurePosixPath(clean(member)).is_absolute()
        ):
            choices.setdefault(stem, []).append(info)
    result = {}
    for stem, choices_for_table in choices.items():
        names = {Path(name(x)): x for x in choices_for_table}
        if len(names) != len(choices_for_table):
            raise ValueError(f"Duplicate member name for {stem} in {archive}")
        pick = names[best_files(list(names))]
        member = name(pick)
        _, ext = table_name(member)
        target = target_for(cache, archive, member, stem, ext)
        copy_member(lambda: open_member(pick), target, size(pick))
        result[stem] = (target, "archive", str(archive) + "!" + member)
    return result


def from_archive(archive, needs, cache):
    if archive.suffix.lower() == ".zip":
        with zipfile.ZipFile(archive) as package:
            return matching_members(
                archive,
                (m for m in package.infolist() if not m.is_dir()),
                needs,
                cache,
                package.open,
                lambda m: m.filename,
                lambda m: m.file_size,
            )
    if not clean(archive).endswith((".tar", ".tar.gz", ".tgz")):
        return {}
    with tarfile.open(archive, "r:*") as package:
        return matching_members(
            archive,
            (m for m in package if m.isfile()),
            needs,
            cache,
            package.extractfile,
            lambda m: m.name,
            lambda m: m.size,
        )


def resolve(primary, database, private):
    sources = {}
    explicit = os.getenv("MIMIC_LAB_DICTIONARY")
    if explicit:
        file = Path(explicit).resolve()
        # An explicit copy can have a browser's renamed filename. Use its data suffix and check its columns in DuckDB.
        if not file.is_file() or not valid_path(file) or not clean(file).endswith(EXT):
            raise ValueError(
                "MIMIC_LAB_DICTIONARY must be an existing MIMIC-IV 3.1 csv[.gz] or parquet dictionary file."
            )
        sources["d_labitems"] = (file, "explicit", str(file))
    archives = []
    for root in directories(primary, database):
        loose, packs = inventory(root)
        archives.extend(p for p in packs if p not in archives)
        grouped = {}
        for file in loose:
            stem = table_name(file)[0]
            if stem not in sources:
                grouped.setdefault(stem, []).append(file)
        for stem, files in grouped.items():
            best = best_files(files)
            sources[stem] = (best, "local_file", str(best))
        if len(sources) == len(TABLES):
            break

    # An individual table download wrapped in ZIP takes precedence over a full release archive.
    def rank(a):
        name = clean(a.name)
        return (
            not any(name.startswith(stem + ".") for stem in TABLES),
            not name.endswith(".zip"),
            str(a),
        )

    ordered = sorted(archives, key=rank)
    # Resolve the dictionary first. If it does not exist, the lab events archive
    # need not be copied to disk for the remaining non-laboratory endpoints.
    for required in (set(TABLES) - {"labevents"}, {"labevents"}):
        if required == {"labevents"} and "d_labitems" not in sources:
            continue
        for archive in ordered:
            needs = required - set(sources)
            if not needs:
                break
            prefix = clean(archive.name).split(".")[0]
            if prefix in TABLES and prefix not in needs:
                continue
            sources.update(from_archive(archive, needs, private / "raw_cache"))
    missing = set(TABLES) - set(sources)
    log = {
        t: (
            {"type": sources[t][1], "path": sources[t][2]}
            if t in sources
            else {"type": "unavailable"}
        )
        for t in TABLES
    }
    (private / "harm_table_sources.json").write_text(
        json.dumps(log, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    for name in TABLES:
        print(f'{name}: {log[name]["type"]}', flush=True)
    if "d_labitems" in missing:
        print(
            "Serum creatinine outcomes require the MIMIC-IV v3.1 d_labitems table.",
            flush=True,
        )
    if missing & {"admissions", "patients"}:
        raise FileNotFoundError(
            "Essential linked admission/demographics table(s) missing: "
            + ", ".join(sorted(missing & {"admissions", "patients"}))
        )
    return sources
