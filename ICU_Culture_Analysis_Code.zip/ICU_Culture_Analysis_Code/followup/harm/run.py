"""Estimate landmark associations with observed inpatient outcomes after a negative culture."""

import argparse
import csv
import math
import os
from datetime import timedelta
from pathlib import Path

for key in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ.setdefault(key, "1")

import duckdb
import numpy as np


def quote(text):
    return "'" + str(text).replace("'", "''") + "'"


from source_tables import resolve, TABLES

# These placeholders are never interpreted as a negative endpoint. The matching
# source-dependent outcomes and covariate-dependent models are withheld below.
SCHEMAS = {
    "d_labitems": "itemid label fluid",
    "labevents": "subject_id hadm_id itemid charttime valuenum valueuom value",
    "diagnoses_icd": "subject_id hadm_id icd_code icd_version",
    "microbiologyevents": "subject_id hadm_id charttime micro_specimen_id spec_type_desc test_name org_name isolate_num ab_name interpretation comments",
}


def relation(file):
    arg = quote(file.absolute().as_posix())
    if file.suffix.lower() == ".parquet":
        return f"read_parquet({arg},hive_partitioning=false)"
    return f"read_csv({arg},header=true,all_varchar=true,auto_detect=true,sample_size=10000,nullstr='')"


def extract(con, private, mimic, database=None, return_sources=False):
    sources = resolve(mimic, database or mimic, private)
    for name in TABLES:
        if name in sources and not (
            name == "labevents" and "d_labitems" not in sources
        ):
            query = "SELECT * FROM " + relation(sources[name][0])
        else:
            query = (
                "SELECT "
                + ", ".join(
                    "CAST(NULL AS VARCHAR) AS " + c for c in SCHEMAS[name].split()
                )
                + " WHERE FALSE"
            )
        con.execute("CREATE TEMP VIEW m_" + name + " AS " + query)
    con.execute(
        "CREATE TEMP VIEW h_bridge_raw AS SELECT * FROM "
        + relation(private / "harm_index.csv")
    )
    con.execute(
        """CREATE TEMP TABLE h_bridge AS SELECT cast(pid AS BIGINT) AS pid,cast(hid AS BIGINT) AS hid,analysis,
      cast(tm AS TIMESTAMP) AS tm,cast(idx AS TIMESTAMP) AS idx,cast(hospital_end AS TIMESTAMP) AS hospital_end,
      cast(icu_in AS TIMESTAMP) AS icu_in,cast(next_icu AS TIMESTAMP) AS next_icu,
      cast(age AS DOUBLE) AS age,cast(baseline_agents AS INT) AS baseline_agents,site,result,
      cast(reduced AS BOOLEAN) AS reduced,cast(broad_at_transfer AS BOOLEAN) AS broad_at_transfer
      FROM h_bridge_raw"""
    )
    con.execute(
        "CREATE TEMP TABLE h_status AS SELECT * FROM "
        + relation(private / "transfer_status.parquet")
    )
    for tab, ids in [("h_bridge", "pid,analysis"), ("h_status", "pid,hid,tm")]:
        if con.execute(
            f"SELECT count(*) FROM (SELECT {ids} FROM {tab} GROUP BY {ids} HAVING count(*)>1)"
        ).fetchone()[0]:
            raise ValueError("Duplicate keys in " + tab)
    if con.execute(
        """SELECT count(*) FROM h_bridge WHERE idx IS NULL OR tm IS NULL OR hospital_end IS NULL OR
            NOT(idx>tm AND idx<=tm+INTERVAL '48 hours' AND idx<hospital_end) OR broad_at_transfer IS DISTINCT FROM TRUE
            OR baseline_agents IS NULL OR baseline_agents<1 OR analysis NOT IN ('strict_negative','low_yield')"""
    ).fetchone()[0]:
        raise ValueError(
            "Culture index failed transfer, active spectrum or clock checks."
        )
    con.execute("""CREATE TEMP TABLE h_kidney AS
      SELECT DISTINCT b.pid,b.hid,true AS prior_kidney_failure
      FROM (SELECT DISTINCT pid,hid,idx FROM h_bridge) b JOIN m_admissions a ON cast(a.subject_id AS BIGINT)=b.pid
      AND try_cast(a.dischtime AS TIMESTAMP)<b.idx JOIN m_diagnoses_icd d ON a.hadm_id=d.hadm_id AND a.subject_id=d.subject_id
      WHERE (cast(d.icd_version AS INT)=10 AND upper(trim(d.icd_code)) IN ('N186','Z992'))
         OR (cast(d.icd_version AS INT)=9 AND trim(d.icd_code) IN ('5856','V4511'))""")
    con.execute(
        Path(__file__).with_name("observations.sql").read_text(encoding="utf-8")
    )
    if con.execute(
        "SELECT count(*) FROM h_index WHERE admit IS NULL OR sex IS NULL OR idx<admit OR hospital_end<idx"
    ).fetchone()[0]:
        raise ValueError(
            "A linked admission or patient record/clock is missing; verify MIMIC version."
        )
    if (
        "d_labitems" in sources
        and not con.execute(
            "SELECT count(*) FROM h_lab_ids WHERE kind='creatinine'"
        ).fetchone()[0]
    ):
        raise ValueError("No serum creatinine dictionary entry")
    rows = con.execute("SELECT * FROM h_ready ORDER BY analysis,pid")
    cols = [f[0] for f in rows.description]
    results = [dict(zip(cols, r)) for r in rows.fetchall()]
    return (results, sources) if return_sources else results


def wilson(k, n):
    a = 1.95996398454
    p = k / n
    d = 1 + a * a / n
    center = (p + a * a / (2 * n)) / d
    h = a * math.sqrt(p * (1 - p) / n + a * a / (4 * n * n)) / d
    return 100 * (center - h), 100 * (center + h)


def public_count(n):
    return str(n) if n >= 11 else "<11"


def risk_line(k, n):
    row = {"n": public_count(n), "events": public_count(k)}
    if min(k, n - k) < 11:
        return dict(row, status="small_cell", risk_pct="", lower="", upper="")
    lo, hi = wilson(k, n)
    return dict(
        row,
        status="estimated",
        risk_pct=round(100 * k / n, 3),
        lower=round(lo, 3),
        upper=round(hi, 3),
    )


def stopped(r):
    return int(r["reduced"])


def at_risk(r):
    lm = r["lm"]
    return (
        r["recovering"] is True
        and r["hospital_end"] > lm
        and (r["death"] is None or r["death"] > lm)
        and (r["next_icu"] is None or r["next_icu"] > lm)
        and r["reduced"] is not None
    )


def numeric_matrix(rows):
    b = []
    # All covariates are known by the culture report.
    cols = [
        lambda r: r["age"],
        lambda r: r["baseline_cr"],
        lambda r: r["baseline_agents"],
        lambda r: (r["idx"] - r["admit"]).total_seconds() / 86400,
        lambda r: (
            (r["tm"] - r["icu_in"]).total_seconds() / 86400 if r["icu_in"] else None
        ),
        lambda r: (r["idx"] - r["tm"]).total_seconds() / 3600,
        lambda r: r["lactate"],
        lambda r: r["sofa_now"],
    ]
    for fn in cols:
        v = np.array([np.nan if fn(r) is None else fn(r) for r in rows], dtype=float)
        finite = np.isfinite(v)
        if finite.any():
            b.append((~finite).astype(float))
            v = np.where(finite, v, np.median(v[finite]))
            b.append(np.clip((v - v.mean()) / max(v.std(), 1e-8), -5, 5))
    for col in ("site", "sex"):
        levels = sorted({str(r[col]) for r in rows})
        for val in levels[1:]:
            b.append(np.array([str(r[col]) == val for r in rows], float))
    b.append(np.array([r["prior_kidney_failure"] for r in rows], float))
    return np.column_stack([np.ones(len(rows))] + [v for v in b if v.std() > 1e-8])


def overlap(x, e, y):
    if min(e.sum(), len(e) - e.sum()) < 2:
        raise ValueError("single arm")
    beta = np.zeros(x.shape[1])
    ridge = np.eye(x.shape[1]) * 0.5
    ridge[0, 0] = 0
    for _ in range(70):
        p = 1 / (1 + np.exp(-np.clip(x @ beta, -32, 32)))
        step = np.linalg.solve(
            x.T @ ((p * (1 - p))[:, None] * x) + ridge, x.T @ (e - p) - ridge @ beta
        )
        beta += step * min(1, 2 / max(np.max(np.abs(step)), 1e-6))
        if np.max(np.abs(step)) < 1e-6:
            break
    else:
        raise ValueError("propensity model did not converge")
    p = 1 / (1 + np.exp(-np.clip(x @ beta, -32, 32)))
    w = np.where(e == 1, 1 - p, p)
    sel = e.astype(bool)
    risk = lambda mask: float(np.average(y[mask], weights=w[mask]))
    ess = lambda u: float(u.sum() ** 2 / (u @ u))
    separation = max(np.quantile(p[~sel], 0.01), np.quantile(p[sel], 0.01)) >= min(
        np.quantile(p[~sel], 0.99), np.quantile(p[sel], 0.99)
    )
    # A constant propensity indicates a shared distribution and is not a positivity failure.
    separation = separation and np.ptp(p) > 1e-6
    differences = []
    for j in range(1, x.shape[1]):
        a = x[sel, j]
        b = x[~sel, j]
        den = math.sqrt((a.var() + b.var()) / 2)
        if den > 1e-7:
            differences.append(
                abs(np.average(a, weights=w[sel]) - np.average(b, weights=w[~sel]))
                / den
            )
    return (
        100 * (risk(sel) - risk(~sel)),
        ess(w[sel]),
        ess(w[~sel]),
        max(differences, default=0),
        separation,
    )


def adjustment(rows, events, boot, rng):
    n = len(rows)
    if not n:
        return {"status": "no_eligible"}
    e = np.array([stopped(r) for r in rows], float)
    y = np.array(events, float)
    masks = [e == 0, e == 1]
    if any(min(y[m].sum(), int(m.sum()) - y[m].sum()) < 11 for m in masks):
        return {"status": "small_cell"}
    x = numeric_matrix(rows)
    try:
        rd, ess1, ess0, smd, separation = overlap(x, e, y)
    except (ValueError, np.linalg.LinAlgError):
        return {"status": "propensity_failed"}
    diag = {
        "effective_n_reduced": round(ess1, 1),
        "effective_n_continued": round(ess0, 1),
        "max_weighted_abs_smd": round(smd, 3),
    }
    if separation or min(ess0, ess1) < 11:
        return dict(diag, status="limited_overlap")
    draws = []
    for _ in range(boot):
        i = rng.integers(n, size=n)
        try:
            draws.append(overlap(x[i], e[i], y[i])[0])
        except (ValueError, np.linalg.LinAlgError):
            pass
    if len(draws) < max(100, 0.9 * boot):
        return dict(diag, status="unstable_bootstrap")
    lo, hi = np.percentile(draws, [2.5, 97.5])
    return dict(
        diag,
        status="estimated",
        adjusted_difference_pp=round(rd, 3),
        lower=round(lo, 3),
        upper=round(hi, 3),
        bootstrap_success=len(draws),
    )


def csv_out(out, name, rows):
    path = out / (name + ".csv")
    # Construct the full header even when some outcomes are withheld.
    fields = list(dict.fromkeys(k for r in rows for k in r))
    if not rows:
        rows = [dict(status="no_eligible")]
        fields = ["status"]
    tmp = path.with_suffix(".tmp")
    with tmp.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    tmp.replace(path)


def requirements(label):
    if (
        label == "AKI_day7_report_monitorable"
        or label == "AKI_before_or_at_landmark_or_prior_ESRD"
    ):
        return {"d_labitems", "labevents", "diagnoses_icd"}
    if "creatinine" in label:
        return {"d_labitems", "labevents"}
    if "Cdiff" in label:
        return {"d_labitems", "labevents", "microbiologyevents"}
    if "MDRO" in label or "target_organism_ast" in label:
        return {"microbiologyevents"}
    return set()


def summarize(rows, out, boot, missing=frozenset()):
    flow = []
    rates = []
    contrasts = []
    diag = []
    rng = np.random.default_rng(42602)
    for scope in ("strict_negative", "low_yield"):
        eligible = [r for r in rows if r["analysis"] == scope]
        stable = [r for r in eligible if r["recovering"] is True]
        base = [r for r in stable if at_risk(r)]
        for label, n in [
            ("report_index", len(eligible)),
            ("recovering_at_transfer", len(stable)),
            ("strict_clinical_stability", sum(r["stable"] is True for r in eligible)),
            ("recovery_unknown", sum(r["recovering"] is None for r in eligible)),
            ("in_hospital_alive_icu_free_48h_reduction_known", len(base)),
            (
                "ICU_return_by_48h_including_before_report",
                sum(
                    r["next_icu"] is not None and r["next_icu"] <= r["lm"]
                    for r in stable
                ),
            ),
            (
                "creatinine_AKI_signal_during_grace",
                sum(bool(r["grace_aki"]) for r in stable),
            ),
            (
                "hospital_onset_Cdiff_positive_during_grace",
                sum(bool(r["grace_cdi"]) for r in stable),
            ),
            (
                "during_grace_death",
                sum(r["death"] is not None and r["death"] <= r["lm"] for r in stable),
            ),
            (
                "during_grace_live_discharge",
                sum(
                    r["hospital_end"] <= r["lm"] and r["death"] is None for r in stable
                ),
            ),
            ("regimen_unresolved_at_48h", sum(r["reduced"] is None for r in stable)),
        ]:
            flow.append(
                dict(
                    analysis=scope,
                    step=label,
                    patients="" if requirements(label) & missing else public_count(n),
                    source_status=(
                        "source_unavailable"
                        if requirements(label) & missing
                        else "available"
                    ),
                    analysis_status=(
                        "no_qualifying_reports"
                        if not eligible
                        else (
                            "no_verified_recovery"
                            if not stable
                            else (
                                "no_observable_landmark"
                                if not base
                                else "landmark_available"
                            )
                        )
                    ),
                )
            )
        aki_ok = (
            lambda r: r["baseline_cr"] is not None
            and not r["prior_aki"]
            and not r["prior_kidney_failure"]
            and r["post_cr_count"] > 0
        )
        cdi_ok = lambda r: not r["prior_cdi"]
        repeat = lambda r: r["post_md_ast"]
        anyrow = lambda r: True
        death7 = lambda r: (
            r["death"] is not None
            and r["lm"] < r["death"] <= r["tm"] + timedelta(days=7)
        ) or (
            r["dod"] is not None
            and r["death"] is None
            and r["dod"] >= r["lm"].date()
            and r["dod"] <= (r["tm"] + timedelta(days=7)).date()
        )
        defs = [
            ("AKI_day7_report_monitorable", aki_ok, lambda r: r["aki_t"] is not None),
            (
                "hospital_onset_Cdiff_positive_day7_report",
                cdi_ok,
                lambda r: r["cdi_t"] is not None,
            ),
            (
                "new_sentinel_MDRO_detection_day14_report",
                anyrow,
                lambda r: r["md_t"] is not None,
            ),
            (
                "ICU_return_day7_transfer",
                anyrow,
                lambda r: r["next_icu"] is not None
                and r["next_icu"]
                <= min(r["tm"] + timedelta(days=7), r["inpatient_end"]),
            ),
            ("linked_mortality_day7_transfer", anyrow, death7),
        ]
        for label, filt, fn in defs:
            if requirements(label) & missing:
                for regimen in ("reduced", "continued"):
                    rates.append(
                        dict(
                            analysis=scope,
                            endpoint=label,
                            regimen=regimen,
                            n="",
                            events="",
                            risk_pct="",
                            lower="",
                            upper="",
                            status="source_unavailable",
                        )
                    )
                contrasts.append(
                    dict(analysis=scope, endpoint=label, status="source_unavailable")
                )
                continue
            d = [r for r in base if filt(r)]
            y = [int(fn(r)) for r in d]
            for g, name in [(1, "reduced"), (0, "continued")]:
                arm = [v for r, v in zip(d, y) if stopped(r) == g]
                rates.append(
                    dict(
                        analysis=scope,
                        endpoint=label,
                        regimen=name,
                        **risk_line(sum(arm), len(arm)),
                    )
                )
            contrasts.append(
                dict(
                    analysis=scope,
                    endpoint=label,
                    **(
                        {"status": "baseline_covariate_source_unavailable"}
                        if missing & {"labevents", "d_labitems", "diagnoses_icd"}
                        else adjustment(d, y, boot, rng)
                    ),
                )
            )
        for label, fn in [
            ("post_landmark_creatinine_measured", lambda r: r["post_cr_count"] > 0),
            (
                "AKI_before_or_at_landmark_or_prior_ESRD",
                lambda r: r["prior_aki"] or r["prior_kidney_failure"],
            ),
            ("baseline_creatinine_available", lambda r: r["baseline_cr"] is not None),
            ("followup_Cdiff_stool_assay", lambda r: r["post_cdi_tests"] > 0),
            ("followup_Cdiff_assay_interpretable", lambda r: r["parsed_cdi_tests"] > 0),
            ("followup_target_organism_ast", repeat),
            ("prior_sentinel_MDRO_90d", lambda r: r["prior_any_md"]),
            (
                "discharged_alive_before_report_day7",
                lambda r: r["hospital_end"] < r["idx"] + timedelta(days=7)
                and r["death"] is None,
            ),
            (
                "death_before_report_day7_in_hospital",
                lambda r: r["death"] is not None
                and r["death"] <= r["idx"] + timedelta(days=7),
            ),
            (
                "discharged_alive_before_report_day14",
                lambda r: r["hospital_end"] < r["idx"] + timedelta(days=14)
                and r["death"] is None,
            ),
            (
                "death_before_report_day14_in_hospital",
                lambda r: r["death"] is not None
                and r["death"] <= r["idx"] + timedelta(days=14),
            ),
        ]:
            for g, name in [(1, "reduced"), (0, "continued")]:
                d = [r for r in base if stopped(r) == g]
                if requirements(label) & missing:
                    diag.append(
                        dict(
                            analysis=scope,
                            measure=label,
                            regimen=name,
                            n="",
                            events="",
                            risk_pct="",
                            lower="",
                            upper="",
                            status="source_unavailable",
                        )
                    )
                else:
                    diag.append(
                        dict(
                            analysis=scope,
                            measure=label,
                            regimen=name,
                            **risk_line(sum(bool(fn(r)) for r in d), len(d)),
                        )
                    )
    for name, result in [
        ("harm_flow", flow),
        ("harm_risks", rates),
        ("harm_overlap_adjusted", contrasts),
        ("harm_ascertainment", diag),
    ]:
        csv_out(out, name, result)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("private", "out", "mimic"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument(
        "--database-root",
        type=Path,
        help="Optional directory containing additional local copies of the v3.1 tables.",
    )
    p.add_argument("--bootstrap", type=int, default=499)
    args = p.parse_args()
    if args.bootstrap < 100:
        p.error("--bootstrap must be at least 100")
    args.out.mkdir(parents=True, exist_ok=True)
    work = args.private / "harm_duckdb_temp"
    work.mkdir(exist_ok=True, parents=True)
    with duckdb.connect(
        config={
            "threads": "2",
            "memory_limit": "2GB",
            "temp_directory": str(work.absolute()),
        }
    ) as con:
        rows, sources = extract(
            con, args.private, args.mimic, args.database_root, return_sources=True
        )
    missing = set(TABLES) - set(sources)
    summarize(rows, args.out, args.bootstrap, missing)
    status = "partial" if missing else "complete"
    flags = [
        dict(
            kind="module",
            name="harm",
            status=status,
            detail=(
                "Unadjusted safety endpoints available when essential inputs present; missing source-specific estimates are blank."
                if missing
                else "All required raw tables resolved."
            ),
        )
    ]
    for name in TABLES:
        flags.append(
            dict(
                kind="source",
                name=name,
                status=sources[name][1] if name in sources else "missing",
                detail="MIMIC-IV 3.1 hospital module",
            )
        )
    for name in (
        "AKI_day7_report_monitorable",
        "hospital_onset_Cdiff_positive_day7_report",
        "new_sentinel_MDRO_detection_day14_report",
        "ICU_return_day7_transfer",
        "linked_mortality_day7_transfer",
    ):
        absent = sorted(requirements(name) & missing)
        flags.append(
            dict(
                kind="raw_endpoint",
                name=name,
                status="source_unavailable" if absent else "available",
                detail=", ".join(absent),
            )
        )
    csv_out(args.out, "harm_source_status", flags)
    print("Landmark analysis: " + status + ". Aggregate output: " + str(args.out))


if __name__ == "__main__":
    main()
