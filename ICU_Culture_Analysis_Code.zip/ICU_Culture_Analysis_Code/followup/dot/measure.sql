-- Assign each systemic broad-spectrum agent to its inpatient administration date.
CREATE TEMP TABLE review_dot_agents AS
SELECT agent, CASE WHEN category='mrsa' THEN 1 ELSE 0 END AS mrsa,
 CASE WHEN category IN ('ap','ap_carb') THEN 1 ELSE 0 END AS ap,
 CASE WHEN category IN ('carb','ap_carb') THEN 1 ELSE 0 END AS carb
FROM (VALUES
 ('vancomycin','mrsa'),('linezolid','mrsa'),('daptomycin','mrsa'),('tedizolid','mrsa'),
 ('ceftaroline','mrsa'),('telavancin','mrsa'),
 ('piperacillin_tazobactam','ap'),('cefepime','ap'),('ceftazidime','ap'),('aztreonam','ap'),
 ('ceftazidime_avibactam','ap'),('ceftolozane_tazobactam','ap'),('cefiderocol','ap'),
 ('ciprofloxacin','ap'),('levofloxacin','ap'),('gentamicin','ap'),('amikacin','ap'),
 ('tobramycin','ap'),('colistin','ap'),('polymyxin_b','ap'),('ertapenem','carb'),
 ('meropenem','ap_carb'),('imipenem','ap_carb'),('doripenem','ap_carb'),
 ('meropenem_vaborbactam','ap_carb'),('imipenem_relebactam','ap_carb')
) a(agent,category);
CREATE TEMP TABLE review_dot_admin AS
SELECT DISTINCT m.pid,m.hid,m.at_time,m.recorded,m.agent,m.route_kind AS route
FROM culture_em m JOIN review_dot_hosp h USING(pid,hid) JOIN review_dot_agents a USING(agent)
WHERE NOT regexp_matches(m.name,'TROUGH|PEAK|RANDOM LEVEL|PLACEHOLDER|DOSING BY PHARMACY|PHARMACY TO DOSE');
CREATE TEMP TABLE review_dot_day_counts AS
WITH daily_log AS (
 SELECT DISTINCT e.pid,e.hid,cast(e.at_time AS DATE) AS day FROM culture_em e JOIN review_dot_hosp h USING(pid,hid)
 WHERE e.at_time<(SELECT max(c.hospital_end) FROM cohort c WHERE c.pid=e.pid AND c.hid=e.hid)
), daily AS (
 SELECT d.report_id,d.day,d.inpatient_days,log.day IS NOT NULL AS documented,
  count(DISTINCT a.agent) FILTER(WHERE a.route='systemic') AS ndot,
  count(DISTINCT a.agent) FILTER(WHERE a.route='uncertain')>0 OR EXISTS(
   SELECT 1 FROM culture_amb_em m JOIN review_dot_agents k USING(agent) WHERE m.pid=d.pid AND m.hid=d.hid
    AND m.at_time>=d.day AND m.at_time<(d.day+1) AND m.at_time<d.hospital_end
    AND NOT EXISTS(SELECT 1 FROM review_dot_admin v WHERE v.pid=m.pid AND v.hid=m.hid AND v.agent=m.agent
          AND v.route='systemic' AND cast(v.at_time AS DATE)=d.day AND v.at_time<d.hospital_end)) AS uncertain_dose
 FROM review_dot_days d LEFT JOIN daily_log log USING(pid,hid,day)
 LEFT JOIN review_dot_admin a ON a.pid=d.pid AND a.hid=d.hid AND a.at_time>=d.day
  AND a.at_time<d.day+1 AND a.at_time<d.hospital_end AND a.route<>'local'
 GROUP BY d.report_id,d.pid,d.hid,d.day,d.hospital_end,d.inpatient_days,log.day
)
SELECT d.pid,d.hid,d.day,least(d.hospital_end,cast(d.day + 1 AS TIMESTAMP)) AS covered_until,
 k.documented,k.uncertain_dose AS uncertain_broad,k.ndot AS broad_agent_days
 FROM daily k JOIN review_dot_days d USING(report_id,day);
