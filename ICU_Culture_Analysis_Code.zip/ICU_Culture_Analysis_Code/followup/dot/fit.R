args <- commandArgs(trailingOnly=TRUE)
if(length(args)!=3L) stop("Expected program, private and aggregate directories.")
here <- args[1]; private <- args[2]; output <- args[3]
source(file.path(here,"calendar.R"),local=TRUE,encoding="UTF-8")
source(file.path(dirname(dirname(here)),"primary","order","models.R"),local=TRUE,encoding="UTF-8")
idx <- utils::read.csv(file.path(private,"dot_model_index.csv"),stringsAsFactors=FALSE)
index_bools <- c("other_positive","seven_complete_dates")
for(name in index_bools) idx[[name]] <- response_dot7_bool(idx[[name]],name)
daily <- utils::read.csv(file.path(private,"dot_daily.csv"),colClasses="character",check.names=FALSE)
d <- response_dot7_rows(idx,daily)

# The paper reports the full culture cohort and two specifications excluding reflex urine culture.
estimates <- list()
contrasts <- list()
bad <- utils::read.csv(file.path(private,"dot_unresolved_clocks.csv"),colClasses="character")
d$unresolved_clock <- paste(d$pid,d$hid,sep="/") %in% paste(bad$pid,bad$hid,sep="/")
groups <- list(c("plus_exact_reflex","report_active_only"),c("frozen","main"),c("frozen","report_active_only"))
for(group in groups) {
  z <- d[d$scope==group[1] & d$analysis==group[2],,drop=FALSE]
  for(clock_rule in c("original_administration_definition","exclude_admissions_with_unresolved_broad_timestamps")) {
    for(full in c(FALSE,TRUE)) {
      metric <- if(full) "broad_dot_full_7d" else "broad_dot_7d"
      zz <- z[(!full | z$seven_complete_dates) &
             (clock_rule=="original_administration_definition" | !z$unresolved_clock),,drop=FALSE]
      eligible <- zz[zz$dot_observed,,drop=FALSE]
      for(loc in c("ICU","ward")) {
        g <- eligible[eligible$location==loc,,drop=FALSE]
        extras <- if(nrow(g)>=11 && sum(g$value>0)>=11) c(sum(g$value),sum(g$inpatient_days),
                  unname(quantile(g$value,c(.25,.5,.75)))) else rep(NA_real_,5)
        estimates[[length(estimates)+1L]] <- cbind(scope=group[1],analysis=group[2],clock_rule,location=loc,
          candidates=report_count(sum(zz$location==loc)),treatment_summary(g,metric),
          total_broad_dot=extras[1],total_inpatient_days=extras[2],q1=extras[3],median=extras[4],q3=extras[5])
      }
      for(model in c("crude","adjusted")) {
        contrasts[[length(contrasts)+1L]] <- cbind(scope=group[1],analysis=group[2],clock_rule,location_contrast(eligible,metric,model))
      }
    }
  }
}
utils::write.csv(do.call(rbind,estimates),file.path(output,"dot7_summary.csv"),row.names=FALSE,na="")
utils::write.csv(do.call(rbind,contrasts),file.path(output,"dot7_contrasts.csv"),row.names=FALSE,na="")
