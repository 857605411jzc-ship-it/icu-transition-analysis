"""Reconstruct broad antibiotic calendar days from full hospital administrations following ICU and ward culture reports."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

import duckdb

BASE = Path(__file__).resolve().parent
MEDS = BASE.parents[1] / "primary" / "engine" / "medications.sql"


def literal(x):
    return "'" + str(x).replace("'", "''") + "'"


def source(file):
    path = literal(file.resolve().as_posix())
    return (
        f"read_parquet({path},hive_partitioning=false)"
        if file.suffix.lower() == ".parquet"
        else f"read_csv({path},header=true,all_varchar=true,sample_size=5000,nullstr='')"
    )


def piece(root, name):
    for d in [root / "hosp", root]:
        for ext in [".csv.gz", ".csv", ".parquet"]:
            f = d / (name + ext)
            if f.is_file():
                return f
    raise FileNotFoundError("Full MIMIC v3.1 hospital table required: " + name)


def prepare(con, raw, index, private):
    con.execute("CREATE TEMP VIEW idx AS SELECT * FROM " + source(index))
    # Only the planned calendar dates may contribute administrations. Preserve hospital exit to truncate each date.
    con.execute("""CREATE TEMP TABLE review_dot_days AS
    WITH clocks AS (SELECT DISTINCT cast(pid AS BIGINT) AS pid,cast(hid AS BIGINT) AS hid,
          cast(t AS TIMESTAMP) AS t,cast(hospital_end AS TIMESTAMP) AS hospital_end FROM idx),
    dates AS (SELECT DISTINCT pid,hid,hospital_end,cast(t AS DATE)+cast(x AS INT) AS day
              FROM clocks CROSS JOIN range(1,8) n(x) WHERE cast(t AS DATE)+cast(x AS INT)<hospital_end)
    SELECT *,row_number() OVER(ORDER BY pid,hid,day) AS report_id,
     epoch(least(hospital_end,cast(day + 1 AS TIMESTAMP))-cast(day AS TIMESTAMP))/86400 AS inpatient_days
    FROM dates""")
    con.execute(
        """CREATE TEMP TABLE cohort AS SELECT pid,hid,cast(min(day) AS TIMESTAMP) AS icu_in,
     max(hospital_end) AS hospital_end FROM review_dot_days GROUP BY pid,hid"""
    )
    con.execute("""CREATE TEMP TABLE review_dot_hosp AS SELECT pid,hid FROM cohort""")
    con.execute("""CREATE TEMP TABLE culture_ast(antibiotic VARCHAR)""")
    con.execute(
        "CREATE TEMP VIEW all_rx AS SELECT * FROM " + source(raw["prescriptions"])
    )
    con.execute("CREATE TEMP VIEW src_prescriptions AS SELECT * FROM all_rx")
    con.execute("CREATE TEMP VIEW all_em AS SELECT * FROM " + source(raw["emar"]))
    con.execute(
        "CREATE TEMP VIEW src_emar_detail AS SELECT * FROM "
        + source(raw["emar_detail"])
    )
    # Retain undated records in the limited admission set for a separate uncertainty audit.
    con.execute(
        """CREATE TEMP TABLE dot_selected_em AS SELECT cast(e.subject_id AS BIGINT) AS subject_id,
     cast(e.hadm_id AS BIGINT) AS hadm_id,e.emar_id,e.pharmacy_id,e.medication,e.event_txt,
     try_cast(e.charttime AS TIMESTAMP) AS charttime,try_cast(e.storetime AS TIMESTAMP) AS storetime
     FROM all_em e JOIN review_dot_hosp h ON h.pid=try_cast(e.subject_id AS BIGINT) AND h.hid=try_cast(e.hadm_id AS BIGINT)
     WHERE try_cast(e.charttime AS TIMESTAMP) IS NULL OR EXISTS
     (SELECT 1 FROM review_dot_days d WHERE d.pid=h.pid AND d.hid=h.hid AND cast(try_cast(e.charttime AS TIMESTAMP) AS DATE)=d.day
       AND try_cast(e.charttime AS TIMESTAMP)<d.hospital_end)"""
    )
    con.execute(
        """CREATE TEMP VIEW src_emar AS SELECT * FROM dot_selected_em WHERE charttime IS NOT NULL"""
    )
    con.execute(MEDS.read_text(encoding="utf-8"))
    con.execute((BASE / "measure.sql").read_text(encoding="utf-8"))
    con.execute("CREATE TEMP VIEW m_pat AS SELECT * FROM " + source(raw["patients"]))
    enriched = private / "dot_model_index.csv"
    daily = private / "dot_daily.csv"

    def export(sql, file):
        tmp = file.with_name(file.name + ".partial")
        con.execute(
            "COPY ("
            + sql
            + ") TO "
            + literal(tmp.resolve().as_posix())
            + " (HEADER,FORMAT CSV)"
        )
        os.replace(tmp, file)

    if con.execute(
        """SELECT count(*) FROM idx i WHERE NOT EXISTS (SELECT 1 FROM m_pat p
                   WHERE cast(i.pid AS BIGINT)=try_cast(p.subject_id AS BIGINT))"""
    ).fetchone()[0]:
        raise ValueError("Missing patient demographics for DOT control")
    export(
        """SELECT i.* EXCLUDE(sex),coalesce(nullif(upper(trim(p.gender)),''),'unknown') AS sex
        FROM idx i JOIN m_pat p ON cast(i.pid AS BIGINT)=try_cast(p.subject_id AS BIGINT)
        ORDER BY i.scope,i.analysis,cast(pid AS BIGINT),i.location""",
        enriched,
    )
    export("""SELECT * FROM review_dot_day_counts ORDER BY pid,hid,day""", daily)
    # Count loss of timestamps among candidate use/confirmation rows; count admissions, never expose keys.
    con.execute(
        """CREATE TEMP TABLE lost AS
       WITH names AS (SELECT DISTINCT culture_name(medication) AS name FROM dot_selected_em WHERE charttime IS NULL OR storetime IS NULL),
       mapped AS (SELECT n.name,p.agent FROM names n JOIN culture_drug_patterns p ON regexp_matches(n.name,p.pattern)
         QUALIFY row_number() OVER(PARTITION BY n.name ORDER BY p.priority)=1)
       SELECT DISTINCT e.subject_id,e.hadm_id,e.charttime IS NULL AS undated FROM dot_selected_em e
       JOIN mapped n ON culture_name(e.medication)=n.name JOIN review_dot_agents a USING(agent)
       WHERE (e.charttime IS NULL OR e.storetime IS NULL) AND culture_name(e.event_txt) IN
       ('ADMINISTERED','DELAYED ADMINISTERED','PARTIAL ADMINISTERED','ADMINISTERED BOLUS FROM IV DRIP',
        'ADMINISTERED IN OTHER LOCATION','STARTED','RESTARTED','DELAYED STARTED','STARTED IN OTHER LOCATION',
        'CONFIRMED','DELAYED CONFIRMED','CONFIRMED IN OTHER LOCATION','INFUSION RECONCILIATION','RATE CHANGE')
       AND NOT regexp_matches(n.name,'TROUGH|PEAK|RANDOM LEVEL|PLACEHOLDER|DOSING BY PHARMACY|PHARMACY TO DOSE')"""
    )
    export(
        "SELECT DISTINCT subject_id AS pid,hadm_id AS hid FROM lost",
        private / "dot_unresolved_clocks.csv",
    )
    return daily


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for key in ["private", "out", "mimic"]:
        p.add_argument("--" + key, required=True, type=Path)
    p.add_argument(
        "--rscript",
        default="Rscript",
        help="Rscript executable for the clustered regression models",
    )
    args = p.parse_args()
    priv = args.private.resolve()
    output = args.out.resolve()
    output.mkdir(parents=True, exist_ok=True)
    index = priv / "dot_index.csv"
    raw = {
        n: piece(args.mimic, n)
        for n in ["emar", "emar_detail", "prescriptions", "patients"]
    }

    def sha(file):
        return hashlib.sha256(file.read_bytes()).hexdigest()

    tag = {
        "inputs": {
            k: [str(v.resolve()), v.stat().st_size, v.stat().st_mtime_ns]
            for k, v in raw.items()
        },
        "code": [sha(f) for f in [index, MEDS, BASE / "run.py", BASE / "measure.sql"]],
    }
    marker = priv / "dot_daily_verified.json"
    required = [
        priv / p
        for p in ["dot_model_index.csv", "dot_daily.csv", "dot_unresolved_clocks.csv"]
    ]
    cached = json.loads(marker.read_text(encoding="utf8")) if marker.is_file() else {}
    if cached.get("tag") != tag or not all(
        f.exists() and sha(f) == cached.get(f.name) for f in required
    ):
        (priv / "dot_spill").mkdir(exist_ok=True)
        with duckdb.connect(
            config={
                "threads": "2",
                "memory_limit": "2GB",
                "temp_directory": str(priv / "dot_spill"),
            }
        ) as con:
            prepare(con, raw, index, priv)
        tmp = marker.with_suffix(".partial")
        tmp.write_text(
            json.dumps(dict(tag=tag, **{f.name: sha(f) for f in required})),
            encoding="utf8",
        )
        os.replace(tmp, marker)
    subprocess.run(
        [str(args.rscript), str(BASE / "fit.R"), str(BASE), str(priv), str(output)],
        check=True,
    )
    print("Seven-day broad antibiotic use calculated.")


if __name__ == "__main__":
    main()
