# Seven calendar days of administered broad-agent exposure from an existing daily intermediate.
response_dot7_clock <- function(x, name) {
  if (inherits(x, "POSIXt")) return(as.numeric(x))
  raw <- trimws(as.character(x))
  ok <- grepl("^\\d{4}-\\d{2}-\\d{2}([ T]\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?)?Z?$", raw)
  if (!all(ok & !is.na(x))) stop("Invalid hospital wall clock in ", name)
  raw <- sub("Z$", "", sub("T", " ", raw, fixed = TRUE))
  only_date <- nchar(raw) == 10L
  raw[only_date] <- paste(raw[only_date], "00:00:00")
  values <- as.numeric(as.POSIXct(raw, tz = "UTC", format = "%Y-%m-%d %H:%M:%OS"))
  if (anyNA(values)) stop("Unreadable time in ", name)
  values
}
response_dot7_bool <- function(x, name) {
  raw <- tolower(trimws(as.character(x)))
  if (!all(raw %in% c("0","1","true","false","t","f"))) stop("Unknown flag in ", name)
  raw %in% c("true","t","1")
}
response_dot7_rows <- function(index, daily) {
  if (!"analysis" %in% names(index)) index$analysis <- rep("main", nrow(index))
  required <- c("scope","analysis","pid","hid","location","t","hospital_end","age","sex","era",
                "site","result","baseline_agents","mrsa","ap","carb","days_since_icu_entry",
                "specimen_age_hours","other_positive")
  dvars <- c("pid","hid","day","covered_until","documented","uncertain_broad","broad_agent_days")
  if (!all(required %in% names(index)) || !all(dvars %in% names(daily)))
    stop("Expected DOT index and daily intermediate fields.")
  if ("channel" %in% names(index)) index <- index[index$channel == "emar", ,drop=FALSE]
  index <- index[index$analysis %in% c("main","report_active_only"), ,drop=FALSE]
  if (!nrow(index) || anyNA(index[c("scope","analysis","pid","hid","location","t","hospital_end")]) ||
      anyDuplicated(index[c("scope","analysis","pid","location")]))
    stop("Empty, missing or duplicate report index")
  index$sex[is.na(index$sex) | index$sex==""] <- "unknown"
  midnight <- function(x) floor(x/86400)*86400
  report <- response_dot7_clock(index$t, "t")
  exit <- response_dot7_clock(index$hospital_end, "hospital_end")
  if (any(!is.finite(exit)) || any(!is.finite(report)) || any(report>=exit)) stop("Invalid report and discharge order")
  pid <- as.character(index$pid)
  hid <- as.character(index$hid)
  if (!nrow(daily) || anyNA(daily[c("pid","hid","day")]) || anyDuplicated(daily[c("pid","hid","day")]))
    stop("Empty, missing or duplicate patient/admission/date in daily table")
  day <- as.character(daily$day)
  if (!all(grepl("^\\d{4}-\\d{2}-\\d{2}$", day))) stop("Expected YYYY-MM-DD in day")
  # Work on the shifted hospital calendar in UTC, independent of the machine's time zone.
  datecode <- function(x) as.character(as.Date(x/86400,origin="1970-01-01"))
  day_keys <- paste(as.character(daily$pid), as.character(daily$hid), day, sep="/")
  coverage <- response_dot7_clock(daily$covered_until, "covered_until")
  logged <- response_dot7_bool(daily$documented, "documented")
  ambiguous <- response_dot7_bool(daily$uncertain_broad, "uncertain_broad")
  agents <- suppressWarnings(as.numeric(daily$broad_agent_days))
  if (any(!is.finite(agents) | agents != floor(agents) | agents<0) || any(agents>0 & !logged))
    stop("Inconsistent daily broad-agent counts")
  first <- midnight(report)+86400
  dot <- rep(0, nrow(index)); eligible <- rep(TRUE, nrow(index))
  person_days <- rep(0, nrow(index))
  for (offset in 0:6) {
    day_start <- first+offset*86400
    used <- which(day_start < exit)
    if (!length(used)) next
    day_end <- pmin(day_start[used]+86400,exit[used])
    keys <- paste(pid[used],hid[used],datecode(day_start[used]),sep="/")
    hit <- match(keys,day_keys)
    if (anyNA(hit) || any(coverage[hit] < day_end))
      stop("The daily intermediate does not span every required inpatient date. No expanded DOT estimate was exported.")
    eligible[used] <- eligible[used] & logged[hit] & !ambiguous[hit]
    dot[used] <- dot[used]+agents[hit]
    person_days[used] <- person_days[used]+(day_end-day_start[used])/86400
  }
  index$value <- dot
  index$dot_observed <- eligible
  index$inpatient_days <- person_days
  index$seven_complete_dates <- exit >= first+7*86400
  index
}
